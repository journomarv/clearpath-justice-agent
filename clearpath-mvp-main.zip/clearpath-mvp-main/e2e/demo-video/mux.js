// Builds one narration track from the per-scene TTS clips, delayed to each
// scene's real recorded start time (timeline.json), then muxes it onto the
// Playwright recording. Using each clip's actual start offset (rather than
// assuming clips play back-to-back) keeps narration aligned with what's
// on-screen even though real page-load/network time varies scene to scene.
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const DIR = __dirname;
const timeline = JSON.parse(fs.readFileSync(path.join(DIR, "timeline.json"), "utf8")).timeline;
const videoPath = path.join(DIR, "video-raw", "main.webm");
const outPath = path.join(__dirname, "..", "..", "demos", "clearpath-full-e2e-walkthrough.mp4");

const inputs = [];
const filterParts = [];
timeline.forEach((scene, i) => {
  const audioPath = path.join(DIR, "audio", `${scene.id}.mp3`);
  inputs.push("-i", audioPath);
  // Input 0 is the video, so audio input i is ffmpeg input index i+1.
  filterParts.push(`[${i + 1}:a]adelay=${scene.offsetMs}|${scene.offsetMs}[a${i}]`);
});
const mixInputs = timeline.map((_, i) => `[a${i}]`).join("");
const filterComplex = `${filterParts.join(";")};${mixInputs}amix=inputs=${timeline.length}:normalize=0[aout]`;

fs.mkdirSync(path.dirname(outPath), { recursive: true });

const args = [
  "-y",
  "-i", videoPath,
  ...inputs,
  "-filter_complex", filterComplex,
  "-map", "0:v",
  "-map", "[aout]",
  "-c:v", "libx264",
  "-preset", "medium",
  "-crf", "20",
  "-c:a", "aac",
  "-b:a", "192k",
  "-shortest",
  outPath,
];

console.log("Running ffmpeg mux...");
execFileSync("ffmpeg", args, { stdio: "inherit" });
console.log("Wrote", outPath);
