// Full end-to-end demo recording for ClearPath Justice — public marketing
// pages, the applicant journey, and a direct look at the backend API.
// Runs against the real live production site (never a throwaway/local
// instance), so the demo is honest about what's actually deployed.
//
// Pacing: every "scene" holds for at least as long as its narration clip
// (see narration.json / audio/*.mp3), so the recording is never faster than
// a viewer can follow. mux.js later times each narration clip's start to
// this script's own timeline.json rather than assuming perfect alignment.
//
// Scrolling: every content page is scrolled all the way to the bottom, at a
// readable pace, so the viewer sees everything on the page — not a token
// scroll partway down. If a page is long enough that a full readable scroll
// would run past its narration, the scene is extended rather than the scroll
// being rushed or cut short (see fullScrollAndHold below).

const { chromium } = require("@playwright/test");
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const BASE = "https://clearpath-mvp.terminalvelocityai.tech";
const DEMO_IMAGE = path.join(__dirname, "assets", "demo-saps-certificate.png");
const VIDEO_DIR = path.join(__dirname, "video-raw");
const TIMELINE_PATH = path.join(__dirname, "timeline.json");

const TYPE_DELAY_MS = 45; // slow, readable typing rather than instant fill

function durationMs(id) {
  const audioPath = path.join(__dirname, "audio", `${id}.mp3`);
  const out = execSync(
    `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`
  )
    .toString()
    .trim();
  return Math.round(parseFloat(out) * 1000);
}

async function main() {
  fs.mkdirSync(VIDEO_DIR, { recursive: true });

  const browser = await chromium.launch({ headless: true, slowMo: 120 });
  const context = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    recordVideo: { dir: VIDEO_DIR, size: { width: 1280, height: 800 } },
  });

  const timeline = [];
  const recordingStart = Date.now();
  function mark(id) {
    timeline.push({ id, offsetMs: Date.now() - recordingStart });
  }
  function elapsedSince(id) {
    return Date.now() - (recordingStart + timeline.find((t) => t.id === id).offsetMs);
  }

  const page = await context.newPage();

  /**
   * Scrolls the current page all the way to the bottom at a slow, readable
   * pace, then holds until at least the scene's narration has had time to
   * play. If the full scroll would take longer than the narration, the
   * scroll wins — the scene simply runs longer than the narration clip
   * rather than truncating the scroll. Marks `id` itself, so call this in
   * place of a manual mark()+wait pair.
   */
  async function fullScrollAndHold(id, opts = {}) {
    const { settleMs = 700, pxPerSecond = 300, minScrollMs = 1200, maxScrollMs = 25000, bottomPauseMs = 1200, extra = 600 } = opts;
    mark(id);
    await page.waitForTimeout(settleMs);

    const scrollable = await page.evaluate(
      () => Math.max(0, document.documentElement.scrollHeight - window.innerHeight)
    );

    if (scrollable <= 20) {
      // Nothing meaningful to scroll — just hold for the narration.
      await page.waitForTimeout(Math.max(0, durationMs(id) + extra - elapsedSince(id)));
      return;
    }

    const scrollMs = Math.min(maxScrollMs, Math.max(minScrollMs, (scrollable / pxPerSecond) * 1000));
    const steps = Math.max(6, Math.round(scrollMs / 350));
    const stepDelay = scrollMs / steps;
    const stepSize = scrollable / steps;
    for (let i = 0; i < steps; i++) {
      await page.mouse.wheel(0, stepSize);
      await page.waitForTimeout(stepDelay);
    }
    // Rounding safety — land exactly at the bottom.
    await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));

    const narrationFloor = durationMs(id) + extra;
    const soFar = elapsedSince(id);
    await page.waitForTimeout(Math.max(bottomPauseMs, narrationFloor - soFar));
  }

  // Unique demo account for this recording — cleaned up at the end via the
  // real self-service delete endpoint, same convention this repo already
  // uses for any test account created against production.
  const email = `demo-video-${Date.now()}@example.com`;
  const password = "CorrectHorse!Battery9Demo";
  console.log("Demo account for this run:", email);
  let accessToken = null;
  let documentId = null;
  let passportId = null;

  try {
    // ---- 01: intro on the homepage (stay at top so the hero is readable) ----
    await page.goto(BASE + "/", { waitUntil: "load" });
    mark("01_intro");
    await page.waitForTimeout(Math.max(0, durationMs("01_intro") + 600 - elapsedSince("01_intro")));

    // ---- 02: homepage, full scroll to the bottom ----
    await fullScrollAndHold("02_homepage");

    // ---- 03: how it works, full scroll ----
    await page.goto(BASE + "/how-it-works", { waitUntil: "load" });
    await fullScrollAndHold("03_howitworks");

    // ---- 04: screener question 1 ----
    await page.goto(BASE + "/screener", { waitUntil: "load" });
    mark("04_screener_q1");
    await page.waitForTimeout(2500);
    await page.getByRole("button", { name: /Use or possession only/ }).click();
    await page.waitForTimeout(Math.max(0, durationMs("04_screener_q1") + 600 - elapsedSince("04_screener_q1")));

    // ---- 05: screener question 2 ----
    mark("05_screener_q2");
    await page.waitForTimeout(2000);
    await page.getByRole("button", { name: /Drugs and Drug Trafficking Act 140 of 1992/ }).click();
    await page.waitForTimeout(Math.max(0, durationMs("05_screener_q2") + 600 - elapsedSince("05_screener_q2")));

    // ---- 06: screener result, full scroll ----
    await fullScrollAndHold("06_screener_result");

    // ---- 07: refer page, full scroll ----
    await page.goto(BASE + "/refer", { waitUntil: "load" });
    await fullScrollAndHold("07_refer");

    // ---- 08: register ----
    await page.goto(BASE + "/register", { waitUntil: "load" });
    mark("08_register");
    await page.getByLabel("Full name").click();
    await page.getByLabel("Full name").pressSequentially("Demo Applicant", { delay: TYPE_DELAY_MS });
    await page.getByLabel("Email").pressSequentially(email, { delay: TYPE_DELAY_MS });
    await page.getByLabel("Password (min. 12 characters)").pressSequentially(password, { delay: TYPE_DELAY_MS });
    await page.getByLabel("Confirm password").pressSequentially(password, { delay: TYPE_DELAY_MS });
    await page.locator('input[name="acceptedPrivacyPolicy"]').check();
    await page.waitForTimeout(400);
    const [registerResponse] = await Promise.all([
      page.waitForResponse((r) => r.url().includes("/api/v1/auth/register")),
      page.getByRole("button", { name: "Create account" }).click(),
    ]);
    if (registerResponse.status() !== 201) {
      throw new Error(`Registration failed: ${registerResponse.status()}`);
    }
    await page.getByText("Account created").waitFor({ timeout: 5000 });
    await page.waitForTimeout(Math.max(0, durationMs("08_register") + 600 - elapsedSince("08_register")));

    // ---- 09: login ----
    await page.goto(BASE + "/login", { waitUntil: "load" });
    mark("09_login");
    await page.getByLabel("Email").pressSequentially(email, { delay: TYPE_DELAY_MS });
    await page.getByLabel("Password").pressSequentially(password, { delay: TYPE_DELAY_MS });
    await page.waitForTimeout(300);
    const [loginResponse] = await Promise.all([
      page.waitForResponse((r) => r.url().includes("/api/v1/auth/login")),
      page.getByRole("button", { name: "Log in" }).click(),
    ]);
    if (loginResponse.status() !== 200) throw new Error(`Login failed: ${loginResponse.status()}`);
    await page.waitForURL(/\/dashboard$/, { timeout: 5000 });
    accessToken = await page.evaluate(() => sessionStorage.getItem("accessToken"));
    await page.waitForTimeout(Math.max(0, durationMs("09_login") + 600 - elapsedSince("09_login")));

    // ---- 10: dashboard, full scroll ----
    await fullScrollAndHold("10_dashboard");

    // ---- 11: upload ----
    await page.goto(BASE + "/dashboard/upload", { waitUntil: "load" });
    mark("11_upload");
    await page.waitForTimeout(1500);
    await page.locator('input[type="file"]').setInputFiles(DEMO_IMAGE);
    await page.waitForTimeout(600);
    await page.getByRole("button", { name: "Upload" }).click();
    await page.getByText("Upload received").waitFor({ timeout: 20000 });
    // Pull the real document id back out via the API so the eligibility scene
    // can deep-link straight to it, same as the real "Eligibility page" link
    // shown in the UI does.
    const docsBody = await page.evaluate(async (token) => {
      const res = await fetch("/api/v1/documents", { headers: { Authorization: `Bearer ${token}` } });
      return res.json();
    }, accessToken);
    documentId = docsBody.documents?.[0]?.id ?? null;
    // Full scroll here shows the rest of the upload page's own content
    // (accepted formats, the "Upload received" confirmation) before moving on.
    await fullScrollAndHold("11_upload", { settleMs: 200 });

    // ---- 12: eligibility, manual entry, then full scroll ----
    await page.goto(BASE + `/dashboard/eligibility${documentId ? `?documentId=${documentId}` : ""}`, {
      waitUntil: "load",
    });
    mark("12_eligibility");
    await page.waitForTimeout(2000);
    await page.getByRole("button", { name: "Add offence manually" }).click();
    await page.getByLabel("Offence description").pressSequentially(
      "Possession of a small quantity of cannabis for personal use",
      { delay: TYPE_DELAY_MS }
    );
    await page.getByLabel("Offence date (optional)").fill("2015-03-14");
    await page.getByLabel("Court (optional)").pressSequentially("Cape Town Magistrate's Court", { delay: TYPE_DELAY_MS });
    await page.waitForTimeout(400);
    await page.getByRole("button", { name: "Add offence" }).click();
    await page.waitForTimeout(1000);
    await fullScrollAndHold("12_eligibility", { settleMs: 200 });

    // ---- 13: prepare, full scroll ----
    await page.goto(BASE + "/dashboard/prepare", { waitUntil: "load" });
    await fullScrollAndHold("13_prepare");

    // ---- 14: tracking + verify, then full scroll to show the whole page ----
    await page.goto(BASE + "/dashboard/tracking", { waitUntil: "load" });
    mark("14_tracking_verify");
    await page.waitForTimeout(1500);
    await page.getByRole("button", { name: "Start my case" }).click();
    await page.waitForTimeout(1200);
    await page.getByLabel("Reference number").pressSequentially("DOJ-2026-DEMO-001", { delay: TYPE_DELAY_MS });
    await page.getByLabel("Date submitted").fill("2026-08-01");
    await page.getByLabel("Final outcome").selectOption("granted");
    await page.getByLabel("Date of outcome").fill("2026-09-01");
    await page.waitForTimeout(400);
    await page.getByRole("button", { name: "Save" }).click();
    await page.waitForTimeout(1000);
    await fullScrollAndHold("14_tracking_verify", { settleMs: 200 });

    // ---- 15: digital justice passport, then full scroll to show it in place ----
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(400);
    mark("15_tracking_passport");
    await page.waitForTimeout(600);
    await page.getByRole("button", { name: "Generate Passport" }).click();
    await page.getByText(/\/verify\//).waitFor({ timeout: 8000 });
    const linkText = await page.locator("code", { hasText: "/verify/" }).first().innerText();
    passportId = linkText.trim().split("/verify/")[1];
    await fullScrollAndHold("15_tracking_passport", { settleMs: 200 });

    // ---- 16: public verify page, full scroll ----
    // This page needs no authentication at all — that's the whole point of a
    // Digital Justice Passport — so it's shown in the same recorded tab
    // rather than a second browser context (keeps this a single video file;
    // the backend genuinely does not check any cookie/token on this route).
    await page.goto(`${BASE}/verify/${passportId}`, { waitUntil: "load" });
    await fullScrollAndHold("16_verify_public");

    // ---- 17: AI assistant ----
    await page.goto(BASE + "/dashboard/assistant", { waitUntil: "load" });
    mark("17_assistant");
    await page.waitForTimeout(1200);
    await page.getByPlaceholder("Ask a question...").pressSequentially(
      "Am I eligible for expungement?",
      { delay: TYPE_DELAY_MS }
    );
    await page.getByRole("button", { name: "Send" }).click();
    await page.getByText("Thinking...").waitFor({ timeout: 3000 }).catch(() => {});
    await page.getByText("Thinking...").waitFor({ state: "detached", timeout: 20000 }).catch(() => {});
    // Not a page-level scroll: the assistant is a fixed chat widget, not a
    // long page — a full-page scroll wouldn't reveal anything more.
    await page.waitForTimeout(Math.max(0, durationMs("17_assistant") + 600 - elapsedSince("17_assistant")));

    // ---- 18: account & security, full scroll on each ----
    await page.goto(BASE + "/dashboard/account", { waitUntil: "load" });
    await fullScrollAndHold("18_account_security", { settleMs: 300, bottomPauseMs: 600 });
    await page.goto(BASE + "/dashboard/security", { waitUntil: "load" });
    await page.waitForTimeout(1500);

    // ---- 19: backend, direct API calls ----
    // Fetches must run from a same-origin page (BASE), not about:blank, or the
    // browser's CORS check rejects them outright before they ever reach the
    // server — that's the browser enforcing the real cross-origin policy, not
    // a test artifact. Collect results here, then switch to the terminal-style
    // display.
    mark("19_backend");
    const backendResults = await page.evaluate(async (base) => {
      const health = await fetch(`${base}/health`).then((r) => r.json());
      const noToken = await fetch(`${base}/api/v1/assistant/message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "hi" }),
      }).then((r) => ({ status: r.status }));
      return { health, noToken };
    }, BASE);
    const verifyResult = await page.evaluate(
      async ({ base, id }) => fetch(`${base}/api/v1/passport/${id}/verify`).then((r) => r.json()),
      { base: BASE, id: passportId }
    );
    await page.goto("about:blank");
    await page.setContent(`
      <html><body style="font-family: monospace; background:#0b1220; color:#d1fae5; padding:40px; font-size:22px;">
        <p>&gt; curl ${BASE}/health</p>
        <pre>${JSON.stringify(backendResults.health)}</pre>
        <p>&gt; curl ${BASE}/api/v1/passport/${passportId}/verify</p>
        <pre>${JSON.stringify(verifyResult)}</pre>
        <p>&gt; curl -X POST ${BASE}/api/v1/assistant/message  (no auth token)</p>
        <pre>HTTP ${backendResults.noToken.status} Unauthorized</pre>
      </body></html>
    `);
    await page.waitForTimeout(Math.max(0, durationMs("19_backend") + 600 - elapsedSince("19_backend")));

    // ---- 20: outro, back on the homepage, full scroll again ----
    await page.goto(BASE + "/", { waitUntil: "load" });
    await fullScrollAndHold("20_outro");
  } finally {
    // Always attempt cleanup, even if an earlier scene threw — an orphaned
    // demo account on production is exactly the kind of leftover this repo's
    // own convention says to avoid. Best-effort: if login never succeeded,
    // accessToken is still null and there is nothing to delete.
    if (accessToken) {
      try {
        await page.evaluate(
          async ({ base, token, password }) => {
            await fetch(`${base}/api/v1/account/delete`, {
              method: "POST",
              headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
              credentials: "include",
              body: JSON.stringify({ password }),
            });
          },
          { base: BASE, token: accessToken, password }
        );
        console.log("Cleaned up demo account:", email);
      } catch (cleanupErr) {
        console.error("Cleanup failed — manual deletion needed for", email, cleanupErr);
      }
    } else {
      console.log("No access token acquired — nothing to clean up for", email);
    }

    await context.close();
    await browser.close();

    fs.writeFileSync(TIMELINE_PATH, JSON.stringify({ email, documentId, passportId, timeline }, null, 2));
    console.log("Timeline written to", TIMELINE_PATH);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
