# ClearPath Justice — Playwright E2E suite

Full end-to-end tests run against the **real backend + a real Postgres
instance** (not mocked) plus the real Next.js frontend. Covers: marketing
site rendering/navigation, register → login → dashboard, client-side
validation (weak password, mismatched confirm-password, disallowed file
type), a real PDF upload round-trip through the API, and security/RBAC
checks (unauthenticated/under-privileged access blocked, account lockout
after 5 failed logins, security headers present).

## Prerequisites
- Postgres and Redis reachable at the URLs in `backend/.env` (see
  `backend/.env.example`). Easiest local setup:
  ```bash
  docker run -d --name clearpath-postgres -e POSTGRES_USER=clearpath \
    -e POSTGRES_PASSWORD=changeme -e POSTGRES_DB=clearpath_dev \
    -p 127.0.0.1:5432:5432 postgres:16-alpine
  docker run -d --name clearpath-redis -p 127.0.0.1:6379:6379 redis:7-alpine
  ```
- Backend migrated and running: `cd backend && npm run prisma:migrate && npm run dev`
- Frontend running: `cd frontend && npm run dev` (defaults to port 3000;
  update `playwright.config.ts` `baseURL` and `backend/.env`'s
  `FRONTEND_ORIGIN` if you run it on a different port)

## Run
```bash
cd e2e
npm install
npx playwright install chromium --with-deps
npm test
```

## Notes
- `authRateLimit` (10 auth requests / 15 min per IP) and the account-lockout
  logic (5 failed attempts per account) are both real, active controls. In a
  full suite run they can interact — the IP-level limiter may fire before an
  individual account's lockout does. The lockout test accepts either 401/423
  (lockout) or 429 (rate limit) as a pass, since both mean "brute force
  blocked"; see the comment in `tests/clearpath.spec.ts`.
- Uploaded documents are recorded in Postgres (`documents` table) with a
  `pending` virus-scan status — the actual AV scan and encrypted-object-
  storage upload are documented TODOs (see root `README.md`), not yet wired.
