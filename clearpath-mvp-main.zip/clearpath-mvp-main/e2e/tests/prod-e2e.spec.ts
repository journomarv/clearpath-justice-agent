import { test, expect } from "@playwright/test";

const BASE = "https://clearpath-mvp.terminalvelocityai.tech";
const uniqueEmail = `e2e-prod-${Date.now()}@example.com`;
const password = "correct-horse-battery-staple";

test("register form actually submits and succeeds on production", async ({ page }) => {
  const requests: string[] = [];
  const consoleErrors: string[] = [];
  page.on("console", (msg) => {
    if (msg.type() === "error") consoleErrors.push(msg.text());
  });
  page.on("requestfailed", (req) => {
    requests.push(`FAILED: ${req.method()} ${req.url()} - ${req.failure()?.errorText}`);
  });

  await page.goto(`${BASE}/register`);

  await page.getByLabel("Full name").fill("E2E Prod Tester");
  await page.getByLabel("Email").fill(uniqueEmail);
  await page.getByLabel("Password (min. 12 characters)").fill(password);
  await page.getByLabel("Confirm password").fill(password);
  await page.locator('input[name="acceptedPrivacyPolicy"]').check();

  const [response] = await Promise.all([
    page.waitForResponse((r) => r.url().includes("/api/v1/auth/register")),
    page.getByRole("button", { name: "Create account" }).click(),
  ]);

  expect(response.status()).toBe(201);
  await expect(page.getByText("Check your inbox")).toBeVisible({ timeout: 5000 });

  console.log("Failed requests:", requests);
  console.log("Console errors:", consoleErrors);
});

test("login with the freshly registered account lands on dashboard", async ({ page }) => {
  await page.goto(`${BASE}/login`);
  await page.getByLabel("Email").fill(uniqueEmail);
  await page.getByLabel("Password").fill(password);

  const [response] = await Promise.all([
    page.waitForResponse((r) => r.url().includes("/api/v1/auth/login")),
    page.getByRole("button", { name: "Log in" }).click(),
  ]);
  expect(response.status()).toBe(200);

  await expect(page).toHaveURL(/\/dashboard$/, { timeout: 5000 });

  const token = await page.evaluate(() => sessionStorage.getItem("accessToken"));
  expect(token).toBeTruthy();
  expect(token!.split(".")).toHaveLength(3);
});

test("mismatched confirm-password shows inline error, no network call", async ({ page }) => {
  await page.goto(`${BASE}/register`);
  await page.getByLabel("Full name").fill("Mismatch Tester");
  await page.getByLabel("Email").fill(`mismatch-${Date.now()}@example.com`);
  await page.getByLabel("Password (min. 12 characters)").fill("correct-horse-battery-1");
  await page.getByLabel("Confirm password").fill("different-password-123");
  await page.locator('input[name="acceptedPrivacyPolicy"]').check();
  await page.getByRole("button", { name: "Create account" }).click();
  await expect(page.getByText("Passwords do not match.")).toBeVisible();
});

test("marketing pages render on production", async ({ page }) => {
  for (const path of ["/", "/about", "/how-it-works", "/faq", "/contact"]) {
    const res = await page.goto(`${BASE}${path}`);
    expect(res?.status()).toBe(200);
  }
});
