import { test, expect } from "@playwright/test";

const API_URL = "http://localhost:4000";
const uniqueEmail = `e2e-${Date.now()}@example.com`;
const password = "correct-horse-battery-staple";

test.describe("Marketing site", () => {
  const pages: [string, string][] = [
    ["/", "Clear your record"],
    ["/about", "About ClearPath Justice"],
    ["/how-it-works", "How it Works"],
    ["/faq", "Frequently Asked Questions"],
    ["/contact", "Contact Us"],
  ];

  for (const [path, heading] of pages) {
    test(`renders ${path}`, async ({ page }) => {
      const res = await page.goto(path);
      expect(res?.status()).toBe(200);
      await expect(page.getByText(heading, { exact: false }).first()).toBeVisible();
    });
  }

  test("navigates via header links", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("link", { name: "About" }).click();
    await expect(page).toHaveURL(/\/about$/);
    await page.getByRole("link", { name: "FAQ" }).click();
    await expect(page).toHaveURL(/\/faq$/);
  });
});

test.describe("Auth flow (full E2E against real backend + Postgres)", () => {
  test("register -> login -> land on dashboard", async ({ page }) => {
    await page.goto("/register");

    await page.getByLabel("Full name").fill("E2E Tester");
    await page.getByLabel("Email").fill(uniqueEmail);
    await page.getByLabel("Password (min. 12 characters)").fill(password);
    await page.getByLabel("Confirm password").fill(password);
    await page.getByLabel(/accept the POPIA/).check();

    await page.getByRole("button", { name: "Create account" }).click();

    await expect(page.getByText("Check your inbox")).toBeVisible();

    // Now log in with the account just created.
    await page.goto("/login");
    await page.getByLabel("Email").fill(uniqueEmail);
    await page.getByLabel("Password").fill(password);
    await page.getByRole("button", { name: "Log in" }).click();

    await expect(page).toHaveURL(/\/dashboard$/);
    await expect(page.getByRole("heading", { name: "Welcome back" })).toBeVisible();

    // Access token was actually issued and stored (real JWT round-trip).
    const token = await page.evaluate(() => sessionStorage.getItem("accessToken"));
    expect(token).toBeTruthy();
    expect(token!.split(".")).toHaveLength(3); // header.payload.signature
  });

  test("login rejects wrong password with generic error (no account enumeration)", async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Email").fill(uniqueEmail);
    await page.getByLabel("Password").fill("totally-wrong-password");
    await page.getByRole("button", { name: "Log in" }).click();
    await expect(page.getByText("Invalid email or password.")).toBeVisible();
    await expect(page).toHaveURL(/\/login$/); // did not navigate away
  });

  test("register rejects a weak password client-side before hitting the API", async ({ page }) => {
    await page.goto("/register");
    await page.getByLabel("Full name").fill("Weak Password Tester");
    await page.getByLabel("Email").fill(`weak-${Date.now()}@example.com`);
    await page.getByLabel("Password (min. 12 characters)").fill("short1");
    await page.getByLabel("Confirm password").fill("short1");
    await page.getByLabel(/accept the POPIA/).check();

    // HTML5 minlength=12 should block native form submission.
    const passwordInput = page.getByLabel("Password (min. 12 characters)");
    const isValid = await passwordInput.evaluate((el: HTMLInputElement) => el.checkValidity());
    expect(isValid).toBe(false);
  });

  test("mismatched confirm-password shows an inline error, not a network call", async ({ page }) => {
    await page.goto("/register");
    await page.getByLabel("Full name").fill("Mismatch Tester");
    await page.getByLabel("Email").fill(`mismatch-${Date.now()}@example.com`);
    await page.getByLabel("Password (min. 12 characters)").fill("correct-horse-battery-1");
    await page.getByLabel("Confirm password").fill("different-password-123");
    await page.getByLabel(/accept the POPIA/).check();
    await page.getByRole("button", { name: "Create account" }).click();
    await expect(page.getByText("Passwords do not match.")).toBeVisible();
  });
});

test.describe("Document upload", () => {
  test("rejects a disallowed file type client-side", async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Email").fill(uniqueEmail);
    await page.getByLabel("Password").fill(password);
    await page.getByRole("button", { name: "Log in" }).click();
    await expect(page).toHaveURL(/\/dashboard$/);

    await page.goto("/dashboard/upload");
    const fileInput = page.locator('input[type="file"]');
    // Create a disallowed .txt file on the fly.
    await fileInput.setInputFiles({
      name: "not-allowed.txt",
      mimeType: "text/plain",
      buffer: Buffer.from("this is not a pdf/jpg/png"),
    });
    await page.getByRole("button", { name: "Upload" }).click();
    await expect(page.getByText("Upload failed")).toBeVisible();
  });

  test("uploads a real PDF end-to-end and gets a document id back", async ({ page, request }) => {
    // Log in fresh via the API to get a token for a direct API-level check
    // that the full pipeline (multer -> magic-byte check -> Prisma -> Postgres)
    // works, independent of the UI form.
    const loginRes = await request.post(`${API_URL}/api/v1/auth/login`, {
      data: { email: uniqueEmail, password },
    });
    expect(loginRes.ok()).toBeTruthy();
    const { accessToken } = await loginRes.json();

    const minimalPdf = Buffer.from("%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF");
    const uploadRes = await request.post(`${API_URL}/api/v1/documents`, {
      headers: { Authorization: `Bearer ${accessToken}` },
      multipart: { file: { name: "record.pdf", mimeType: "application/pdf", buffer: minimalPdf } },
    });
    expect(uploadRes.status()).toBe(201);
    const body = await uploadRes.json();
    expect(body.id).toBeTruthy();
    expect(body.virusScanStatus).toBe("pending");
  });
});

test.describe("Security / RBAC (backend, exercised directly)", () => {
  test("admin routes are unreachable without a token", async ({ request }) => {
    const res = await request.get(`${API_URL}/api/v1/admin/cases`);
    expect(res.status()).toBe(401);
  });

  test("an ordinary applicant cannot access admin routes even when authenticated", async ({ request }) => {
    const loginRes = await request.post(`${API_URL}/api/v1/auth/login`, {
      data: { email: uniqueEmail, password },
    });
    const { accessToken } = await loginRes.json();

    const res = await request.get(`${API_URL}/api/v1/admin/cases`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    expect(res.status()).toBe(403);
  });

  test("5 failed logins lock the account", async ({ request }) => {
    // NOTE: this account-lockout control (5 failed attempts) sits behind a
    // second, IP-level control: authRateLimit (10 auth requests / 15 min).
    // In a shared test run those two controls can interact — the rate
    // limiter may fire first and return 429 instead of the lockout's 401/423.
    // Both outcomes mean "brute force blocked"; this test accepts either so
    // it isn't flaky based on how many auth calls earlier tests made against
    // the same IP, while still asserting the account is unusable afterwards.
    const email = `lockout-${Date.now()}@example.com`;
    await request.post(`${API_URL}/api/v1/auth/register`, {
      data: { email, password, fullName: "Lockout Tester", acceptedPrivacyPolicy: true },
    });

    let lastStatus = 0;
    for (let i = 0; i < 5; i++) {
      const res = await request.post(`${API_URL}/api/v1/auth/login`, {
        data: { email, password: "wrong-password-attempt" },
      });
      lastStatus = res.status();
      if (lastStatus === 429) break; // rate limiter got there first
    }
    expect([401, 429]).toContain(lastStatus);

    // Correct password must NOT succeed now — either the account is locked
    // (423) or the IP is rate-limited (429). It must never be 200.
    const lockedRes = await request.post(`${API_URL}/api/v1/auth/login`, {
      data: { email, password },
    });
    expect([423, 429]).toContain(lockedRes.status());
  });

  test("security headers are present on every response", async ({ request }) => {
    const res = await request.get(`${API_URL}/health`);
    const headers = res.headers();
    expect(headers["x-content-type-options"]).toBe("nosniff");
    expect(headers["x-frame-options"]).toBeTruthy();
    expect(headers["strict-transport-security"]).toContain("max-age");
    expect(headers["content-security-policy"]).toContain("default-src 'self'");
  });
});
