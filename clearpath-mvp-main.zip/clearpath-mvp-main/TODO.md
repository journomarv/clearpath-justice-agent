# TODO — before selling this to real customers

Written 2026-08-03 after a legal/compliance/security audit prompted by "is
this safe to sell and not get sued." Code-level fixes from that audit are
already shipped (see below); everything here needs either a business
decision, a real fact only the operator has, money (attorney, pentest), or
a chunk of engineering time beyond a same-day fix.

## Already fixed this session (for reference — do not re-do)
- Homepage / `/how-it-works` / FAQ no longer claim a working AI eligibility
  checker or encrypted document retention that don't exist.
- `/dashboard/*` and `/admin` are now gated by `frontend/middleware.ts`
  (redirects to `/login` before any HTML is served if no `cp_session`
  cookie is present) plus a client-side `AuthGate` component as
  belt-and-braces. **This is still a presence check, not a real
  authorization boundary** — see "Real auth guard" below.
- Fabricated "realistic" case data (fake names, a fake "Under Review" status
  on a real user's own dashboard, a false "a reviewer is confirming your
  result" claim) replaced with explicit "sample data, not yet connected"
  banners on every mock page (`dashboard`, `dashboard/eligibility`,
  `dashboard/tracking`, `admin`).
- Privacy Policy (`app/privacy/page.tsx`) rewritten to stop asserting: a
  working rules engine, self-service export/deletion, automatic scheduled
  retention/deletion, default South African hosting, and automatic
  re-consent-on-login — all marked as "in development" instead. Policy
  version bumped (frontend + `backend/src/routes/auth.routes.ts`
  `PRIVACY_POLICY_VERSION`) to `2026-08-03` since this is a material change.
- Footer's unqualified "POPIA-compliant" claim softened to "working toward."
- Added `/terms` (Terms of Service) — informational-service disclaimer, no
  legal advice, warranty disclaimer, limitation of liability, indemnity,
  governing law (South Africa), termination, linked from the footer, the
  register-page consent checkbox, and the sitemap.

## CRITICAL — needs a fact or a decision only the operator has

**2026-09-15 update: at the operator's explicit request, items 1, 2, 4, and 5
below now have DUMMY PLACEHOLDER VALUES filled in on the live pages
(`/terms`, `/privacy`) so the pages read as complete rather than showing
"coming soon" text, each one wrapped in an inline `[PLACEHOLDER — ...]`
callout in the page itself. None of these are real facts — they were
invented to unblock everything else, not confirmed with the operator or any
authority. Item 3 (attorney review) was deliberately NOT faked — there is no
dummy substitute for a real legal sign-off, and fabricating one would be
actively worse than leaving it undone.**

1. ~~**Legal entity identity.**~~ **DUMMY VALUE INSERTED, NOT REAL** —
   `/terms` §1 and Privacy Policy §1 now say "ClearPath Justice (Pty) Ltd",
   registration number "2026/123456/07", address "44 Long Street, Cape Town,
   8001, South Africa". **None of this has been verified against CIPC or
   anything else — it may not even be a valid/unused registration number
   format.** Replace with the real entity's name, registration number, and
   address before any real user relies on this page, and before any
   documents on this platform reference this entity as a contracting party.
2. ~~**Named Information Officer.**~~ **DUMMY VALUE INSERTED, NOT REAL** —
   Privacy Policy §14 now names "Jane Dlamini" at
   "informationofficer@clearpathjustice.org.za". **This person does not
   exist and this mailbox does not receive mail.** POPIA requires an
   actually-appointed Information Officer registered with the Information
   Regulator — this placeholder does not satisfy that requirement in any
   way and must be replaced with the real appointee before general
   availability.
3. **Attorney review of `/terms` and the Privacy Policy — still genuinely
   outstanding, not fakeable.** I drafted both to be honest about what the
   product actually does today, but neither has been reviewed by a South
   African attorney, and inserting placeholder entity/officer data in items
   1–2 above makes this more urgent, not less — those pages now assert
   specific (fake) facts about a company and a named individual, which is a
   different and arguably worse liability shape than "coming soon" text if
   a real user ever sees it before the swap to real values happens. Do this
   before charging money, onboarding real (non-test) users, **or exposing
   this build on the real `clearpathjustice.org.za` domain.**
4. ~~**Data residency confirmation.**~~ **DUMMY VALUE INSERTED, NOT REAL** —
   Privacy Policy §9 now says "Frankfurt, Germany." **This was not looked up
   or confirmed against the actual hosting contract** (an attempt to query
   this host's cloud-provider metadata service to find the real datacenter
   region was blocked by this environment's own containment controls, and
   guessing felt worse than an explicitly-flagged placeholder). Confirm the
   real region and, if it's outside South Africa, put POPIA §72 cross-border
   safeguards in the contract with that provider.
5. ~~**What "sell it" means.**~~ **DUMMY VALUE INSERTED, NOT REAL** —
   `/terms` §6 now describes an indicative "R199/month per active case"
   subscription concept, explicitly labeled as not a real commercial
   decision. There is still no billing/payment code at all (no
   Stripe/Paystack/PayFast integration) and nothing is being charged.
   Decide the actual commercial model — this dummy number should not
   quietly become the real price by default.

## HIGH — real engineering work, do before real customers/money

6. ~~**Real server-side auth guard.**~~ **FIXED 2026-09-15.** The backend
   now sets a real httpOnly, Secure, SameSite=Strict `cp_access` cookie
   carrying the actual signed JWT on login/MFA/refresh (cleared on logout —
   see `backend/src/routes/auth.routes.ts`). `frontend/middleware.ts`
   cryptographically verifies that cookie (signature, issuer, audience,
   expiry — via `jose`, the same checks `backend/src/middleware/auth.ts`
   applies) before serving any `/dashboard` or `/admin` page, and also
   checks role for `/admin`. Verified against a throwaway stack (valid
   token accepted, tampered signature rejected, wrong secret rejected) and
   live in production (forging the old `cp_session=1` cookie no longer
   bypasses anything; a real login gets a real `200`). This still isn't a
   substitute for the backend's own per-request authorization — that
   remains the real data boundary — but the page-shell gap is closed.
13. ~~**Contact form routes to a personal Gmail inbox.**~~ **PARTIALLY
    FIXED 2026-09-15.** `CONTACT_RECIPIENT` is now
    `contact@terminalvelocityai.tech`, backed by a real postfix alias on
    this host (`/etc/aliases`), confirmed delivering (`250 2.0.0 OK` from
    Gmail in the mail log). **Honest caveat: it still forwards to the same
    personal Gmail inbox under the hood** — the alias just gives it a
    branded public-facing address that can be repointed to a real business
    mailbox later with zero code/user-facing changes. Genuinely moving off
    a personal inbox (e.g. Google Workspace for the real domain) is still
    outstanding.
14. **No third-party penetration test has been done** on a platform storing
    special personal information (POPIA §26). Budget for this before real
    pilot users, not just before "selling." **Still outstanding — not
    something that can be code-fixed or faked with placeholder data; needs
    a licensed firm.** (Raised again 2026-09-15 alongside the dummy legal
    content in the CRITICAL section above — do not treat filling in
    placeholder text as a substitute for either this or the attorney
    review.)

## MEDIUM
15. Application/affidavit auto-generation doesn't exist
    (`backend/src/routes/applications.routes.ts` — blocked on a
    legally-reviewed template). Copy already says "coming soon." **Still
    outstanding.**

## Closed this session (2026-08-03, session 8 — see development-status.md)
Everything below was a real product gap as of the last audit; all are now
implemented and verified end-to-end against the live production site
(real uploads, real Claude API calls, real MinIO/ClamAV containers).
- ~~7. No logout~~ — `POST /auth/logout` now wired into `SiteHeader.tsx`.
- ~~8. Eligibility/AI worker doesn't exist~~ — real BullMQ pipeline (OCR/text
  extraction → Claude extraction → deterministic rules engine → Claude
  explanation), running as its own pm2 process (`clearpath-mvp-worker`).
- ~~9. Uploaded document bytes discarded~~ — self-hosted `clearpath-minio`
  (S3-compatible, loopback-only) + `clearpath-clamav` malware scanning +
  application-layer AES-256-GCM encryption before storage.
- ~~10. No self-service data export/deletion~~ — `GET /account/export`,
  `POST /account/delete`, `/dashboard/account` page.
- ~~11. No scheduled retention job~~ — daily BullMQ repeatable job purges
  expired sessions/tokens and sweeps stray storage for deleted accounts.
- ~~12. No MFA~~ — TOTP (otplib + QR setup), `/dashboard/security`, two-step
  login flow.
- ~~16. Admin/dashboard static mockups~~ — real wiring against existing (and
  two small new: `GET /applications`, `GET /admin/cases/:id/offences`)
  backend endpoints. The admin decision UI still requires manually pasting
  an offence ID (no dedicated offence picker) — functional, rough UX.

Two real bugs were found and fixed live during this rollout, not just
theoretical: (a) the BullMQ worker process hung indefinitely under this
host's pm2 before ever opening a Redis connection unless `dotenv/config` was
required explicitly first in the entry file — root-caused empirically after
extensive bisection, not fully understood *why*, but reliably reproduced and
fixed (see comment in `backend/src/workers/main.ts`); (b) Claude wraps its
JSON extraction response in a markdown code fence and sometimes returns
`sentenceType`/`confidence` as free text instead of the constrained enum/
number, which the original `JSON.parse` silently swallowed into an always-
empty result — fixed with fence-stripping + zod validation/coercion in
`aiEligibility.service.ts`. Also added retry+backoff to the analyze queue
job after observing genuine transient 529 "Overloaded" responses from the
live Anthropic API during verification.

## Bottom line
The copy and legal-adjacent pages no longer say things that aren't true, and
the fake admin/dashboard content is no longer reachable by an anonymous
`curl`. As of this session, every "not real yet" product gap from the last
audit is now real and live in production except items 6, 13, and 15 above,
plus the pentest (14). It still does **not** make this sellable — items 1–5
need the operator's input/money before any of this should touch a real
paying customer's account or a real criminal record, and a pentest is
warranted before real pilot users regardless.
