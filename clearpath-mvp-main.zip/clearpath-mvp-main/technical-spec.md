# ClearPath Justice — Technical Specification

This document describes **how the system is built and run**. For *what it
does*, see `functional-spec.md`. For the full original design rationale,
see `/docs` (14 files); this document is the condensed, implementation-
facing version, kept in sync with what's actually deployed.

## 1. Architecture overview

```
Browser
   │  HTTPS
   ▼
nginx (Docker container "nginx-webstack", shared across the host's sites)
   ├─ /api/*  ──▶ Backend  (Express + TypeScript, pm2, port 4400)
   └─ /*      ──▶ Frontend (Next.js App Router, pm2, port 4401)

Backend ──▶ Postgres (Docker, persistent volume)
        ──▶ Redis (Docker, persistent volume) — job queue backing store
        ──▶ Claude API (Anthropic) — extraction / eligibility explanation
        ──▶ Object storage (planned — not yet wired, see §7)
```

## 2. Repository layout
```
docs/            Full 14-part MVP specification (product, security, roadmap, etc.)
backend/         Express + TypeScript API, Prisma schema, security middleware
frontend/        Next.js App Router site (marketing + dashboard + admin)
e2e/             Playwright end-to-end test suite (runs against real services)
ecosystem.config.js   pm2 process definitions for production
functional-spec.md    what the system does (this doc's companion)
development-status.md  live, session-by-session status — the source of truth
                        for "is X actually working right now"
```

## 3. Technology stack

| Layer | Choice | Why |
|---|---|---|
| Frontend | Next.js 14 (App Router), React, TypeScript | SSR for fast marketing pages + SEO; one framework for static site and app |
| Backend | Node.js + Express, TypeScript | Shared language with frontend; mature security-middleware ecosystem |
| Database | PostgreSQL via Prisma ORM | Strong relational integrity for case data; Prisma prevents raw-SQL injection by construction |
| Auth | Custom JWT (15 min access) + rotating httpOnly refresh cookie; Argon2id password hashing | Full control over session revocation — critical for instant logout on compromise |
| OCR | Cloud OCR (pluggable — e.g. AWS Textract / Google Document AI) | Not yet wired; see §7 |
| AI | Claude (Anthropic) | Structured extraction + long-context document handling + enterprise data-handling commitments |
| Job queue | BullMQ + Redis | Keeps OCR/AI/PDF work off the request path; caps AI-cost exposure via concurrency limits — worker not yet implemented |
| Process management | pm2 | Matches this host's existing convention for all other deployed sites |
| Reverse proxy | nginx (shared Docker container `nginx-webstack`) | One nginx serves every site on this host via per-domain `conf.d` files |
| TLS | Let's Encrypt wildcard cert (`*.terminalvelocityai.tech`) | Already provisioned for the parent domain; no per-subdomain cert needed |

## 4. Data model
See `docs/03-database-schema.md` for the full field-by-field design and
`backend/prisma/schema.prisma` for the authoritative, runnable schema.
Key tables: `users`, `sessions`, `documents`, `offences`,
`eligibility_assessments`, `rules_versions`, `applications`,
`application_notes`, `notifications`, `chat_messages`, `audit_logs`.

Fields marked `[ENCRYPTED]` in the schema doc (ID numbers, offence text, MFA
secrets, full names) are stored as AES-256-GCM ciphertext produced by
`backend/src/utils/encryption.ts` — application-level encryption layered on
top of the database's own encryption-at-rest.

## 5. API
See `docs/04-api-architecture.md` for the full endpoint list and async-job
design. All routes are versioned under `/api/v1`, mounted in
`backend/src/app.ts`:

| Route prefix | File | Access |
|---|---|---|
| `/api/v1/auth` | `routes/auth.routes.ts` | Public |
| `/api/v1/documents` | `routes/documents.routes.ts` | Authenticated |
| `/api/v1/eligibility` | `routes/eligibility.routes.ts` | Authenticated |
| `/api/v1/applications` | `routes/applications.routes.ts` | Authenticated |
| `/api/v1/admin` | `routes/admin.routes.ts` | `reviewer` / `admin` / `super_admin` (RBAC-enforced server-side) |

## 6. Security architecture
Full detail in `docs/08-security-architecture.md`. Summary of what's
actually implemented in code today:
- Argon2id password hashing (`src/utils/password.ts`).
- AES-256-GCM field-level encryption (`src/utils/encryption.ts`).
- JWT access tokens (15 min) + rotating httpOnly `SameSite=Strict` refresh
  cookies, with server-side session revocation (`sessions` table).
- RBAC middleware (`src/middleware/auth.ts`) enforced on every privileged
  route — never relies on client-side hiding.
- Append-only audit logging (`src/middleware/auditLog.ts`) on every
  security-relevant action.
- Helmet security headers, strict CSP, HSTS, tiered rate limiting
  (`src/middleware/security.ts`) — separate, tighter budgets for auth
  endpoints and AI endpoints.
- File-upload hardening: MIME allow-list + magic-byte verification + 10MB
  cap (`routes/documents.routes.ts`).
- Account lockout after 5 failed logins; generic error messages everywhere
  to prevent account enumeration.

**Framing note**: this MVP has no payment flow, so it is not literally in
PCI-DSS scope. The above is PCI-DSS's *control rigor* applied to POPIA
special-category data (criminal records, ID numbers). See
`docs/08-security-architecture.md` §0 for the reasoning and the recommended
path if payments are added later.

## 7. What's implemented vs. documented-but-not-yet-built
Kept honest and current in `development-status.md` — treat that file as
the live source of truth, not this one. As of this writing:

**Implemented and verified (Playwright E2E, 16/16, against real Postgres/Redis):**
marketing site, register/login/logout, account lockout, RBAC on admin
routes, document-upload validation + DB record + audit log, security
headers, dark-mode-default UI with a persisted theme toggle.

**Documented (API contract + service functions exist) but not yet wired:**
- BullMQ worker connecting the queue to `services/aiEligibility.service.ts`
- The deterministic eligibility rules engine itself (`rules_versions` table
  exists; nothing populates or evaluates it yet)
- Real encrypted object storage for uploaded file bytes (currently: hash +
  DB row only, no persisted file)
- MFA setup/verify and password-reset endpoints
- PDF template generation for the application + affidavit (blocked on
  attorney review of the templates — see `docs/13-risks-mitigations.md`)
- Frontend authenticated-route guards

## 8. Production deployment (live)
**https://clearpath-mvp.terminalvelocityai.tech**

| Component | Where | Notes |
|---|---|---|
| Frontend | pm2 `clearpath-mvp-frontend`, port 4401 | `next start`; built with `NEXT_PUBLIC_API_URL` baked in at build time — **never leave a `frontend/.env.local` in place**, it silently overrides the production build |
| Backend | pm2 `clearpath-mvp-backend`, port 4400 | `node dist/server.js`; secrets in `backend/.env.production` (chmod 600, not committed), loaded via `DOTENV_CONFIG_PATH` in `ecosystem.config.js` |
| Postgres | Docker `clearpath-postgres`, 127.0.0.1:55435, volume `clearpath_pg_data` | `--restart unless-stopped` |
| Redis | Docker `clearpath-redis`, 127.0.0.1:63794, volume `clearpath_redis_data` | `--restart unless-stopped` |
| nginx vhost | `/home/webadmin/web-stack/conf/conf.d/clearpath-mvp.terminalvelocityai.tech.conf` | `/api/*` → 4400, everything else → 4401; reuses the existing wildcard cert |
| Firewall | `ufw` allow rules for 4400/4401 from `172.17.0.0/16` | Required — without these the nginx container can't reach the app (504s). Every proxied app on this host needs its own rule. |

Redeploy after a code change:
```bash
cd backend  && npm run build && pm2 restart clearpath-mvp-backend
cd frontend && rm -rf .next .env.local && npm run build && pm2 restart clearpath-mvp-frontend
```

## 9. Testing
- `e2e/tests/clearpath.spec.ts` — Playwright, runs against real Postgres +
  Redis + both real servers. Covers marketing pages, the full
  register→login→dashboard journey, client-side validation, a real file
  upload round-trip, and RBAC/security-header/lockout checks. See
  `e2e/README.md` to reproduce locally.
- `backend/` has a `vitest` script declared but no unit test files yet —
  recommended first targets are `utils/encryption.ts` and
  `utils/password.ts` (a silent bug in either is a POPIA-grade problem).
- `tsc --noEmit` is clean in both `backend/` and `frontend/`.

## 10. Known open items
- `npm audit` residual "high" finding on `next`/`postcss` whose full fix
  needs a Next.js 16 major upgrade — deliberately deferred pending a
  considered decision (see `development-status.md`).
- Vitest's own dependency chain (`vite`/`esbuild`) has unresolved dev-only
  audit findings in `backend/` — not shipped, not yet cleaned up.
