# ClearPath Justice — Functional Specification

This document describes **what the system does** from a user's point of view:
who uses it, what they can do, and what the system's behavior guarantees are.
For screen-level detail see `docs/02-wireframes.md`; for the underlying
architecture see `tech-spec.md`.

## 1. Actors

| Actor | Description |
|---|---|
| **Applicant** | A member of the public checking eligibility for criminal record expungement and, if eligible, generating an application. |
| **Reviewer** | ClearPath staff or a partner paralegal/attorney who confirms or overrides AI eligibility results and approves generated documents. |
| **Admin** | Everything a Reviewer can do, plus manages the case queue/assignment and exports reports. |
| **Super Admin** | Everything an Admin can do, plus manages staff accounts/roles and can read raw audit logs. |

## 2. Functional areas

### 2.1a Quick cannabis-conviction screener (`/screener`, public, no login)
A separate, lightweight, 2-question wizard — distinct from the full
account-based AI Eligibility Checker — for the specific and currently
high-volume case of cannabis-related convictions under the Cannabis for
Private Purposes Act 7 of 2024 (CPPA):
1. "What was the conviction for?" → *use/possession*, *dealing/supply*, or
   *child diversion record*.
2. Depending on that answer: which law the conviction was under (for
   possession), or whether it was based on a quantity-based presumption of
   dealing rather than direct evidence (for dealing). Diversion records go
   straight to a result.
- Every branch ends in one of: likely eligible — automatic (CPPA s.5(1)),
  possibly eligible — needs an application (s.5(2)), not covered by
  section 5, not yet supported (diversion, s.5(2)(d)), or uncertain —
  needs more information, each with plain-language next steps.
- This tool is purely rules-based (no AI, no human review, no account, no
  data stored) and says so explicitly. It links into the full
  account-based checker (`/register`) when a result looks favorable.
- Modeled on the public reference implementation at
  clearpathjustice.org.za, adapted to ClearPath's own copy and design
  system.

### 2.1 Marketing site (public, unauthenticated)
- Home, About, How it Works, FAQ, and Contact pages.
- Every page carries a persistent disclaimer: ClearPath Justice is not a law
  firm and does not give legal advice.
- Dark mode is the default appearance site-wide; a toggle switch in the
  top-right of the header lets a visitor switch to light mode, and the
  choice is remembered (localStorage) for their next visit.

### 2.2 Account management
- **Register**: email + password + full name, with mandatory acceptance of
  the Privacy Policy (POPIA-consent, timestamped and versioned).
- **Log in** / **Log out**.
- **Reset password**: email-a-link flow. The system never reveals whether a
  given email address has an account (both "register" and "forgot password"
  return the same response regardless).
- Passwords must be 12–128 characters (length-based policy, not forced
  complexity rules).
- An account is temporarily locked after 5 consecutive failed login attempts.

### 2.3 Applicant dashboard
An applicant can:
- View and edit their profile.
- Upload a criminal record document (PDF, JPG, or PNG, up to 10MB).
- View extracted offence details and confirm or correct them before they
  feed into the eligibility check.
- View their AI-assisted eligibility result per offence: **Eligible**,
  **Not Eligible**, or **Uncertain**, each with a plain-language reason.
- Track their case through a fixed set of stages: **Submitted → Under
  Review → Waiting for Information → Approved / Rejected**.
- View and download generated documents (application + affidavit) — but
  only once a human Reviewer has approved them.
- Receive notifications (in-app + email) whenever their case status changes.
- Enter offence details by hand when AI extraction couldn't produce them
  (scanned/image-only document, AI not configured, or a failed extraction
  pass) — the manual entry goes through the same confirm-then-evaluate gate
  as an AI-extracted offence. (The AI Assistant chatbot described in earlier
  drafts of this spec was cut from MVP scope — see `docs/14-future-roadmap.md`.)

### 2.4 Eligibility checking — behavioral guarantees
This is the core of the product, and its behavior is intentionally
constrained:
1. **Extraction is not the same as a decision.** The AI extracts offence
   facts from the uploaded document; the applicant reviews and can correct
   that extraction before anything else happens.
2. **The eligibility verdict is decided by a deterministic, versioned rules
   table** encoding South African expungement law (waiting periods,
   excluded-offence schedules, sentence-type exclusions) — never by asking
   an LLM to "decide" eligibility. This makes every result explainable and
   reproducible after the fact.
3. **A human Reviewer must confirm or override every verdict** before an
   application document is generated. If the Reviewer disagrees with the AI
   recommendation, they must record a reason (this is itself an audited
   action).
4. **The applicant never sees "you are expunged."** The strongest statement
   the product ever makes is "you appear eligible / not eligible / uncertain
   under the Criminal Procedure Act — this is not a legal decision; only the
   Department of Justice & Constitutional Development can grant
   expungement."

### 2.5 Application generation
- Once a Reviewer confirms eligibility, the system pre-fills the DOJ&CD
  expungement application and a supporting affidavit from the confirmed
  offence data.
- The applicant reviews the generated documents before they are finalized.
- A Reviewer must approve the generated documents before they become
  downloadable to the applicant.
- ClearPath does not itself file the application with government — the
  applicant (or their attorney) lodges the approved, generated paperwork.

### 2.6 Reviewer / Admin workflow
- **Case queue**: list of cases, filterable by status/reviewer/date, with
  the AI's recommendation and confidence visible at a glance.
- **Case detail**: side-by-side view of the uploaded document, the AI's
  extraction, and its eligibility reasoning, with controls to confirm or
  override (with a required reason) each offence's verdict.
- **Document approval**: review generated application/affidavit; approve
  for the applicant, or request changes (which moves the case to "Waiting
  for Information" with a user-visible note explaining what's needed).
- **Status control**: advance a case through its lifecycle; every change
  auto-notifies the applicant.
- **Reports**: export case volume, status breakdown, turnaround time, and
  AI/Reviewer agreement rate as CSV/PDF, filterable by date range and
  outcome.

### 2.7 Super Admin
- Manage Reviewer/Admin accounts and roles.
- Read-only access to the full audit log (who did what, to what, when).

## 3. Cross-cutting behaviors

- **Notifications**: every case-status change, document approval, and
  request for more information triggers an in-app + email notification to
  the applicant.
- **Audit trail**: registration, login (success/failure), document
  upload/access, every AI eligibility run, every Reviewer decision or
  override, every status change, data export, and account deletion are all
  recorded in an append-only audit log.
- **Data rights**: an applicant can request an export of their data or
  delete their account at any time; both are POPIA data-subject-rights
  flows, not just UI buttons — see `docs/08-security-architecture.md` §6.
- **Accessibility**: WCAG 2.1 AA is the target across all screens.
- **Mobile-first**: every flow above must be usable on a low-end Android
  device on a 3G connection.

## 4. Explicitly out of scope for this release
See `docs/01-product-specification.md` §3 and `docs/14-future-roadmap.md`
for the full detail. In short: no direct government e-filing integration, no
Digital Certificate of Expungement / Digital Justice Passport, no payments,
no multi-language UI, no native mobile app, no law-firm/CAO multi-tenant
dashboards. All are planned phase-2+ additions built on top of this MVP's
data model without requiring a rearchitecture.

## 5. Current implementation status
This functional spec describes the intended product. As of this document's
last update, the following pieces are **specified and scaffolded but not
yet functionally complete** (see `development-status.md` for the live,
authoritative status):
- The OCR → AI-extraction → rules-engine → AI-explanation pipeline (API
  contract exists; the worker and rules engine itself do not yet).
- Real encrypted object storage for uploaded documents (uploads are
  recorded in the database; the file bytes are not yet persisted anywhere).
- MFA and password-reset endpoints.
- The generated legal document templates (require attorney review before
  they can be built).
- Frontend authenticated-route guards (dashboard/admin pages render, but do
  not yet redirect an unauthenticated visitor).

What **is** implemented and verified end-to-end: the marketing site,
registration/login/logout with account lockout, RBAC-gated admin routes,
document-upload plumbing (validation, hashing, DB record), the audit log,
and the dark-mode-default UI with a theme toggle — all confirmed working
against a real production deployment at
https://clearpath-mvp.terminalvelocityai.tech.
