import type { Metadata } from "next";

export const metadata: Metadata = { title: "Verify Passport", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

interface VerifyResult {
  valid: boolean;
  outcome?: "granted" | "refused" | "withdrawn";
  issuedAt?: string;
  revoked?: boolean;
}

const OUTCOME_LABELS: Record<string, string> = {
  granted: "Granted",
  refused: "Refused",
  withdrawn: "Withdrawn",
};

async function verify(id: string): Promise<VerifyResult> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/passport/${id}/verify`, {
      cache: "no-store",
    });
    if (!res.ok) return { valid: false };
    return res.json();
  } catch {
    return { valid: false };
  }
}

export default async function VerifyPassportPage({ params }: { params: { id: string } }) {
  const result = await verify(params.id);

  return (
    <article>
      <h1>Digital Justice Passport</h1>
      {result.valid ? (
        <div className="step-card">
          <p style={{ fontSize: "1.1rem", fontWeight: 600, color: "#166534" }}>Verified</p>
          <p>
            Outcome: <strong>{OUTCOME_LABELS[result.outcome ?? ""] ?? "Unknown"}</strong>
          </p>
          {result.issuedAt && <p>Issued: {new Date(result.issuedAt).toLocaleDateString()}</p>}
          <p style={{ color: "var(--color-text-muted)" }}>
            This confirms that a ClearPath Justice case reached this outcome. No offence, sentence,
            or personal record information is shared here.
          </p>
        </div>
      ) : (
        <div className="step-card">
          <p style={{ fontSize: "1.1rem", fontWeight: 600, color: "#991b1b" }}>Not verified</p>
          <p style={{ color: "var(--color-text-muted)" }}>
            This passport ID is invalid, revoked, or does not exist.
          </p>
        </div>
      )}
    </article>
  );
}
