import type { Metadata } from "next";

const TERMS_VERSION = "2026-08-03";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The terms governing your use of the ClearPath Justice website and early-access expungement-help service.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <article>
      <h1>Terms of Service</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        Version {TERMS_VERSION}. By creating an account or using this website, you agree to these terms.
      </p>

      <div className="disclaimer-banner">
        ClearPath Justice is in early access. It is not a law firm, does not provide legal advice, and does not
        guarantee any outcome. See section 3 for what this service does and does not do today.
      </div>

      <h2>1. Who these terms apply to</h2>
      <p>
        These terms govern your use of the ClearPath Justice website and account services (the "Service"), operated
        on a South African pilot basis by <strong>ClearPath Justice (Pty) Ltd</strong> (South African company
        registration number <strong>2026/123456/07</strong>), of <strong>44 Long Street, Cape Town, 8001, South
        Africa</strong>.{" "}
        <em>
          [PLACEHOLDER — this entity name, registration number, and address are placeholder values pending
          confirmation of the real registered entity; do not rely on them and do not treat this as a real company
          registration lookup]
        </em>{" "}
        Contact us via the <a href="/contact">Contact page</a> if you need the confirmed information sooner.
      </p>

      <h2>2. Eligibility to use the Service</h2>
      <p>
        You must be at least 18 years old and able to form a binding contract under South African law to register an
        account. Information you submit must relate to your own criminal record, or to a record you are legally
        authorized to act on behalf of (for example, as a legal guardian or appointed representative).
      </p>

      <h2>3. What the Service does and does not do</h2>
      <p>
        ClearPath Justice provides informational tools and administrative assistance related to South African
        criminal record expungement. <strong>It is not a law firm, does not employ your attorney, and nothing on this
        site is legal advice.</strong> Some features described elsewhere on this site are still in development and
        are explicitly marked as such where they appear — for example, automated eligibility analysis, self-service
        data export/deletion, and long-term encrypted document storage are not live yet. Any result, screener
        outcome, or status shown anywhere on the Service is either (a) a real result confirmed by a human, (b) the
        fixed decision-tree result of our Quick Screener, clearly labelled as such, or (c) illustrative sample data,
        clearly labelled as such. We do not guarantee that any application will be approved by the relevant government
        authority, or any particular processing time by that authority, both of which are outside our control.
      </p>

      <h2>4. Your account and information</h2>
      <p>
        You are responsible for keeping your login credentials confidential and for the accuracy of the information
        you provide. Notify us immediately via the <a href="/contact">Contact page</a> if you suspect unauthorized
        access to your account. See our <a href="/privacy">Privacy Policy</a> for how we handle your personal
        information.
      </p>

      <h2>5. Acceptable use</h2>
      <p>
        You agree not to: submit information you know to be false; attempt to access another user's account or data;
        attempt to interfere with, probe, or circumvent the Service's security controls; or use the Service for any
        unlawful purpose. We may suspend or terminate an account that violates this section.
      </p>

      <h2>6. Fees</h2>
      <p>
        The current early-access pilot is free to use. Our indicative post-pilot pricing plan (
        <em>
          [PLACEHOLDER — not yet a real commercial decision]: a free ASSESS/Quick Screener tier, plus an optional
          R199/month subscription per active case covering PREPARE/MANAGE/VERIFY tooling and reviewer time
        </em>
        ) is not yet in effect and is not being charged today. If we introduce paid features, we will tell you the
        confirmed price and get your agreement before charging you anything, and will update this section
        accordingly.
      </p>

      <h2>7. Intellectual property</h2>
      <p>
        The ClearPath Justice name, logo, and site content are owned by us or our licensors. You retain ownership of
        the documents and information you submit; you grant us a limited license to process that information solely
        to provide the Service to you, as described in our Privacy Policy.
      </p>

      <h2>8. Disclaimer of warranties</h2>
      <p>
        The Service is provided "as is" and "as available," without warranties of any kind, express or implied,
        including any warranty of accuracy, completeness, merchantability, fitness for a particular purpose, or
        non-infringement, to the maximum extent permitted by South African law.
      </p>

      <h2>9. Limitation of liability</h2>
      <p>
        To the maximum extent permitted by law, ClearPath Justice and its operators will not be liable for any
        indirect, incidental, special, or consequential damages arising from your use of the Service, or for any
        decision made by a government authority on an application you submit. Nothing in these terms limits liability
        that cannot be limited under South African law, including the Consumer Protection Act 68 of 2008 where it
        applies, or liability for gross negligence, fraud, or wilful misconduct.
      </p>

      <h2>10. Indemnification</h2>
      <p>
        You agree to indemnify and hold us harmless from any claim arising from your breach of these terms, your
        misuse of the Service, or information you submit that you were not authorized to submit.
      </p>

      <h2>11. Termination</h2>
      <p>
        You may stop using the Service and request account deletion at any time via the{" "}
        <a href="/contact">Contact page</a> — see our <a href="/privacy">Privacy Policy</a> for how deletion requests
        are handled. We may suspend or terminate your account for a violation of section 5, or discontinue the
        Service, with notice where reasonably possible.
      </p>

      <h2>12. Governing law and disputes</h2>
      <p>
        These terms are governed by the laws of the Republic of South Africa. Any dispute arising from these terms
        or the Service will be subject to the non-exclusive jurisdiction of the South African courts, without
        prejudice to any right you have to refer a matter to the Information Regulator, the National Consumer
        Commission, or another applicable regulator.
      </p>

      <h2>13. Changes to these terms</h2>
      <p>
        We may update these terms as the Service develops out of early access. The version date at the top of this
        page identifies the version currently in effect. Material changes will be posted here.
      </p>

      <h2>14. Contact us</h2>
      <p>
        Questions about these terms can be sent via our <a href="/contact">Contact page</a>.
      </p>
    </article>
  );
}
