"use client";

import { trackEvent } from "@/lib/analytics";

interface Resource {
  name: string;
  description: string;
  url: string;
  phone?: string;
}

const RESOURCES: { category: string; blurb: string; items: Resource[] }[] = [
  {
    category: "Department of Justice & Constitutional Development",
    blurb:
      "The authority that actually processes and decides expungement applications. ClearPath helps you prepare — the DOJ&CD is who submits and rules on it.",
    items: [
      {
        name: "DOJ&CD — Expungements",
        description: "Official process, eligibility criteria, and application forms.",
        url: "https://www.justice.gov.za/expungements.html",
      },
    ],
  },
  {
    category: "SAPS Criminal Record Centre",
    blurb:
      "Holds the criminal record database itself and issues Police Clearance Certificates. An approved expungement is actioned here.",
    items: [
      {
        name: "SAPS — Police Clearance Certificate",
        description: "How to apply for and track a police clearance certificate.",
        url: "https://www.saps.gov.za/services/applying_clearence_certificate.php",
      },
    ],
  },
  {
    category: "Legal Assistance",
    blurb: "Free or low-cost legal advice if your situation is complex or your application is contested.",
    items: [
      {
        name: "Legal Aid South Africa",
        description: "Free legal advice and representation for those who qualify. Toll-free advice line 0800 110 110.",
        url: "https://legal-aid.co.za/",
        phone: "0800 110 110",
      },
    ],
  },
  {
    category: "Advice Offices & Civil Society",
    blurb: "Organisations that specialise in reintegration support and can help with the practical side of an application.",
    items: [
      {
        name: "NICRO",
        description: "National Institute for Crime Prevention and the Reintegration of Offenders — expungement support and reintegration services.",
        url: "https://www.nicro.org.za/",
      },
    ],
  },
];

export default function ReferClient() {
  return (
    <>
      <section className="hero" style={{ paddingBottom: "1rem" }}>
        <span className="hero-eyebrow">Refer</span>
        <h1>Where to go next</h1>
        <p>
          ClearPath Justice is not the Department of Justice, SAPS, or a law
          firm — we help you prepare, but these are the organisations that
          actually decide and process your case.
        </p>
      </section>

      {RESOURCES.map((group) => (
        <section key={group.category} style={{ marginTop: "2rem" }}>
          <span className="section-kicker">{group.category}</span>
          <p style={{ color: "var(--color-text-muted)", marginTop: "-0.25rem" }}>{group.blurb}</p>
          <div className="steps">
            {group.items.map((item) => (
              <div className="step-card" key={item.name}>
                <h3 style={{ marginTop: 0 }}>{item.name}</h3>
                <p>{item.description}</p>
                {item.phone && (
                  <p style={{ margin: "0 0 0.5rem", color: "var(--color-text-muted)" }}>Phone: {item.phone}</p>
                )}
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-ghost"
                  onClick={() => trackEvent("referral_clicked", { referral: item.name })}
                >
                  Visit site →
                </a>
              </div>
            ))}
          </div>
        </section>
      ))}

      <section className="disclaimer-banner" style={{ marginTop: "2.5rem" }}>
        ClearPath Justice does not represent, and is not affiliated with, the
        Department of Justice, SAPS, or any organisation listed here. We link
        to them so you know where responsibility for your case actually
        lies.
      </section>
    </>
  );
}
