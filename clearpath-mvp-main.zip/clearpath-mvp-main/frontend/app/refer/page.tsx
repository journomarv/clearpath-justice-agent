import type { Metadata } from "next";
import ReferClient from "./ReferClient";

export const metadata: Metadata = {
  title: "Get Help & Referrals",
  description:
    "Where to go for criminal record relief in South Africa: the Department of Justice, SAPS Criminal Record Centre, Legal Aid SA, and advice offices.",
  alternates: { canonical: "/refer" },
};

export default function ReferPage() {
  return <ReferClient />;
}
