import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Product Walkthrough",
  description: "A full recorded walkthrough of ClearPath Justice — the public site, the applicant journey, and the backend API — with narration.",
  alternates: { canonical: "/demo" },
};

export default function DemoPage() {
  return (
    <article>
      <h1>Product Walkthrough</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        A narrated, end-to-end recording of ClearPath Justice as it actually runs today — the
        public site, the full applicant journey (Assess through Verify), the Digital Justice
        Passport, and a direct look at the backend API. Nothing here is staged or mocked; it&apos;s
        recorded against this live site.
      </p>

      <video
        controls
        preload="metadata"
        style={{ width: "100%", maxWidth: "960px", borderRadius: "8px", marginTop: "1rem" }}
      >
        <source src="/clearpath-demo.mp4" type="video/mp4" />
        Your browser doesn&apos;t support embedded video. You can{" "}
        <a href="/clearpath-demo.mp4">download the walkthrough directly</a> instead.
      </video>

      <p style={{ marginTop: "1rem" }}>
        <a href="/clearpath-demo.mp4" download>
          Download the video (MP4)
        </a>
      </p>

      <p style={{ marginTop: "2rem" }}>
        Ready to try it yourself? <Link href="/screener">Start the Quick Screener</Link> or{" "}
        <Link href="/register">create an account</Link>.
      </p>
    </article>
  );
}
