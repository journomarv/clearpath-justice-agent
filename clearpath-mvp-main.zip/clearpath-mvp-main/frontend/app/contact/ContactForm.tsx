"use client";

import { useState } from "react";

type Status = "idle" | "sending" | "sent" | "error";

export default function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setStatus("sending");

    const form = new FormData(e.currentTarget);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/contact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.get("name"),
          email: form.get("email"),
          message: form.get("message"),
          website: form.get("website") ?? "",
        }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => null);
        setError(body?.error?.message ?? "We couldn't send your message. Please try again.");
        setStatus("error");
        return;
      }
      setStatus("sent");
    } catch {
      setError("We couldn't reach the server. Please check your connection and try again.");
      setStatus("error");
    }
  }

  if (status === "sent") {
    return (
      <article>
        <h1>Thanks — we&apos;ve got your message</h1>
        <p>We&apos;ll get back to you at the email address you gave us.</p>
      </article>
    );
  }

  return (
    <article>
      <h1>Contact Us</h1>
      <p>Have a question that&apos;s not in the FAQ? Send us a message.</p>

      <div className="disclaimer-banner">
        Please don&apos;t include full criminal record details in this form. If you want your record assessed,
        create an account and upload it securely instead.
      </div>

      <form onSubmit={handleSubmit}>
        <label>
          Name
          <input type="text" name="name" required maxLength={200} autoComplete="name" />
        </label>
        <label>
          Email
          <input type="email" name="email" required maxLength={320} autoComplete="email" />
        </label>
        <label>
          Message
          <textarea name="message" required maxLength={5000} rows={5} />
        </label>

        {/* Honeypot: hidden from people, tempting to bots. Real submissions
            leave it empty; anything that fills it is dropped server-side. */}
        <div aria-hidden="true" style={{ position: "absolute", left: "-9999px" }}>
          <label>
            Website (leave blank)
            <input type="text" name="website" tabIndex={-1} autoComplete="off" />
          </label>
        </div>

        {error && <p style={{ color: "#f87171" }}>{error}</p>}
        <button type="submit" disabled={status === "sending"}>
          {status === "sending" ? "Sending…" : "Send"}
        </button>
      </form>
    </article>
  );
}
