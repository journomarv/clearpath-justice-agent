import type { Metadata } from "next";
import RegisterForm from "./RegisterForm";

export const metadata: Metadata = {
  title: "Create Your Account",
  description: "Register for a free ClearPath Justice account to check your eligibility for criminal record expungement in South Africa and track your application.",
  alternates: { canonical: "/register" },
};

export default function RegisterPage() {
  return <RegisterForm />;
}
