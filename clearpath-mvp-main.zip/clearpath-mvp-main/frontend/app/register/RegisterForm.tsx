"use client";

import { useState } from "react";

export default function RegisterForm() {
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = new FormData(e.currentTarget);

    if (form.get("password") !== form.get("confirmPassword")) {
      setError("Passwords do not match.");
      return;
    }
    if (!form.get("acceptedPrivacyPolicy")) {
      setError("You must accept the Privacy Policy to continue.");
      return;
    }

    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        fullName: form.get("fullName"),
        email: form.get("email"),
        password: form.get("password"),
        acceptedPrivacyPolicy: true,
      }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setError(body?.error?.message ?? "Something went wrong. Please try again.");
      return;
    }
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <article>
        <h1>Account created</h1>
        <p>
          Your account is ready. <a href="/login">Log in</a> to continue.
        </p>
      </article>
    );
  }

  return (
    <article>
      <h1>Create your account</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Full name
          <input type="text" name="fullName" required maxLength={200} />
        </label>
        <label>
          Email
          <input type="email" name="email" required maxLength={320} autoComplete="email" />
        </label>
        <label>
          Password (min. 12 characters)
          <input type="password" name="password" required minLength={12} maxLength={128} autoComplete="new-password" />
        </label>
        <label>
          Confirm password
          <input type="password" name="confirmPassword" required minLength={12} maxLength={128} autoComplete="new-password" />
        </label>
        <label style={{ flexDirection: "row", alignItems: "center", display: "flex", gap: "0.5rem" }}>
          <input type="checkbox" name="acceptedPrivacyPolicy" required style={{ width: "auto" }} />
          I accept the <a href="/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a> &amp;{" "}
          <a href="/terms" target="_blank" rel="noopener noreferrer">Terms of Service</a>
        </label>
        {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
        <button type="submit">Create account</button>
      </form>
    </article>
  );
}
