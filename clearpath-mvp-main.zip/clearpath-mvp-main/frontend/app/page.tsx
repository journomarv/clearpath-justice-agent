import Link from "next/link";

const JOURNEY = [
  {
    letter: "A",
    name: "Assess",
    status: "Live",
    body: "A preliminary screener explains the factors behind your result. It is not a legal determination.",
  },
  {
    letter: "P",
    name: "Prepare",
    status: "Partial",
    body: "See what information and documents you need. Upload exists today; automatic document analysis is still being built.",
  },
  {
    letter: "M",
    name: "Manage",
    status: "Live",
    body: "Your dashboard tracks your case status and timeline from submission through to outcome.",
  },
  {
    letter: "R",
    name: "Refer",
    status: "Live",
    body: "Clear links to the Department of Justice, SAPS, Legal Aid SA, and advice offices — the bodies who actually decide your case.",
  },
  {
    letter: "V",
    name: "Verify",
    status: "Live",
    body: "Record your reference number, submission date, and final outcome, and log your own correspondence. Once an outcome is recorded, issue a Digital Justice Passport — a shareable, privacy-preserving proof that your case reached an outcome, without exposing your offence or record.",
  },
];

export default function HomePage() {
  return (
    <>
      <section className="hero">
        <span className="hero-eyebrow">Free · Confidential · Reviewed by a human</span>
        <h1>Clear your record. Reopen your future.</h1>
        <p>
          Find out in minutes whether you qualify for criminal record
          expungement in South Africa — reviewed by a human before anything
          is submitted.
        </p>
        <div style={{ display: "flex", gap: "0.85rem", justifyContent: "center", flexWrap: "wrap", marginTop: "1.75rem" }}>
          <Link href="/register" className="btn-primary" style={{ marginTop: 0 }}>Check My Eligibility</Link>
          <Link href="/how-it-works" className="btn-ghost">See how it works</Link>
          <Link href="/demo" className="btn-ghost">Watch the walkthrough ▶</Link>
        </div>
      </section>

      <section
        className="step-card"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1rem",
          alignItems: "center",
          justifyContent: "space-between",
          borderColor: "var(--color-accent-border)",
          background: "linear-gradient(135deg, var(--color-accent-soft), var(--color-surface) 60%)",
        }}
      >
        <div>
          <span className="section-kicker">Fast track</span>
          <h3 style={{ margin: "0 0 0.35rem" }}>Got a cannabis-related conviction?</h3>
          <p style={{ margin: 0, color: "var(--color-text-muted)" }}>
            Try our quick 2-question screener for cannabis possession or dealing convictions under the CPPA —
            no account needed.
          </p>
        </div>
        <Link href="/screener" className="btn-accent" style={{ whiteSpace: "nowrap" }}>
          Quick Screener →
        </Link>
      </section>

      <section style={{ marginTop: "3rem" }}>
        <span className="section-kicker">Our process</span>
        <h2>Assess → Prepare → Manage → Refer → Verify</h2>
        <p style={{ color: "var(--color-text-muted)", marginTop: "-0.5rem" }}>
          ClearPath assists; it does not adjudicate. Every step below is
          labeled with what&apos;s actually live today.
        </p>
        <div className="steps">
          {JOURNEY.map((step) => (
            <div className="step-card" key={step.letter}>
              <span className="step-num">{step.letter}</span>
              <h3>
                {step.name}{" "}
                <span style={{ fontSize: "0.7rem", fontWeight: 600, color: "var(--color-text-muted)" }}>
                  · {step.status}
                </span>
              </h3>
              <p>{step.body}</p>
            </div>
          ))}
        </div>
        <p style={{ marginTop: "1rem" }}>
          <Link href="/refer">See who to contact next →</Link>
        </p>
      </section>

      <section style={{ marginTop: "3rem" }}>
        <span className="section-kicker">Live today</span>
        <h2>How it works</h2>
        <p style={{ color: "var(--color-text-muted)", marginTop: "-0.5rem" }}>
          ClearPath Justice is in early access. Here&apos;s what&apos;s live
          today and what&apos;s still being built.
        </p>
        <div className="steps">
          <div className="step-card">
            <span className="step-num">1</span>
            <h3>Cannabis conviction? Get an instant answer</h3>
            <p>
              Our <Link href="/screener">Quick Screener</Link> gives an
              immediate result for cannabis possession or dealing convictions
              under the CPPA — no account needed.
            </p>
          </div>
          <div className="step-card">
            <span className="step-num">2</span>
            <h3>Other offences: register &amp; talk to our team</h3>
            <p>
              Create an account and reach out through our{" "}
              <Link href="/contact">Contact page</Link> — a real person will
              walk you through your eligibility for other types of
              expungement.
            </p>
          </div>
          <div className="step-card">
            <span className="step-num">3</span>
            <h3>Coming soon: automated AI review &amp; application generation</h3>
            <p>
              We&apos;re building automatic offence extraction and
              application/affidavit generation. Document upload exists today,
              but files aren&apos;t yet processed automatically or retained
              long-term — automated review isn&apos;t live yet.
            </p>
          </div>
        </div>
      </section>

      <section className="disclaimer-banner" style={{ marginTop: "2.5rem" }}>
        ClearPath Justice is not a law firm and does not provide legal advice.
        Every AI recommendation is reviewed by a human before it becomes your
        final result.
      </section>
    </>
  );
}
