import type { Metadata } from "next";
import CaseDetailClient from "./CaseDetailClient";

export const metadata: Metadata = {
  title: "Case Detail",
  robots: { index: false, follow: false },
};

export default function CaseDetailPage({ params }: { params: { id: string } }) {
  return <CaseDetailClient caseId={params.id} />;
}
