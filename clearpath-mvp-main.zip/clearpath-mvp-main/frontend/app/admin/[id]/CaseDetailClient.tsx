"use client";

import { useEffect, useState } from "react";
import { apiFetchJson, apiFetch } from "@/lib/auth";

interface CaseDetail {
  id: string;
  status: string;
  userId: string;
  assignedReviewerId: string | null;
  createdAt: string;
}

interface OffenceRow {
  id: string;
  offenceDescription: string;
  offenceDate: string | null;
  sentenceType: string | null;
  userConfirmed: boolean;
  latestAssessment: {
    id: string;
    aiRecommendation: string;
    aiReasoning: string;
    finalDecision: string | null;
    decidedAt: string | null;
  } | null;
}

const STATUSES = ["submitted", "under_review", "waiting_for_information", "approved", "rejected"];

export default function CaseDetailClient({ caseId }: { caseId: string }) {
  const [caseDetail, setCaseDetail] = useState<CaseDetail | null>(null);
  const [offences, setOffences] = useState<OffenceRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const [statusValue, setStatusValue] = useState("");
  const [decisionOffenceId, setDecisionOffenceId] = useState("");
  const [decision, setDecision] = useState<"eligible" | "not_eligible" | "uncertain">("eligible");
  const [overrideReason, setOverrideReason] = useState("");

  function load() {
    apiFetchJson<CaseDetail>(`/api/v1/admin/cases/${caseId}`)
      .then((c) => {
        setCaseDetail(c);
        setStatusValue(c.status);
      })
      .catch((err) => setError(err.message));
    apiFetchJson<{ offences: OffenceRow[] }>(`/api/v1/admin/cases/${caseId}/offences`)
      .then((body) => setOffences(body.offences))
      .catch((err) => setError(err.message));
  }

  useEffect(load, [caseId]);

  async function handleStatusChange(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    const res = await apiFetch(`/api/v1/admin/cases/${caseId}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status: statusValue }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setError(body?.error?.message ?? "Could not update status.");
      return;
    }
    setMessage("Status updated.");
    load();
  }

  async function handleDecision(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    const res = await apiFetch(`/api/v1/admin/cases/${caseId}/decision`, {
      method: "POST",
      body: JSON.stringify({
        offenceId: decisionOffenceId,
        decision,
        ...(overrideReason ? { overrideReason } : {}),
      }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setError(body?.error?.message ?? "Could not record decision.");
      return;
    }
    setMessage("Decision recorded.");
    setOverrideReason("");
    load();
  }

  if (error && !caseDetail) return <article><h1>Case Detail</h1><p style={{ color: "#b91c1c" }}>{error}</p></article>;
  if (!caseDetail) return <article><h1>Case Detail</h1><p>Loading...</p></article>;

  return (
    <article>
      <h1>Case {caseDetail.id.slice(0, 8)}</h1>
      {message && <p style={{ color: "#16a34a" }}>{message}</p>}
      {error && <p style={{ color: "#b91c1c" }}>{error}</p>}

      <section className="step-card" style={{ marginBottom: "1.5rem" }}>
        <h3>Status</h3>
        <p>Current: <span className="status-badge">{caseDetail.status}</span></p>
        <form onSubmit={handleStatusChange}>
          <label>
            Change status
            <select value={statusValue} onChange={(e) => setStatusValue(e.target.value)}>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>
          <button type="submit">Update status</button>
        </form>
      </section>

      <section className="step-card" style={{ marginBottom: "1.5rem" }}>
        <h3>Offences</h3>
        {!offences && <p>Loading...</p>}
        {offences && offences.length === 0 && <p style={{ color: "var(--color-text-muted)" }}>No offences on file for this applicant yet.</p>}
        {offences?.map((o) => (
          <div key={o.id} style={{ borderTop: "1px solid var(--color-border)", paddingTop: "0.75rem", marginTop: "0.75rem" }}>
            <p><strong>{o.offenceDescription}</strong> ({o.id.slice(0, 8)})</p>
            <p style={{ color: "var(--color-text-muted)" }}>
              Confirmed by user: {o.userConfirmed ? "yes" : "no"}
              {o.offenceDate && ` — ${new Date(o.offenceDate).toLocaleDateString()}`}
              {o.sentenceType && ` — ${o.sentenceType}`}
            </p>
            {o.latestAssessment ? (
              <p>
                AI recommendation: <strong>{o.latestAssessment.aiRecommendation}</strong>
                {o.latestAssessment.finalDecision && ` — final: ${o.latestAssessment.finalDecision}`}
                <br />
                {o.latestAssessment.aiReasoning}
              </p>
            ) : (
              <p style={{ color: "var(--color-text-muted)" }}>No eligibility assessment yet.</p>
            )}
          </div>
        ))}
      </section>

      <section className="step-card">
        <h3>Record a decision</h3>
        <form onSubmit={handleDecision}>
          <label>
            Offence ID
            <input
              type="text"
              required
              value={decisionOffenceId}
              onChange={(e) => setDecisionOffenceId(e.target.value)}
              placeholder="Paste an offence ID from above"
            />
          </label>
          <label>
            Decision
            <select value={decision} onChange={(e) => setDecision(e.target.value as typeof decision)}>
              <option value="eligible">Eligible</option>
              <option value="not_eligible">Not eligible</option>
              <option value="uncertain">Uncertain</option>
            </select>
          </label>
          <label>
            Override reason (required if disagreeing with the AI recommendation)
            <input type="text" value={overrideReason} onChange={(e) => setOverrideReason(e.target.value)} />
          </label>
          <button type="submit">Record decision</button>
        </form>
      </section>
    </article>
  );
}
