"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiFetchJson } from "@/lib/auth";

interface CaseRow {
  id: string;
  status: string;
  assignedReviewerId: string | null;
  createdAt: string;
  userId: string;
}

export default function AdminQueueClient() {
  const [cases, setCases] = useState<CaseRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetchJson<{ cases: CaseRow[] }>("/api/v1/admin/cases")
      .then((body) => setCases(body.cases))
      .catch((err) => setError(err.message));
  }, []);

  return (
    <article>
      <h1>Case Queue</h1>
      <p><Link href="/admin/analytics">View pilot analytics →</Link></p>
      {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
      {!cases && !error && <p>Loading...</p>}
      {cases && cases.length === 0 && <p style={{ color: "var(--color-text-muted)" }}>No cases yet.</p>}
      {cases && cases.length > 0 && (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ textAlign: "left", borderBottom: "2px solid #e5e7eb" }}>
              <th style={{ padding: "0.5rem" }}>Case ID</th>
              <th>Status</th>
              <th>Assigned Reviewer</th>
              <th>Created</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {cases.map((c) => (
              <tr key={c.id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                <td style={{ padding: "0.5rem" }}>{c.id.slice(0, 8)}</td>
                <td><span className="status-badge">{c.status}</span></td>
                <td>{c.assignedReviewerId ?? "Unassigned"}</td>
                <td>{new Date(c.createdAt).toLocaleDateString()}</td>
                <td><a href={`/admin/${c.id}`}>Open &rarr;</a></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </article>
  );
}
