import type { Metadata } from "next";
import AdminQueueClient from "./AdminQueueClient";

// Internal reviewer/admin surface — never indexed, never crawled.
export const metadata: Metadata = {
  title: "Case Queue",
  robots: { index: false, follow: false },
};

export default function AdminQueuePage() {
  return <AdminQueueClient />;
}
