"use client";

import { useEffect, useState } from "react";
import { apiFetchJson } from "@/lib/auth";

interface Summary {
  windowDays: number;
  funnel: Record<string, number>;
  casesByStage: { status: string; count: number }[];
  assessmentOutcomes: { outcome: string | null; count: number }[];
  totalCases: number;
  totalAssessments: number;
}

const FUNNEL_STEPS = [
  "visitor",
  "assessment_started",
  "assessment_completed",
  "pathway_identified",
  "action_plan_generated",
  "case_created",
  "referral_clicked",
];

const FUNNEL_LABELS: Record<string, string> = {
  visitor: "Visitors",
  assessment_started: "Assessment Started",
  assessment_completed: "Assessment Completed",
  pathway_identified: "Pathway Identified",
  action_plan_generated: "Action Plan Generated",
  case_created: "Case Created",
  referral_clicked: "Referral Clicked",
};

export default function AnalyticsSummaryClient() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetchJson<Summary>("/api/v1/admin/analytics/summary")
      .then(setSummary)
      .catch((err) => setError(err.message));
  }, []);

  return (
    <article>
      <h1>Pilot Analytics</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        Aggregate counts only — no names, ID numbers, or case-level detail.
      </p>
      {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
      {!summary && !error && <p>Loading...</p>}

      {summary && (
        <>
          <section style={{ marginBottom: "2rem" }}>
            <h2>Journey funnel (last {summary.windowDays} days)</h2>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                {FUNNEL_STEPS.map((key) => (
                  <tr key={key} style={{ borderBottom: "1px solid #e5e7eb" }}>
                    <td style={{ padding: "0.5rem" }}>{FUNNEL_LABELS[key]}</td>
                    <td style={{ padding: "0.5rem", textAlign: "right", fontWeight: 600 }}>
                      {summary.funnel[key] ?? 0}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          <section style={{ marginBottom: "2rem" }}>
            <h2>Cases by stage</h2>
            <p style={{ color: "var(--color-text-muted)" }}>{summary.totalCases} total cases</p>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                {summary.casesByStage.map((row) => (
                  <tr key={row.status} style={{ borderBottom: "1px solid #e5e7eb" }}>
                    <td style={{ padding: "0.5rem" }}>{row.status}</td>
                    <td style={{ padding: "0.5rem", textAlign: "right", fontWeight: 600 }}>{row.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          <section>
            <h2>Assessment outcomes</h2>
            <p style={{ color: "var(--color-text-muted)" }}>{summary.totalAssessments} total assessments</p>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                {summary.assessmentOutcomes.map((row) => (
                  <tr key={row.outcome ?? "unknown"} style={{ borderBottom: "1px solid #e5e7eb" }}>
                    <td style={{ padding: "0.5rem" }}>{row.outcome ?? "Unknown"}</td>
                    <td style={{ padding: "0.5rem", textAlign: "right", fontWeight: 600 }}>{row.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </>
      )}
    </article>
  );
}
