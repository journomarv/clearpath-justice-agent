import type { Metadata } from "next";
import AnalyticsSummaryClient from "./AnalyticsSummaryClient";

export const metadata: Metadata = {
  title: "Analytics",
  robots: { index: false, follow: false },
};

export default function AdminAnalyticsPage() {
  return <AnalyticsSummaryClient />;
}
