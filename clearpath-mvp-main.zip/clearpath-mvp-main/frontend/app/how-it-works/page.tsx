import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "How it Works",
  description: "ClearPath Justice is in early access: an instant cannabis-conviction screener and human-reviewed help are live today, with automated AI analysis and application generation still in development.",
  alternates: { canonical: "/how-it-works" },
};

const liveSteps = [
  { title: "1. Quick Screener (cannabis convictions)", body: "Answer two questions about a cannabis possession or dealing conviction and get an instant, plain-language result under the CPPA. No account needed." },
  { title: "2. Register", body: "Create a secure account in under a minute." },
  { title: "3. Upload your criminal record", body: "Upload a PDF, JPG, or PNG of your SAPS criminal record. We store the file's metadata and checksum now; automated processing of the file itself is not live yet (see below)." },
  { title: "4. Talk to a human reviewer", body: "For anything other than a cannabis conviction, contact our team directly and a reviewer will assess your case and explain your options." },
];

const upcomingSteps = [
  { title: "AI analysis", body: "Automatic extraction of offence details from an uploaded record, checked against expungement law and flagged for anything uncertain." },
  { title: "Eligibility result", body: "Which offences appear eligible, not eligible, or uncertain, with plain-language reasons — generated automatically instead of by manual review." },
  { title: "Application generated", body: "Your expungement application and affidavit pre-filled automatically for your review." },
  { title: "Case tracking dashboard", body: "Follow your case from Submitted through to a final decision, and download finalized documents, in one place." },
];

export default function HowItWorksPage() {
  return (
    <article>
      <h1>How it Works</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        ClearPath Justice is in early access. The steps below are live today.
        A fully automated AI review and application pipeline is in
        development — see what&apos;s coming next further down this page.
      </p>
      <div className="steps">
        {liveSteps.map((s) => (
          <div className="step-card" key={s.title}>
            <h3>{s.title}</h3>
            <p>{s.body}</p>
          </div>
        ))}
      </div>

      <h2 style={{ marginTop: "2.5rem" }}>Coming soon</h2>
      <p style={{ color: "var(--color-text-muted)" }}>
        These are in active development and are not yet available. Until they
        ship, offence review and application preparation happen through
        direct <Link href="/contact">contact</Link> with our team rather than
        automatically.
      </p>
      <div className="steps">
        {upcomingSteps.map((s) => (
          <div className="step-card" key={s.title}>
            <h3>{s.title}</h3>
            <p>{s.body}</p>
          </div>
        ))}
      </div>
    </article>
  );
}
