"use client";

import { useState } from "react";

function authHeaders(): HeadersInit {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${sessionStorage.getItem("accessToken") ?? ""}`,
  };
}

type Step = "idle" | "setup" | "verify";

export default function SecurityForm() {
  const [step, setStep] = useState<Step>("idle");
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string | null>(null);
  const [otpauthUrl, setOtpauthUrl] = useState<string | null>(null);
  const [verifyCode, setVerifyCode] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [disablePassword, setDisablePassword] = useState("");
  const [disableCode, setDisableCode] = useState("");

  async function startSetup() {
    setError(null);
    setMessage(null);
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/mfa/setup`, {
      method: "POST",
      headers: authHeaders(),
      credentials: "include",
    });
    const body = await res.json();
    if (!res.ok) {
      setError(body?.error?.message ?? "Could not start MFA setup.");
      return;
    }
    setQrCodeDataUrl(body.qrCodeDataUrl);
    setOtpauthUrl(body.otpauthUrl);
    setStep("verify");
  }

  async function confirmSetup(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/mfa/verify`, {
      method: "POST",
      headers: authHeaders(),
      credentials: "include",
      body: JSON.stringify({ code: verifyCode }),
    });
    const body = await res.json();
    if (!res.ok) {
      setError(body?.error?.message ?? "Incorrect code.");
      return;
    }
    setMessage("MFA is now enabled on your account.");
    setStep("idle");
    setQrCodeDataUrl(null);
    setVerifyCode("");
  }

  async function disableMfa(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/mfa/disable`, {
      method: "POST",
      headers: authHeaders(),
      credentials: "include",
      body: JSON.stringify({ password: disablePassword, code: disableCode }),
    });
    const body = await res.json();
    if (!res.ok) {
      setError(body?.error?.message ?? "Could not disable MFA.");
      return;
    }
    setMessage("MFA has been disabled.");
    setDisablePassword("");
    setDisableCode("");
  }

  return (
    <>
      <h1>Security</h1>

      <section className="step-card" style={{ marginBottom: "1.5rem" }}>
        <h3>Two-factor authentication (TOTP)</h3>
        <p style={{ color: "var(--color-text-muted)" }}>
          Add an authenticator app (Google Authenticator, Authy, etc.) as a second factor
          on your account.
        </p>

        {message && <p style={{ color: "#16a34a" }}>{message}</p>}
        {error && <p style={{ color: "#b91c1c" }}>{error}</p>}

        {step === "idle" && (
          <button type="button" onClick={startSetup}>Set up two-factor authentication</button>
        )}

        {step === "verify" && qrCodeDataUrl && (
          <div>
            <p>Scan this QR code in your authenticator app, then enter the 6-digit code it shows:</p>
            {/* eslint-disable-next-line @next/next/no-img-element -- data: URL, not an optimizable remote image */}
            <img src={qrCodeDataUrl} alt="MFA setup QR code" width={200} height={200} />
            {otpauthUrl && <p style={{ fontSize: "0.8rem", wordBreak: "break-all" }}>{otpauthUrl}</p>}
            <form onSubmit={confirmSetup}>
              <label>
                6-digit code
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  required
                  value={verifyCode}
                  onChange={(e) => setVerifyCode(e.target.value)}
                />
              </label>
              <button type="submit">Confirm and enable</button>
            </form>
          </div>
        )}
      </section>

      <section className="step-card">
        <h3>Disable two-factor authentication</h3>
        <p style={{ color: "var(--color-text-muted)" }}>
          Requires your current password and a valid code from your authenticator app.
        </p>
        <form onSubmit={disableMfa}>
          <label>
            Password
            <input
              type="password"
              required
              value={disablePassword}
              onChange={(e) => setDisablePassword(e.target.value)}
              autoComplete="current-password"
            />
          </label>
          <label>
            6-digit code
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              required
              value={disableCode}
              onChange={(e) => setDisableCode(e.target.value)}
            />
          </label>
          <button type="submit">Disable two-factor authentication</button>
        </form>
      </section>
    </>
  );
}
