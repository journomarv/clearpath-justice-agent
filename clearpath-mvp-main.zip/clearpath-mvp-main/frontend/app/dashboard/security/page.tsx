import type { Metadata } from "next";
import SecurityForm from "./SecurityForm";

export const metadata: Metadata = {
  title: "Security",
  robots: { index: false, follow: false },
};

export default function SecurityPage() {
  return <SecurityForm />;
}
