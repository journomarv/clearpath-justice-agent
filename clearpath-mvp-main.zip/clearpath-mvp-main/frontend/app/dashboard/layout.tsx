import type { Metadata } from "next";
import AuthGate from "@/components/AuthGate";

// Applies to every /dashboard/* route: this is a private, per-user area
// with no reason to appear in search results, and nothing here should be
// crawled or have its links followed.
export const metadata: Metadata = {
  robots: { index: false, follow: false },
};

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return <AuthGate>{children}</AuthGate>;
}
