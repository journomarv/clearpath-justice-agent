"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

function authHeaders(): HeadersInit {
  return { Authorization: `Bearer ${sessionStorage.getItem("accessToken") ?? ""}` };
}

export default function AccountForm() {
  const router = useRouter();
  const [exportStatus, setExportStatus] = useState<"idle" | "working" | "error">("idle");
  const [deletePassword, setDeletePassword] = useState("");
  const [confirmText, setConfirmText] = useState("");
  const [deleteStatus, setDeleteStatus] = useState<"idle" | "working" | "error">("idle");
  const [deleteError, setDeleteError] = useState<string | null>(null);

  async function handleExport() {
    setExportStatus("working");
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/account/export`, {
      headers: authHeaders(),
      credentials: "include",
    });
    if (!res.ok) {
      setExportStatus("error");
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "clearpath-data-export.json";
    a.click();
    URL.revokeObjectURL(url);
    setExportStatus("idle");
  }

  async function handleDelete(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setDeleteError(null);
    if (confirmText !== "DELETE") {
      setDeleteError('Type "DELETE" to confirm.');
      return;
    }
    setDeleteStatus("working");
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/account/delete`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      credentials: "include",
      body: JSON.stringify({ password: deletePassword }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setDeleteError(body?.error?.message ?? "Could not delete account. Check your password and try again.");
      setDeleteStatus("error");
      return;
    }
    sessionStorage.removeItem("accessToken");
    document.cookie = "cp_session=; path=/; max-age=0";
    router.push("/");
  }

  return (
    <>
      <h1>Account &amp; Data</h1>

      <section className="step-card" style={{ marginBottom: "1.5rem" }}>
        <h3>Export your data</h3>
        <p style={{ color: "var(--color-text-muted)" }}>
          Download everything ClearPath holds about your account as a single JSON file
          (POPIA right of access).
        </p>
        <button type="button" onClick={handleExport} disabled={exportStatus === "working"}>
          {exportStatus === "working" ? "Preparing download..." : "Export my data"}
        </button>
        {exportStatus === "error" && (
          <p style={{ color: "#b91c1c" }}>Export failed. Please try again or contact us.</p>
        )}
      </section>

      <section className="step-card" style={{ borderColor: "#b91c1c" }}>
        <h3>Delete your account</h3>
        <p style={{ color: "var(--color-text-muted)" }}>
          This permanently deletes your uploaded documents and anonymizes your account
          (POPIA right of erasure). This cannot be undone.
        </p>
        <form onSubmit={handleDelete}>
          <label>
            Current password
            <input
              type="password"
              required
              value={deletePassword}
              onChange={(e) => setDeletePassword(e.target.value)}
              autoComplete="current-password"
            />
          </label>
          <label>
            Type DELETE to confirm
            <input
              type="text"
              required
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
            />
          </label>
          {deleteError && <p style={{ color: "#b91c1c" }}>{deleteError}</p>}
          <button type="submit" disabled={deleteStatus === "working"} style={{ background: "#b91c1c" }}>
            {deleteStatus === "working" ? "Deleting..." : "Delete my account"}
          </button>
        </form>
      </section>
    </>
  );
}
