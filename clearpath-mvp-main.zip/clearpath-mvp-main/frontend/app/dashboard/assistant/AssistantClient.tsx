"use client";

import { useState } from "react";
import { apiFetchJson } from "@/lib/auth";

interface Turn {
  role: "user" | "assistant";
  content: string;
}

const MAX_HISTORY = 10;

export default function AssistantClient() {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function send() {
    const message = input.trim();
    if (!message || sending) return;

    setError(null);
    setSending(true);
    setInput("");
    const nextTurns: Turn[] = [...turns, { role: "user", content: message }];
    setTurns(nextTurns);

    try {
      const body = await apiFetchJson<{ reply: string }>("/api/v1/assistant/message", {
        method: "POST",
        body: JSON.stringify({ message, history: turns.slice(-MAX_HISTORY) }),
      });
      setTurns([...nextTurns, { role: "assistant", content: body.reply }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="step-card" style={{ marginTop: "1rem" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem", minHeight: "200px" }}>
        {turns.length === 0 && (
          <p style={{ color: "var(--color-text-muted)" }}>
            Try: &ldquo;What does an SAPS clearance certificate look like?&rdquo; or &ldquo;What
            do I still need to prepare my application?&rdquo;
          </p>
        )}
        {turns.map((turn, i) => (
          <div key={i} style={{ alignSelf: turn.role === "user" ? "flex-end" : "flex-start", maxWidth: "85%" }}>
            <strong style={{ fontSize: "0.75rem", color: "var(--color-text-muted)" }}>
              {turn.role === "user" ? "You" : "Assistant"}
            </strong>
            <p style={{ margin: 0, whiteSpace: "pre-wrap" }}>{turn.content}</p>
          </div>
        ))}
        {sending && <p style={{ color: "var(--color-text-muted)" }}>Thinking...</p>}
        {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        style={{ display: "flex", gap: "0.5rem", marginTop: "1rem" }}
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask a question..."
          maxLength={2000}
          style={{ flex: 1, padding: "0.5rem" }}
          disabled={sending}
        />
        <button type="submit" disabled={sending || !input.trim()}>
          Send
        </button>
      </form>
    </div>
  );
}
