import type { Metadata } from "next";
import AssistantClient from "./AssistantClient";

export const metadata: Metadata = { title: "Assistant", robots: { index: false, follow: false } };

export default function AssistantPage() {
  return (
    <>
      <h1>ClearPath Assistant</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        Ask about the process, your documents, or what to do next. The assistant explains and
        guides — it does not decide your eligibility or represent DOJ, SAPS, or any court. For a
        result, use the <a href="/dashboard/eligibility">Eligibility Checker</a>.
      </p>
      <AssistantClient />
    </>
  );
}
