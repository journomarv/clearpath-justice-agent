"use client";

import { useEffect, useState } from "react";
import { apiFetchJson } from "@/lib/auth";

interface Application {
  id: string;
  status: string;
  createdAt: string;
}

interface Offence {
  id: string;
  userConfirmed: boolean;
  latestAssessment: { finalDecision: string | null; aiRecommendation: string | null } | null;
}

export default function DashboardSummary() {
  const [applications, setApplications] = useState<Application[] | null>(null);
  const [offences, setOffences] = useState<Offence[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      apiFetchJson<{ applications: Application[] }>("/api/v1/applications"),
      apiFetchJson<{ offences: Offence[] }>("/api/v1/eligibility/offences"),
    ])
      .then(([appBody, offBody]) => {
        setApplications(appBody.applications);
        setOffences(offBody.offences);
      })
      .catch((err) => setError(err.message));
  }, []);

  if (error) {
    return (
      <p style={{ color: "#b91c1c" }}>
        Couldn&apos;t load your summary ({error}). Try the pages below directly, or use the{" "}
        <a href="/contact">Contact page</a> for help.
      </p>
    );
  }

  if (!applications || !offences) {
    return <p>Loading your summary...</p>;
  }

  const decided = offences.filter((o) => o.latestAssessment?.finalDecision).length;
  const pendingConfirmation = offences.filter((o) => !o.userConfirmed).length;

  return (
    <>
      <p>
        {offences.length === 0 && applications.length === 0 ? (
          <>You haven&apos;t started an eligibility check yet.</>
        ) : (
          <>
            {offences.length} offence{offences.length === 1 ? "" : "s"} on file
            {decided > 0 && <>, {decided} assessed</>}
            {pendingConfirmation > 0 && <>, {pendingConfirmation} awaiting your confirmation</>}.
            {applications.length > 0 && <> {applications.length} application{applications.length === 1 ? "" : "s"} tracked.</>}
          </>
        )}
      </p>
      <p style={{ color: "var(--color-text-muted)" }}>
        This preliminary assessment is not a legal determination. For help with an actual case, use the{" "}
        <a href="/contact">Contact page</a>.
      </p>
    </>
  );
}
