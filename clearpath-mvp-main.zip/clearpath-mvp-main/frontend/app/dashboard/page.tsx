import type { Metadata } from "next";
import Link from "next/link";
import DashboardSummary from "./DashboardSummary";

export const metadata: Metadata = { title: "Dashboard" };

export default function DashboardPage() {
  return (
    <>
      <h1>Welcome back</h1>

      <section className="step-card" style={{ marginBottom: "1.5rem" }}>
        <h3>Your application</h3>
        <DashboardSummary />
      </section>

      <div className="steps">
        <Link href="/dashboard/upload" className="step-card">
          <h3>Upload Criminal Record</h3>
          <p>Start or update your eligibility check.</p>
        </Link>
        <Link href="/dashboard/eligibility" className="step-card">
          <h3>Eligibility Results</h3>
          <p>View your AI-assisted eligibility assessment.</p>
        </Link>
        <Link href="/dashboard/prepare" className="step-card">
          <h3>Action Plan</h3>
          <p>See what to do next, and what's still missing.</p>
        </Link>
        <Link href="/dashboard/tracking" className="step-card">
          <h3>Case Tracking</h3>
          <p>Track your case status and record submission outcomes.</p>
        </Link>
        <Link href="/dashboard/assistant" className="step-card">
          <h3>Ask the Assistant</h3>
          <p>Get plain-language help understanding the process and your documents.</p>
        </Link>
        <Link href="/dashboard/applications" className="step-card">
          <h3>My Documents</h3>
          <p>View and download your application documents.</p>
        </Link>
        <Link href="/dashboard/account" className="step-card">
          <h3>Account &amp; Data</h3>
          <p>Export your data or delete your account.</p>
        </Link>
        <Link href="/dashboard/security" className="step-card">
          <h3>Security</h3>
          <p>Set up two-factor authentication.</p>
        </Link>
      </div>
    </>
  );
}
