"use client";

import { useEffect, useState } from "react";
import { apiFetch, apiFetchJson } from "@/lib/auth";

interface DocumentRow {
  id: string;
  type: string;
  mimeType: string;
  virusScanStatus: string;
  uploadedAt: string;
}

export default function DocumentsClient() {
  const [documents, setDocuments] = useState<DocumentRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetchJson<{ documents: DocumentRow[] }>("/api/v1/documents")
      .then((body) => setDocuments(body.documents))
      .catch((err) => setError(err.message));
  }, []);

  async function download(id: string, mimeType: string) {
    const res = await apiFetch(`/api/v1/documents/${id}/download`);
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `document-${id}.${mimeType.split("/")[1] ?? "bin"}`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <article>
      <h1>My Documents</h1>
      {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
      {!documents && !error && <p>Loading...</p>}
      {documents && documents.length === 0 && (
        <p style={{ color: "var(--color-text-muted)" }}>
          No documents uploaded yet. Head to the <a href="/dashboard/upload">Upload page</a> to get started.
        </p>
      )}
      <ul>
        {documents?.map((d) => (
          <li key={d.id} style={{ marginBottom: "0.5rem" }}>
            {d.type.replace(/_/g, " ")} — uploaded {new Date(d.uploadedAt).toLocaleDateString()} —{" "}
            {d.virusScanStatus === "clean" ? (
              <button type="button" onClick={() => download(d.id, d.mimeType)} style={{ padding: "0.15rem 0.5rem" }}>
                Download
              </button>
            ) : (
              <em>{d.virusScanStatus}</em>
            )}
          </li>
        ))}
      </ul>
    </article>
  );
}
