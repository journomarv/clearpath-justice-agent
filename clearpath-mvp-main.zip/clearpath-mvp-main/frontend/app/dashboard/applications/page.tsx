import type { Metadata } from "next";
import DocumentsClient from "./DocumentsClient";

export const metadata: Metadata = { title: "My Documents", robots: { index: false, follow: false } };

export default function ApplicationsPage() {
  return <DocumentsClient />;
}
