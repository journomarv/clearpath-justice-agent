import type { Metadata } from "next";
import TrackingClient from "./TrackingClient";

export const metadata: Metadata = { title: "Case Tracking", robots: { index: false, follow: false } };

export default function TrackingPage() {
  return <TrackingClient />;
}
