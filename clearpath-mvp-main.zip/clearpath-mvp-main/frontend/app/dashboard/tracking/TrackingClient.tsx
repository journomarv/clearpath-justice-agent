"use client";

import { useEffect, useState } from "react";
import { apiFetch, apiFetchJson } from "@/lib/auth";

interface Application {
  id: string;
  status: string;
  createdAt: string;
  referenceNumber: string | null;
  submittedAt: string | null;
  outcome: "granted" | "refused" | "withdrawn" | null;
  outcomeDate: string | null;
}

interface Note {
  id: string;
  body: string;
  createdAt: string;
}

const OUTCOME_LABELS: Record<string, string> = {
  granted: "Granted",
  refused: "Refused",
  withdrawn: "Withdrawn",
};

const STAGES = ["submitted", "under_review", "waiting_for_information", "approved"];
const STAGE_LABELS: Record<string, string> = {
  submitted: "Submitted",
  under_review: "Under Review",
  waiting_for_information: "Waiting for Information",
  approved: "Approved",
  rejected: "Rejected",
};

export default function TrackingClient() {
  const [application, setApplication] = useState<Application | null>(null);
  const [notes, setNotes] = useState<Note[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  const [referenceNumber, setReferenceNumber] = useState("");
  const [submittedAt, setSubmittedAt] = useState("");
  const [outcome, setOutcome] = useState("");
  const [outcomeDate, setOutcomeDate] = useState("");
  const [verifySaving, setVerifySaving] = useState(false);
  const [verifyError, setVerifyError] = useState<string | null>(null);

  const [noteBody, setNoteBody] = useState("");
  const [noteSaving, setNoteSaving] = useState(false);
  const [noteError, setNoteError] = useState<string | null>(null);

  const [passportId, setPassportId] = useState<string | null>(null);
  const [passportSaving, setPassportSaving] = useState(false);
  const [passportError, setPassportError] = useState<string | null>(null);

  const [startingCase, setStartingCase] = useState(false);
  const [startError, setStartError] = useState<string | null>(null);

  function load() {
    apiFetchJson<{ applications: Application[] }>("/api/v1/applications")
      .then(async (body) => {
        const latest = body.applications[0] ?? null;
        setApplication(latest);
        if (latest) {
          setReferenceNumber(latest.referenceNumber ?? "");
          setSubmittedAt(latest.submittedAt ? latest.submittedAt.slice(0, 10) : "");
          setOutcome(latest.outcome ?? "");
          setOutcomeDate(latest.outcomeDate ? latest.outcomeDate.slice(0, 10) : "");
          const timeline = await apiFetchJson<{ notes: Note[] }>(`/api/v1/applications/${latest.id}/timeline`);
          setNotes(timeline.notes);
        }
        setLoaded(true);
      })
      .catch((err) => {
        setError(err.message);
        setLoaded(true);
      });
  }

  useEffect(load, []);

  async function saveVerify() {
    if (!application) return;
    setVerifySaving(true);
    setVerifyError(null);
    try {
      await apiFetch(`/api/v1/applications/${application.id}/verify`, {
        method: "PATCH",
        body: JSON.stringify({
          referenceNumber: referenceNumber.trim() || null,
          submittedAt: submittedAt ? new Date(submittedAt).toISOString() : null,
          outcome: outcome || null,
          outcomeDate: outcomeDate ? new Date(outcomeDate).toISOString() : null,
        }),
      });
      load();
    } catch (err) {
      setVerifyError(err instanceof Error ? err.message : "Couldn't save.");
    } finally {
      setVerifySaving(false);
    }
  }

  async function startCase() {
    setStartingCase(true);
    setStartError(null);
    try {
      await apiFetch("/api/v1/applications", { method: "POST" });
      load();
    } catch (err) {
      setStartError(err instanceof Error ? err.message : "Couldn't start a case.");
    } finally {
      setStartingCase(false);
    }
  }

  async function generatePassport() {
    if (!application) return;
    setPassportSaving(true);
    setPassportError(null);
    try {
      const passport = await apiFetchJson<{ id: string }>(`/api/v1/applications/${application.id}/passport`, {
        method: "POST",
      });
      setPassportId(passport.id);
    } catch (err) {
      setPassportError(err instanceof Error ? err.message : "Couldn't generate a passport.");
    } finally {
      setPassportSaving(false);
    }
  }

  async function addNote() {
    if (!application || !noteBody.trim()) return;
    setNoteSaving(true);
    setNoteError(null);
    try {
      await apiFetch(`/api/v1/applications/${application.id}/notes`, {
        method: "POST",
        body: JSON.stringify({ body: noteBody.trim() }),
      });
      setNoteBody("");
      load();
    } catch (err) {
      setNoteError(err instanceof Error ? err.message : "Couldn't save.");
    } finally {
      setNoteSaving(false);
    }
  }

  if (!loaded) return <article><h1>Case Tracking</h1><p>Loading...</p></article>;

  if (error) return <article><h1>Case Tracking</h1><p style={{ color: "#b91c1c" }}>{error}</p></article>;

  if (!application) {
    return (
      <article>
        <h1>Case Tracking</h1>
        <p style={{ color: "var(--color-text-muted)" }}>
          You don&apos;t have a case yet. Once you&apos;ve reviewed your{" "}
          <a href="/dashboard/eligibility">eligibility results</a>, start one below to get a
          reference number and track what happens next.
        </p>
        {startError && <p style={{ color: "#b91c1c" }}>{startError}</p>}
        <button type="button" onClick={startCase} disabled={startingCase}>
          {startingCase ? "Starting..." : "Start my case"}
        </button>
      </article>
    );
  }

  const currentIndex = application.status === "rejected" ? STAGES.length - 1 : STAGES.indexOf(application.status);

  return (
    <article>
      <h1>Case Tracking</h1>
      <ol style={{ display: "flex", gap: "1rem", listStyle: "none", padding: 0, flexWrap: "wrap" }}>
        {STAGES.map((s, i) => (
          <li
            key={s}
            style={{
              padding: "0.5rem 1rem",
              borderRadius: "999px",
              background: i <= currentIndex ? "#166534" : "#e5e7eb",
              color: i <= currentIndex ? "white" : "#6b7280",
              fontSize: "0.85rem",
              fontWeight: 600,
            }}
          >
            {STAGE_LABELS[s]}
          </li>
        ))}
      </ol>
      <p style={{ marginTop: "1.5rem", color: "var(--color-text-muted)" }}>
        Application {application.id.slice(0, 8)} — started {new Date(application.createdAt).toLocaleDateString()}
      </p>

      {notes.length > 0 && (
        <section style={{ marginTop: "1.5rem" }}>
          <h3>Case updates</h3>
          {notes.map((n) => (
            <div key={n.id} className="step-card" style={{ marginBottom: "0.75rem" }}>
              <p>{n.body}</p>
              <p style={{ color: "var(--color-text-muted)", fontSize: "0.85rem" }}>
                {new Date(n.createdAt).toLocaleString()}
              </p>
            </div>
          ))}
        </section>
      )}

      <section className="step-card" style={{ marginTop: "1.5rem" }}>
        <h3>Record what happened (VERIFY)</h3>
        <p style={{ color: "var(--color-text-muted)" }}>
          Once you&apos;ve submitted your application, record the reference number and outcome
          here yourself — ClearPath doesn&apos;t receive this automatically from DOJ or SAPS.
        </p>
        {application.outcome && (
          <p>
            <strong>Outcome:</strong> {OUTCOME_LABELS[application.outcome]}
            {application.outcomeDate && <> on {new Date(application.outcomeDate).toLocaleDateString()}</>}
          </p>
        )}
        <div style={{ display: "grid", gap: "0.75rem", maxWidth: "420px" }}>
          <label>
            Reference number
            <input
              type="text"
              value={referenceNumber}
              onChange={(e) => setReferenceNumber(e.target.value)}
              maxLength={100}
              style={{ display: "block", width: "100%", padding: "0.4rem" }}
            />
          </label>
          <label>
            Date submitted
            <input
              type="date"
              value={submittedAt}
              onChange={(e) => setSubmittedAt(e.target.value)}
              style={{ display: "block", width: "100%", padding: "0.4rem" }}
            />
          </label>
          <label>
            Final outcome
            <select
              value={outcome}
              onChange={(e) => setOutcome(e.target.value)}
              style={{ display: "block", width: "100%", padding: "0.4rem" }}
            >
              <option value="">Not yet known</option>
              <option value="granted">Granted</option>
              <option value="refused">Refused</option>
              <option value="withdrawn">Withdrawn</option>
            </select>
          </label>
          <label>
            Date of outcome
            <input
              type="date"
              value={outcomeDate}
              onChange={(e) => setOutcomeDate(e.target.value)}
              style={{ display: "block", width: "100%", padding: "0.4rem" }}
            />
          </label>
          {verifyError && <p style={{ color: "#b91c1c" }}>{verifyError}</p>}
          <button type="button" onClick={saveVerify} disabled={verifySaving} style={{ justifySelf: "start" }}>
            {verifySaving ? "Saving..." : "Save"}
          </button>
        </div>
      </section>

      {application.outcome && (
        <section className="step-card" style={{ marginTop: "1.5rem" }}>
          <h3>Digital Justice Passport</h3>
          <p style={{ color: "var(--color-text-muted)" }}>
            A shareable proof that your case reached an outcome — it shows only the outcome and
            issue date, never your offence details or personal information.
          </p>
          {!passportId ? (
            <button type="button" onClick={generatePassport} disabled={passportSaving}>
              {passportSaving ? "Generating..." : "Generate Passport"}
            </button>
          ) : (
            <div>
              <p>Share this verification link:</p>
              <code style={{ display: "block", padding: "0.5rem", background: "var(--color-surface-muted, #f3f4f6)", wordBreak: "break-all" }}>
                {typeof window !== "undefined" ? `${window.location.origin}/verify/${passportId}` : `/verify/${passportId}`}
              </code>
            </div>
          )}
          {passportError && <p style={{ color: "#b91c1c" }}>{passportError}</p>}
        </section>
      )}

      <section className="step-card" style={{ marginTop: "1.5rem" }}>
        <h3>Your notes &amp; correspondence</h3>
        {notes.length === 0 && (
          <p style={{ color: "var(--color-text-muted)" }}>No entries yet — add your first below.</p>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            addNote();
          }}
          style={{ display: "flex", gap: "0.5rem", marginTop: "0.75rem" }}
        >
          <input
            type="text"
            value={noteBody}
            onChange={(e) => setNoteBody(e.target.value)}
            placeholder="e.g. Called SAPS CRC, told to wait 6 weeks"
            maxLength={2000}
            style={{ flex: 1, padding: "0.4rem" }}
          />
          <button type="submit" disabled={noteSaving || !noteBody.trim()}>
            Add
          </button>
        </form>
        {noteError && <p style={{ color: "#b91c1c" }}>{noteError}</p>}
      </section>
    </article>
  );
}
