import type { Metadata } from "next";
import { Suspense } from "react";
import EligibilityClient from "./EligibilityClient";

export const metadata: Metadata = { title: "Eligibility Result", robots: { index: false, follow: false } };

export default function EligibilityPage() {
  return (
    <Suspense fallback={<p>Loading...</p>}>
      <EligibilityClient />
    </Suspense>
  );
}
