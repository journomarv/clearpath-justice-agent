"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { apiFetch, apiFetchJson } from "@/lib/auth";

const SENTENCE_TYPES = ["fine", "imprisonment", "imprisonment_suspended", "caution", "other"] as const;

interface Offence {
  id: string;
  offenceDescription: string;
  offenceDate: string | null;
  court: string | null;
  sentenceType: string | null;
  sentenceDetails: string | null;
  userConfirmed: boolean;
  extractionConfidence: number | null;
  latestAssessment: {
    aiRecommendation: string;
    aiReasoning: string;
    finalDecision: string | null;
    decidedAt: string | null;
  } | null;
}

const verdictColor: Record<string, string> = {
  eligible: "#166534",
  not_eligible: "#991b1b",
  uncertain: "#92400e",
};

export default function EligibilityClient() {
  const [offences, setOffences] = useState<Offence[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const searchParams = useSearchParams();
  const documentId = searchParams.get("documentId");

  function load() {
    apiFetchJson<{ offences: Offence[] }>("/api/v1/eligibility/offences")
      .then((body) => setOffences(body.offences))
      .catch((err) => setError(err.message));
  }

  useEffect(load, []);

  async function confirm(id: string) {
    const res = await apiFetch(`/api/v1/eligibility/offences/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ userConfirmed: true }),
    });
    if (res.ok) load();
  }

  return (
    <article>
      <h1>Your Eligibility Results</h1>
      <div className="disclaimer-banner" style={{ marginBottom: "1rem" }}>
        This is an AI-assisted estimate, not a legal decision. A ClearPath reviewer will confirm before your
        application is generated.
      </div>

      {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
      {!offences && !error && <p>Loading...</p>}
      {offences && offences.length === 0 && !documentId && (
        <p style={{ color: "var(--color-text-muted)" }}>
          Nothing to show yet — upload a document from the <a href="/dashboard/upload">Upload page</a> to start
          your eligibility check.
        </p>
      )}
      {offences && offences.length === 0 && documentId && (
        <p style={{ color: "var(--color-text-muted)" }}>
          We couldn&apos;t automatically extract offence details from your document (or extraction hasn&apos;t
          finished yet). You can enter them by hand below instead.
        </p>
      )}

      {offences?.map((o) => (
        <div className="step-card" key={o.id} style={{ marginBottom: "1rem" }}>
          <h3>{o.offenceDescription}</h3>
          <p style={{ color: "var(--color-text-muted)" }}>
            {o.offenceDate && new Date(o.offenceDate).toLocaleDateString()}
            {o.court && ` — ${o.court}`}
            {o.sentenceType && ` — ${o.sentenceType.replace(/_/g, " ")}`}
          </p>

          {!o.userConfirmed && (
            <>
              <p style={{ color: "var(--color-text-muted)" }}>
                Review the extracted details above. If they look right, confirm to run your eligibility check.
              </p>
              <button type="button" onClick={() => confirm(o.id)}>Confirm this is correct</button>
            </>
          )}

          {o.userConfirmed && !o.latestAssessment && (
            <p style={{ color: "var(--color-text-muted)" }}>Confirmed — awaiting eligibility evaluation.</p>
          )}

          {o.latestAssessment && (
            <>
              <p style={{ color: verdictColor[o.latestAssessment.aiRecommendation], fontWeight: 600, textTransform: "uppercase" }}>
                {(o.latestAssessment.finalDecision ?? o.latestAssessment.aiRecommendation).replace("_", " ")}
                {o.latestAssessment.finalDecision ? " (reviewer-confirmed)" : " (AI estimate, awaiting reviewer)"}
              </p>
              <p>{o.latestAssessment.aiReasoning}</p>
            </>
          )}
        </div>
      ))}

      {documentId && <ManualOffenceForm documentId={documentId} onAdded={load} />}
    </article>
  );
}

function ManualOffenceForm({ documentId, onAdded }: { documentId: string; onAdded: () => void }) {
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    setFormError(null);
    const form = new FormData(e.currentTarget);
    const offenceDescription = String(form.get("offenceDescription") ?? "").trim();
    const offenceDate = String(form.get("offenceDate") ?? "");
    const court = String(form.get("court") ?? "").trim();
    const sentenceType = String(form.get("sentenceType") ?? "");
    const sentenceDetails = String(form.get("sentenceDetails") ?? "").trim();

    const res = await apiFetch("/api/v1/eligibility/offences", {
      method: "POST",
      body: JSON.stringify({
        documentId,
        offenceDescription,
        offenceDate: offenceDate ? new Date(offenceDate).toISOString() : null,
        court: court || null,
        sentenceType: sentenceType || null,
        sentenceDetails: sentenceDetails || null,
      }),
    });

    setSubmitting(false);
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setFormError(body?.error?.message ?? "Could not add this offence.");
      return;
    }
    (e.target as HTMLFormElement).reset();
    setOpen(false);
    onAdded();
  }

  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)}>
        Add offence manually
      </button>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="step-card" style={{ marginTop: "1rem" }}>
      <h3>Add offence manually</h3>
      {formError && <p style={{ color: "#b91c1c" }}>{formError}</p>}
      <label>
        Offence description
        <input type="text" name="offenceDescription" required maxLength={2000} />
      </label>
      <label>
        Offence date (optional)
        <input type="date" name="offenceDate" />
      </label>
      <label>
        Court (optional)
        <input type="text" name="court" maxLength={200} />
      </label>
      <label>
        Sentence type (optional)
        <select name="sentenceType" defaultValue="">
          <option value="">Unknown</option>
          {SENTENCE_TYPES.map((t) => (
            <option key={t} value={t}>
              {t.replace(/_/g, " ")}
            </option>
          ))}
        </select>
      </label>
      <label>
        Sentence details (optional)
        <input type="text" name="sentenceDetails" maxLength={2000} />
      </label>
      <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.5rem" }}>
        <button type="submit" disabled={submitting}>
          {submitting ? "Adding..." : "Add offence"}
        </button>
        <button type="button" onClick={() => setOpen(false)} disabled={submitting}>
          Cancel
        </button>
      </div>
    </form>
  );
}
