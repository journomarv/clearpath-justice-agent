"use client";

import { useEffect, useState } from "react";
import { apiFetchJson } from "@/lib/auth";

interface PlanStep {
  id: string;
  title: string;
  detail: string;
  done: boolean;
}

interface Plan {
  steps: PlanStep[];
  missing: { documentsMissing: boolean; unconfirmedOffenceCount: number };
}

export default function PrepareClient() {
  const [plan, setPlan] = useState<Plan | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetchJson<Plan>("/api/v1/prepare/plan")
      .then(setPlan)
      .catch((err) => setError(err.message));
  }, []);

  if (error) return <p style={{ color: "#b91c1c" }}>{error}</p>;
  if (!plan) return <p>Loading your plan...</p>;

  const doneCount = plan.steps.filter((s) => s.done).length;

  return (
    <div>
      <p style={{ fontWeight: 600 }}>
        {doneCount} of {plan.steps.length} steps complete
      </p>
      <ol style={{ listStyle: "none", padding: 0, display: "grid", gap: "0.75rem" }}>
        {plan.steps.map((step) => (
          <li key={step.id} className="step-card" style={{ opacity: step.done ? 0.7 : 1 }}>
            <h3 style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <span aria-hidden>{step.done ? "✅" : "⬜"}</span>
              {step.title}
            </h3>
            <p style={{ color: "var(--color-text-muted)" }}>{step.detail}</p>
          </li>
        ))}
      </ol>
      <p style={{ marginTop: "1rem", color: "var(--color-text-muted)" }}>
        This plan is preliminary guidance, not a legal determination. For help with an actual
        case, use the <a href="/contact">Contact page</a>.
      </p>
    </div>
  );
}
