import type { Metadata } from "next";
import PrepareClient from "./PrepareClient";

export const metadata: Metadata = { title: "Action Plan", robots: { index: false, follow: false } };

export default function PreparePage() {
  return (
    <>
      <h1>Your Action Plan</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        What to do next, based on where you are right now. This updates automatically as you
        complete each step.
      </p>
      <PrepareClient />
    </>
  );
}
