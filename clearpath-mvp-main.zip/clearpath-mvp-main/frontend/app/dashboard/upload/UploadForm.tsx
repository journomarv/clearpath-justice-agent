"use client";

import { useState } from "react";

export default function UploadForm() {
  const [status, setStatus] = useState<"idle" | "uploading" | "done" | "error">("idle");
  const [documentId, setDocumentId] = useState<string | null>(null);

  async function handleUpload(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const file = form.get("file") as File | null;
    if (!file) return;

    if (!["application/pdf", "image/jpeg", "image/png"].includes(file.type)) {
      setStatus("error");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setStatus("error");
      return;
    }

    setStatus("uploading");
    const body = new FormData();
    body.append("file", file);

    const accessToken = sessionStorage.getItem("accessToken");
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/documents`, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}` },
      credentials: "include",
      body,
    });
    if (!res.ok) {
      setStatus("error");
      return;
    }
    const { id: uploadedDocumentId } = await res.json();
    setDocumentId(uploadedDocumentId);
    // Kicks off the extraction pipeline (docs/05-ai-workflow.md steps 1-4).
    // Best-effort: the upload itself already succeeded either way, and the
    // Eligibility page can be revisited once results are ready (or offences
    // can be entered manually if extraction can't run for this document).
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/eligibility/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
      credentials: "include",
      body: JSON.stringify({ documentId: uploadedDocumentId }),
    }).catch(() => undefined);
    setStatus("done");
  }

  return (
    <article>
      <h1>Upload Your Criminal Record</h1>
      <p>Accepted formats: PDF, JPG, PNG. Maximum size: 10MB.</p>
      <form onSubmit={handleUpload}>
        <label>
          File
          <input type="file" name="file" accept=".pdf,.jpg,.jpeg,.png" required />
        </label>
        <button type="submit" disabled={status === "uploading"}>
          {status === "uploading" ? "Uploading..." : "Upload"}
        </button>
      </form>
      {status === "done" && (
        <p>
          Upload received. We&apos;re analyzing your document — check the{" "}
          <a href={documentId ? `/dashboard/eligibility?documentId=${documentId}` : "/dashboard/eligibility"}>
            Eligibility page
          </a>{" "}
          shortly for extracted details to confirm. If nothing was extracted automatically, you&apos;ll be able to
          add offence details by hand from that page.
        </p>
      )}
      {status === "error" && <p style={{ color: "#b91c1c" }}>Upload failed. Please check the file type/size and try again.</p>}
    </article>
  );
}
