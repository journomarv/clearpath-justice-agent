"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export default function ConfirmResetForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token");

  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<"idle" | "submitting" | "done">("idle");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);

    const form = new FormData(e.currentTarget);
    const newPassword = form.get("newPassword") as string;
    const confirmPassword = form.get("confirmPassword") as string;

    if (newPassword !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (!token) {
      setError("This reset link is missing its token. Please use the link from your email.");
      return;
    }

    setStatus("submitting");
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/password/reset`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, newPassword }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setError(body?.error?.message ?? "That link is invalid or has expired. Please request a new one.");
      setStatus("idle");
      return;
    }

    setStatus("done");
    setTimeout(() => router.push("/login"), 2000);
  }

  if (!token) {
    return (
      <article>
        <h1>Invalid reset link</h1>
        <p>
          This page needs a reset token from the link in your email. If you didn&apos;t get one, you can{" "}
          <a href="/reset-password">request a new reset link</a>.
        </p>
      </article>
    );
  }

  if (status === "done") {
    return (
      <article>
        <h1>Password updated</h1>
        <p>Your password has been reset. Redirecting you to log in…</p>
      </article>
    );
  }

  return (
    <article>
      <h1>Choose a new password</h1>
      <form onSubmit={handleSubmit}>
        <label>
          New password (min. 12 characters)
          <input type="password" name="newPassword" required minLength={12} maxLength={128} autoComplete="new-password" />
        </label>
        <label>
          Confirm new password
          <input type="password" name="confirmPassword" required minLength={12} maxLength={128} autoComplete="new-password" />
        </label>
        {error && <p style={{ color: "#f87171" }}>{error}</p>}
        <button type="submit" disabled={status === "submitting"}>
          {status === "submitting" ? "Updating…" : "Update password"}
        </button>
      </form>
    </article>
  );
}
