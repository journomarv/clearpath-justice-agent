import type { Metadata } from "next";
import { Suspense } from "react";
import ConfirmResetForm from "./ConfirmResetForm";

export const metadata: Metadata = {
  title: "Choose a New Password",
  robots: { index: false, follow: false },
};

export default function ConfirmResetPage() {
  return (
    <Suspense fallback={null}>
      <ConfirmResetForm />
    </Suspense>
  );
}
