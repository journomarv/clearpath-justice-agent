import type { Metadata } from "next";
import ResetPasswordForm from "./ResetPasswordForm";

export const metadata: Metadata = {
  title: "Reset Your Password",
  description: "Request a password reset link for your ClearPath Justice account.",
  alternates: { canonical: "/reset-password" },
  robots: { index: false, follow: true },
};

export default function ResetPasswordPage() {
  return <ResetPasswordForm />;
}
