"use client";

import { useState } from "react";

export default function ResetPasswordForm() {
  const [sent, setSent] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/password/forgot`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: form.get("email") }),
    });
    // Always show the same message, regardless of whether the email
    // exists — avoids account enumeration.
    setSent(true);
  }

  if (sent) {
    return (
      <article>
        <h1>Check your email</h1>
        <p>If an account exists for that email, a reset link is on its way.</p>
      </article>
    );
  }

  return (
    <article>
      <h1>Reset your password</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Email
          <input type="email" name="email" required autoComplete="email" />
        </label>
        <button type="submit">Send reset link</button>
      </form>
    </article>
  );
}
