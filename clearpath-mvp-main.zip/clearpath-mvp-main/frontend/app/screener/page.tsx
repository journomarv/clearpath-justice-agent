import type { Metadata } from "next";
import ScreenerClient from "./ScreenerClient";

export const metadata: Metadata = {
  title: "Quick Cannabis Conviction Eligibility Screener",
  description:
    "Answer two quick questions to check whether your cannabis-related conviction may qualify for expungement under South Africa's Cannabis for Private Purposes Act 7 of 2024 (CPPA). Free, no account needed.",
  alternates: { canonical: "/screener" },
  openGraph: {
    title: "Quick Cannabis Conviction Eligibility Screener | ClearPath Justice",
    description:
      "Answer two quick questions to check whether your cannabis-related conviction may qualify for expungement under South Africa's CPPA.",
    url: "/screener",
  },
};

export default function ScreenerPage() {
  return <ScreenerClient />;
}
