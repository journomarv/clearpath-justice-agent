"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { trackEvent } from "@/lib/analytics";

type ConvictionType = "possession" | "dealing" | "diversion";
type LawBasis = "1992" | "1971" | "homeland" | "unsure";
type Presumption = "yes" | "no" | "unsure";

type Step = "type" | "law" | "presumption" | "result";

interface Answers {
  convictionType: ConvictionType | null;
  lawBasis: LawBasis | null;
  presumption: Presumption | null;
}

const EMPTY_ANSWERS: Answers = { convictionType: null, lawBasis: null, presumption: null };

function Trail({ active }: { active: "s1" | "s2" | "s2d" | null }) {
  const waypoints: { key: "s1" | "s2" | "s2d"; label: string; sub: string }[] = [
    { key: "s1", label: "Section 5(1)", sub: "Use / possession — automatic" },
    { key: "s2", label: "Section 5(2)", sub: "Dealing on presumption — by application" },
    { key: "s2d", label: "Section 5(2)(d)", sub: "Child diversion records" },
  ];
  return (
    <div className="screener-trail">
      {waypoints.map((w) => (
        <div key={w.key} className={`screener-waypoint${w.key === active ? " is-active" : ""}`}>
          <strong>{w.label}</strong>
          <span>{w.sub}</span>
        </div>
      ))}
    </div>
  );
}

function Result({ answers, onRestart }: { answers: Answers; onRestart: () => void }) {
  if (answers.convictionType === "diversion") {
    return (
      <div className="screener-card">
        <Trail active="s2d" />
        <span className="result-tag tone-muted">Not yet supported</span>
        <h2 className="screener-q-title">This quick screener doesn&apos;t cover child diversion records yet.</h2>
        <p className="result-section">CPPA section 5(2)(d)</p>
        <p className="result-body">
          Diversion records — orders made instead of a conviction for something that happened before you turned
          18 — sit under a separate, still-developing part of the Cannabis for Private Purposes Act. We haven&apos;t
          built guidance for this pathway yet.
        </p>
        <div className="next-steps">
          <h3>Suggested next steps</h3>
          <ul>
            <li>Check back here as this pathway gets built out.</li>
            <li>A Legal Aid South Africa clinic can advise on diversion-record queries directly in the meantime.</li>
          </ul>
        </div>
        <ResultActions onRestart={onRestart} showFullChecker={false} />
      </div>
    );
  }

  if (answers.convictionType === "possession") {
    if (answers.lawBasis === "unsure") return <UncertainResult onRestart={onRestart} />;
    return (
      <div className="screener-card">
        <Trail active="s1" />
        <span className="result-tag tone-teal">Likely eligible — automatic</span>
        <h2 className="screener-q-title">This conviction likely qualifies for automatic expungement.</h2>
        <p className="result-section">CPPA section 5(1)</p>
        <p className="result-body">
          Cannabis use or possession convictions under the 1971 Act, the 1992 Act, or a pre-1993 homeland-era law
          fall under section 5(1). No application should be needed — removal is meant to happen automatically once
          the Act is in force.
        </p>
        <div className="next-steps">
          <h3>Suggested next steps</h3>
          <ul>
            <li>Note down what you have on the case (date, court, charge) in case you need to follow up later.</li>
            <li>SAPS is expected to action automatic expungements against its own Criminal Record Centre database — there&apos;s no confirmed public timeline yet.</li>
            <li>Once it&apos;s actioned, a police clearance certificate will confirm the record no longer shows the conviction.</li>
          </ul>
        </div>
        <ResultActions onRestart={onRestart} showFullChecker />
      </div>
    );
  }

  // dealing
  if (answers.presumption === "unsure") return <UncertainResult onRestart={onRestart} />;
  if (answers.presumption === "yes") {
    return (
      <div className="screener-card">
        <Trail active="s2" />
        <span className="result-tag tone-gold">Possibly eligible — needs an application</span>
        <h2 className="screener-q-title">This record may qualify, but it won&apos;t be automatic.</h2>
        <p className="result-section">CPPA section 5(2)</p>
        <p className="result-body">
          Dealing convictions that rested on a legal presumption of dealing — decided by the quantity found, rather
          than direct proof of a sale — can potentially be expunged under section 5(2), but that route requires a
          formal application once the process is in place.
        </p>
        <div className="next-steps">
          <h3>Suggested next steps</h3>
          <ul>
            <li>Try to get hold of the charge sheet or J15 record — it will show whether the presumption was relied on.</li>
            <li>No application process exists yet — the CPPA&apos;s regulations are still being finalised.</li>
            <li>A Legal Aid clinic can help confirm whether the presumption applied in your specific case.</li>
          </ul>
        </div>
        <ResultActions onRestart={onRestart} showFullChecker />
      </div>
    );
  }
  return (
    <div className="screener-card">
      <Trail active="s2" />
      <span className="result-tag tone-amber">Not covered by section 5</span>
      <h2 className="screener-q-title">This one doesn&apos;t appear to fall under section 5 of the CPPA.</h2>
      <p className="result-section">Outside current CPPA scope</p>
      <p className="result-body">
        Dealing convictions based on direct evidence of a sale or supply — rather than a quantity-based presumption
        — aren&apos;t covered by the expungement provisions in section 5 as currently drafted.
      </p>
      <div className="next-steps">
        <h3>Suggested next steps</h3>
        <ul>
          <li>A Legal Aid clinic or attorney can confirm whether any other relief might apply to your case.</li>
          <li>Keep an eye on future regulations — the Act&apos;s scope may still be clarified as it comes into force.</li>
        </ul>
      </div>
      <ResultActions onRestart={onRestart} showFullChecker={false} />
    </div>
  );
}

function UncertainResult({ onRestart }: { onRestart: () => void }) {
  return (
    <div className="screener-card">
      <Trail active={null} />
      <span className="result-tag tone-muted">Needs a closer look</span>
      <h2 className="screener-q-title">We can&apos;t tell from these answers alone.</h2>
      <p className="result-section">Uncertain</p>
      <p className="result-body">
        Which law applied, and whether a presumption of dealing was used, both matter a lot here — and it sounds
        like that&apos;s not clear yet from what you have.
      </p>
      <div className="next-steps">
        <h3>Suggested next steps</h3>
        <ul>
          <li>Try to locate your charge sheet, J15, or court record — the year and the exact charge wording usually settle this.</li>
          <li>A Legal Aid clinic can help interpret an older or hard-to-read record.</li>
        </ul>
      </div>
      <ResultActions onRestart={onRestart} showFullChecker={false} />
    </div>
  );
}

function ResultActions({ onRestart, showFullChecker }: { onRestart: () => void; showFullChecker: boolean }) {
  return (
    <div className="result-actions">
      {showFullChecker && (
        <Link href="/register" className="btn-primary" style={{ marginTop: 0 }}>
          Start my full application
        </Link>
      )}
      <button type="button" onClick={onRestart} className="screener-back" style={{ background: "none", border: "none", cursor: "pointer", padding: 0 }}>
        ← Start over
      </button>
    </div>
  );
}

// Maps the same branches Result() renders to the MVP spec's three funnel
// outcomes ("Potential pathway" / "More information required" / "Does not
// appear to meet the criteria") — kept alongside Result() as the one place
// this decision tree is expressed, so the two can't silently drift apart.
function classifyOutcome(answers: Answers): "pathway" | "more_info" | "not_met" {
  if (answers.convictionType === "diversion") return "more_info";
  if (answers.convictionType === "possession") {
    return answers.lawBasis === "unsure" ? "more_info" : "pathway";
  }
  if (answers.presumption === "unsure") return "more_info";
  return answers.presumption === "yes" ? "pathway" : "not_met";
}

export default function ScreenerClient() {
  const [step, setStep] = useState<Step>("type");
  const [answers, setAnswers] = useState<Answers>(EMPTY_ANSWERS);

  useEffect(() => {
    if (step === "result") trackEvent("assessment_completed", { outcome: classifyOutcome(answers) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  function chooseType(convictionType: ConvictionType) {
    trackEvent("assessment_started");
    setAnswers((a) => ({ ...a, convictionType }));
    if (convictionType === "possession") setStep("law");
    else if (convictionType === "dealing") setStep("presumption");
    else setStep("result");
  }

  function chooseLaw(lawBasis: LawBasis) {
    setAnswers((a) => ({ ...a, lawBasis }));
    setStep("result");
  }

  function choosePresumption(presumption: Presumption) {
    setAnswers((a) => ({ ...a, presumption }));
    setStep("result");
  }

  function restart() {
    setAnswers(EMPTY_ANSWERS);
    setStep("type");
  }

  return (
    <article>
      <h1>Quick Cannabis-Conviction Screener</h1>
      <p style={{ color: "var(--color-text-muted)", marginTop: "-0.5rem" }}>
        A couple of quick questions about a cannabis-related conviction, checked against the Cannabis for Private
        Purposes Act 7 of 2024 (CPPA).
      </p>
      <div className="disclaimer-banner">
        This is a quick, rules-based pre-screener — separate from ClearPath&apos;s full AI-assisted Eligibility
        Checker and not reviewed by a person. It is not legal advice. The CPPA has not yet formally commenced, so no
        application process exists yet for any pathway below.
      </div>

      {step === "type" && (
        <div className="screener-card">
          <Trail active={null} />
          <span className="screener-q-index">QUESTION 1 OF 2</span>
          <h2 className="screener-q-title">What was the conviction for?</h2>
          <div className="screener-options">
            <button type="button" className="screener-option" onClick={() => chooseType("possession")}>
              <span className="screener-option-title">Use or possession only</span>
              <span className="screener-option-sub">e.g. possession of a small amount of cannabis, or personal use</span>
            </button>
            <button type="button" className="screener-option" onClick={() => chooseType("dealing")}>
              <span className="screener-option-title">Dealing or supply</span>
              <span className="screener-option-sub">Convicted of dealing, supply, or trafficking</span>
            </button>
            <button type="button" className="screener-option" onClick={() => chooseType("diversion")}>
              <span className="screener-option-title">Child diversion record</span>
              <span className="screener-option-sub">A diversion order, not a conviction, from when I was under 18</span>
            </button>
          </div>
        </div>
      )}

      {step === "law" && (
        <div className="screener-card">
          <Trail active="s1" />
          <span className="screener-q-index">QUESTION 2 OF 2</span>
          <h2 className="screener-q-title">Which law were you convicted under?</h2>
          <div className="screener-options">
            <button type="button" className="screener-option" onClick={() => chooseLaw("1992")}>
              <span className="screener-option-title">Drugs and Drug Trafficking Act 140 of 1992</span>
            </button>
            <button type="button" className="screener-option" onClick={() => chooseLaw("1971")}>
              <span className="screener-option-title">Abuse of Dependence-Producing Substances Act 41 of 1971</span>
            </button>
            <button type="button" className="screener-option" onClick={() => chooseLaw("homeland")}>
              <span className="screener-option-title">A pre-1993 homeland law</span>
              <span className="screener-option-sub">e.g. Transkei, Bophuthatswana, Venda, or Ciskei law, before 1993</span>
            </button>
            <button type="button" className="screener-option" onClick={() => chooseLaw("unsure")}>
              <span className="screener-option-title">Not sure / other</span>
            </button>
          </div>
          <button type="button" className="screener-back" onClick={() => setStep("type")} style={{ background: "none", border: "none", cursor: "pointer" }}>
            ← Back
          </button>
        </div>
      )}

      {step === "presumption" && (
        <div className="screener-card">
          <Trail active="s2" />
          <span className="screener-q-index">QUESTION 2 OF 2</span>
          <h2 className="screener-q-title">Was the conviction based on a presumption of dealing?</h2>
          <p className="screener-q-hint">
            Some laws presume dealing once you possess more than a set quantity, without needing direct proof that
            you sold anything.
          </p>
          <div className="screener-options">
            <button type="button" className="screener-option" onClick={() => choosePresumption("yes")}>
              <span className="screener-option-title">Yes, it was presumption-based</span>
              <span className="screener-option-sub">Convicted mainly because of the quantity found</span>
            </button>
            <button type="button" className="screener-option" onClick={() => choosePresumption("no")}>
              <span className="screener-option-title">No, there was direct evidence</span>
              <span className="screener-option-sub">There was direct evidence of a sale or supply</span>
            </button>
            <button type="button" className="screener-option" onClick={() => choosePresumption("unsure")}>
              <span className="screener-option-title">Not sure</span>
            </button>
          </div>
          <button type="button" className="screener-back" onClick={() => setStep("type")} style={{ background: "none", border: "none", cursor: "pointer" }}>
            ← Back
          </button>
        </div>
      )}

      {step === "result" && <Result answers={answers} onRestart={restart} />}
    </article>
  );
}
