"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

function completeLogin(accessToken: string) {
  // Access token kept in memory only for this session (never localStorage)
  // in a production build — a real implementation would lift this into
  // an app-wide auth context/provider.
  sessionStorage.setItem("accessToken", accessToken);
  // UI-only flag (no token value) so components like SiteHeader can show
  // logged-in state without reading sessionStorage themselves. The real
  // server-side gate is the httpOnly `cp_access` cookie the backend sets on
  // this same response — see middleware.ts, which verifies that cookie's
  // JWT signature/issuer/audience/expiry rather than trusting this one.
  document.cookie = "cp_session=1; path=/; SameSite=Lax";
}

export default function LoginForm() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [challengeToken, setChallengeToken] = useState<string | null>(null);
  const [mfaCode, setMfaCode] = useState("");

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = new FormData(e.currentTarget);

    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include", // required: refresh token is an httpOnly cookie
      body: JSON.stringify({ email: form.get("email"), password: form.get("password") }),
    });

    if (!res.ok) {
      setError("Invalid email or password.");
      return;
    }
    const body = await res.json();
    if (body.mfaRequired) {
      setChallengeToken(body.challengeToken);
      return;
    }
    completeLogin(body.accessToken);
    router.push("/dashboard");
  }

  async function handleMfaSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/mfa/challenge`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ challengeToken, code: mfaCode }),
    });
    if (!res.ok) {
      setError("Incorrect or expired code. Please try again.");
      return;
    }
    const { accessToken } = await res.json();
    completeLogin(accessToken);
    router.push("/dashboard");
  }

  if (challengeToken) {
    return (
      <article>
        <h1>Enter your authentication code</h1>
        <form onSubmit={handleMfaSubmit}>
          <label>
            6-digit code
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              required
              autoFocus
              value={mfaCode}
              onChange={(e) => setMfaCode(e.target.value)}
            />
          </label>
          {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
          <button type="submit">Verify</button>
        </form>
      </article>
    );
  }

  return (
    <article>
      <h1>Log in</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Email
          <input type="email" name="email" required autoComplete="email" />
        </label>
        <label>
          Password
          <input type="password" name="password" required autoComplete="current-password" />
        </label>
        {error && <p style={{ color: "#b91c1c" }}>{error}</p>}
        <button type="submit">Log in</button>
      </form>
      <p><a href="/reset-password">Forgot password?</a></p>
    </article>
  );
}
