import type { Metadata, Viewport } from "next";
import { Outfit } from "next/font/google";
import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import RevealObserver from "@/components/RevealObserver";
import AnalyticsTracker from "@/components/AnalyticsTracker";
import ServiceWorkerRegister from "@/components/ServiceWorkerRegister";
import "./globals.css";

const displayFont = Outfit({
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  variable: "--font-display",
  display: "swap",
});

const SITE_URL = "https://clearpath-mvp.terminalvelocityai.tech";
const SITE_NAME = "ClearPath Justice";
const SITE_DESCRIPTION =
  "AI-assisted eligibility checking and application help for criminal record expungement in South Africa, including a free quick screener for cannabis-related convictions under the CPPA. Every result is reviewed by a person before it's final.";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: `${SITE_NAME} — Criminal Record Expungement Help (South Africa)`, template: `%s | ${SITE_NAME}` },
  description: SITE_DESCRIPTION,
  applicationName: SITE_NAME,
  authors: [{ name: SITE_NAME }],
  alternates: { canonical: "/" },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  icons: { icon: "/clearpath-logo.jpeg", apple: "/clearpath-logo.jpeg" },
  manifest: "/manifest.json",
  openGraph: {
    type: "website",
    locale: "en_ZA",
    url: "/",
    siteName: SITE_NAME,
    title: `${SITE_NAME} — Criminal Record Expungement Help (South Africa)`,
    description: SITE_DESCRIPTION,
    images: [{ url: "/clearpath-logo.jpeg", width: 1254, height: 1254, alt: `${SITE_NAME} logo` }],
  },
  twitter: {
    card: "summary_large_image",
    title: `${SITE_NAME} — Criminal Record Expungement Help (South Africa)`,
    description: SITE_DESCRIPTION,
    images: ["/clearpath-logo.jpeg"],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#0b1210" },
    { media: "(prefers-color-scheme: light)", color: "#f7f9f7" },
  ],
};

const ORGANIZATION_JSON_LD = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: SITE_NAME,
  url: SITE_URL,
  logo: `${SITE_URL}/clearpath-logo.jpeg`,
  description: SITE_DESCRIPTION,
  slogan: "Expunge. Restore. Renew.",
  areaServed: { "@type": "Country", name: "South Africa" },
};

// WebSite + Service structured data, separate from the Organization block
// above (kept as its own long-standing script tag rather than merged, so
// this stays additive). This is aimed at generative/AI search — Google's
// AI Overviews, Bing Copilot, Perplexity, ChatGPT browsing — which lean on
// structured data and a site's own stated facts more heavily than classic
// keyword ranking. Every claim here matches what's actually true today
// (see /how-it-works and TODO.md) rather than aspirational copy.
const WEBSITE_JSON_LD = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: SITE_NAME,
  url: SITE_URL,
  description: SITE_DESCRIPTION,
  inLanguage: "en-ZA",
  publisher: { "@type": "Organization", name: SITE_NAME, url: SITE_URL },
};

const SERVICE_JSON_LD = {
  "@context": "https://schema.org",
  "@type": "Service",
  serviceType: "Criminal record expungement guidance",
  name: `${SITE_NAME} — Criminal Record Expungement Assistance`,
  provider: { "@type": "Organization", name: SITE_NAME, url: SITE_URL },
  areaServed: { "@type": "Country", name: "South Africa" },
  audience: { "@type": "Audience", audienceType: "People with a South African criminal record seeking expungement" },
  description:
    "A free preliminary eligibility screener, a personalised preparation checklist, case tracking, referrals to the Department of Justice, SAPS, and Legal Aid SA, and a plain-language AI assistant — all explicitly not a substitute for legal advice or a government authority.",
  disambiguatingDescription:
    "ClearPath Justice assists; it does not adjudicate. It is not the Department of Justice, SAPS, or a law firm, and does not decide any application's outcome.",
};

// Dark mode is the product default. This runs before first paint so a
// returning visitor who chose light mode never sees a flash of dark first.
const THEME_INIT_SCRIPT = `
(function () {
  try {
    var stored = localStorage.getItem("clearpath-theme");
    var theme = stored === "light" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", theme);
  } catch (e) {
    document.documentElement.setAttribute("data-theme", "dark");
  }
})();
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark" className={displayFont.variable}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT_SCRIPT }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ORGANIZATION_JSON_LD) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(WEBSITE_JSON_LD) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(SERVICE_JSON_LD) }} />
      </head>
      <body>
        <a href="#main-content" className="skip-link">Skip to content</a>
        <RevealObserver />
        <AnalyticsTracker />
        <ServiceWorkerRegister />
        <SiteHeader />
        <main id="main-content">{children}</main>
        <footer className="site-footer">
          <p>
            ClearPath Justice is not a law firm and does not provide legal advice.
            All eligibility results are AI-assisted estimates reviewed by a human
            before any application is generated.
          </p>
          <p>
            &copy; {new Date().getFullYear()} ClearPath Justice. Early access — working toward full POPIA
            compliance. <Link href="/privacy">Privacy Policy</Link> · <Link href="/terms">Terms of Service</Link>
          </p>
        </footer>
      </body>
    </html>
  );
}
