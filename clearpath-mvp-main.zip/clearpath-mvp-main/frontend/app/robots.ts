import type { MetadataRoute } from "next";

const SITE_URL = "https://clearpath-mvp.terminalvelocityai.tech";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      // Deliberately a single wildcard rule rather than name-listing crawlers:
      // this allows every public path to every crawler by default, AI
      // crawlers included (GPTBot, ClaudeBot, PerplexityBot, Google-Extended,
      // Bingbot, CCBot, etc.) — there is no separate disallow rule targeting
      // any of them, which is the intentional choice for a site that wants
      // to be citable in generative/AI search, not just classic search.
      userAgent: "*",
      allow: "/",
      // Dashboard and admin are per-user/staff surfaces, not public content.
      // The API isn't meant to be crawled either.
      disallow: ["/dashboard", "/dashboard/", "/admin", "/admin/", "/api/"],
    },
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
