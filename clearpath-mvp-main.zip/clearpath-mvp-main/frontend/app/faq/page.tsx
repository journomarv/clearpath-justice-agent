import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Frequently Asked Questions",
  description: "Answers to common questions about criminal record expungement eligibility, required documents, timelines, security, cost, and legal advice at ClearPath Justice.",
  alternates: { canonical: "/faq" },
};

const faqs = [
  { q: "Who is eligible for expungement?", a: "Eligibility depends on the offence, sentence type, and time elapsed since completion of sentence, under the Criminal Procedure Act. Today, our Quick Screener gives an instant answer for cannabis possession or dealing convictions under the CPPA. For other offences, ClearPath Justice is in early access — register and contact our team, and a person will assess your specific case; automated analysis of an uploaded record is still in development." },
  { q: "What documents do I need?", a: "A SAPS criminal record (PDF, JPG, or PNG). You can upload one today, though automated processing of the file itself isn't live yet — see 'Is my information secure?' below. We may request supporting documents depending on your case." },
  { q: "How long does the process take?", a: "The Quick Screener gives a cannabis-conviction result instantly. For other cases, response times depend on our team's manual review since automated AI analysis isn't live yet. Government processing time is outside our control either way." },
  { q: "Is my information secure?", a: "Your account and personal data are access-controlled and handled in line with POPIA. Uploaded document files are not currently retained after the upload request completes — encrypted long-term storage for uploaded files is still in development, so please don't rely on ClearPath Justice as your only copy of any document. See our Privacy Policy for details." },
  { q: "Does ClearPath Justice give legal advice?", a: "No. We provide informational tools and administrative assistance. For legal advice about your specific situation, consult an attorney or Legal Aid South Africa." },
  { q: "Does this cost anything?", a: "The MVP pilot is free to use for eligible participants." },
];

const FAQ_JSON_LD = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a },
  })),
};

export default function FaqPage() {
  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(FAQ_JSON_LD) }} />
      <h1>Frequently Asked Questions</h1>
      {faqs.map((f) => (
        <details key={f.q} style={{ marginBottom: "0.75rem" }}>
          <summary style={{ fontWeight: 600, cursor: "pointer" }}>{f.q}</summary>
          <p>{f.a}</p>
        </details>
      ))}
    </article>
  );
}
