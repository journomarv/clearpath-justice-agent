const POLICY_VERSION = "2026-08-03-3";

export default function PrivacyPage() {
  return (
    <article>
      <h1>Privacy Policy</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        Policy version {POLICY_VERSION}. This is the version you agree to when you create a ClearPath Justice
        account, and the version recorded against your account at that time.
      </p>

      <div className="disclaimer-banner">
        This policy explains how we handle your personal information. It is not legal advice, and it does not
        replace your rights under the Protection of Personal Information Act 4 of 2013 (POPIA).
      </div>

      <div className="disclaimer-banner" style={{ marginTop: "0.75rem" }}>
        <strong>Early access:</strong> ClearPath Justice is in early access. Several features described in
        this policy — automated eligibility analysis in particular — are still in development and are not
        live yet. Self-service data export and account deletion are available from your dashboard (see
        section 8), and expired session/token records are purged automatically on a daily schedule (see
        section 7). Where a feature is not yet live, that is stated explicitly below.
      </div>

      <h2>1. Who we are</h2>
      <p>
        ClearPath Justice aims to help people determine whether they qualify for criminal record expungement in
        South Africa, and to assist with preparing the paperwork. We are the responsible party for the personal
        information described below, as defined under POPIA. The responsible party is{" "}
        <strong>ClearPath Justice (Pty) Ltd</strong> (South African company registration number{" "}
        <strong>2026/123456/07</strong>), of <strong>44 Long Street, Cape Town, 8001, South Africa</strong>.{" "}
        <em>
          [PLACEHOLDER — this entity name, registration number, and address are placeholder values pending
          confirmation of the real registered entity]
        </em>{" "}
        See our <a href="/contact">Contact page</a> if you need the confirmed information sooner.
      </p>

      <h2>2. What we collect</h2>
      <ul>
        <li><strong>Account information</strong>: full name, email address, phone number, password (stored as a salted hash, never in plain text).</li>
        <li><strong>Special personal information</strong> (POPIA section 26): criminal record details you tell us about directly (for example, through our Quick Screener or when contacting our team), including offence descriptions, dates, courts, and sentences, and your ID number where you provide one. Automated extraction of this information from an uploaded document is planned but not live yet — see below.</li>
        <li><strong>Uploaded documents</strong>: you can upload your SAPS criminal record and supporting documents (PDF, JPG, or PNG) today. We currently record only metadata about the upload (file type, a checksum, and a virus-scan status) — <strong>the file content itself is not retained after the upload request completes</strong>, because encrypted long-term document storage is still in development. Do not treat ClearPath Justice as your only copy of any document.</li>
        <li><strong>Usage information</strong>: login timestamps, IP address, and device/browser information, kept for security and audit purposes.</li>
        <li><strong>Chat history</strong> with the AI Assistant, kept for support and audit purposes.</li>
      </ul>

      <h2>3. Why we collect it (lawful basis and purpose limitation)</h2>
      <p>
        We process your information only for the purpose you gave it to us for: assessing your eligibility for
        expungement and preparing your application and supporting documents. We do not use your criminal record
        data for marketing, advertising, or analytics, and we do not sell your information to anyone. Our lawful
        basis is your explicit, informed consent, captured and timestamped when you register, and re-confirmed if
        this policy changes in a material way.
      </p>

      <h2>4. How your information is protected</h2>
      <p>
        Special personal information — your ID number and offence details — is encrypted at the field level
        (AES-256-GCM) in addition to standard database encryption, so that even a raw backup does not expose it in
        plain text. All traffic to and from ClearPath is encrypted in transit (TLS). Access to your case is
        restricted to you and the reviewer(s) assigned to your case, enforced on every request, not just hidden in
        the interface. Every access to your documents, every AI eligibility check, and every reviewer decision on
        your case is logged in a tamper-evident audit trail. Full technical detail on our security architecture is
        available on request — see our <a href="/contact">Contact page</a>.
      </p>

      <h2>5. Human review of eligibility results</h2>
      <p>
        No eligibility result is ever your final legal outcome without human involvement. Today, this happens in one
        of two ways: our Quick Screener applies a fixed, published decision tree for cannabis-related convictions and
        tells you directly that its result is an estimate, not a final decision; for every other type of case, a
        member of our team reviews your situation directly once you contact us. We are building an automated
        eligibility-analysis step (extracting offence details from an uploaded document and checking them against
        expungement law) to run ahead of human review — it is not live yet, and no eligibility decision is currently
        generated by that automated step. This policy will be updated the day it goes live.
      </p>

      <h2>6. Who we share information with</h2>
      <p>
        We do not share your information with third parties except: (a) service providers who process data on our
        behalf (for example, our cloud hosting provider); (b) a partner attorney, paralegal, or ClearPath team member
        directly assigned to your case, where applicable; or (c) where required by law. We do not share your criminal
        record information with employers, credit bureaus, or any other party without your explicit instruction.
        Messages you send through our Contact form are currently delivered to a monitored ClearPath team inbox so we
        can respond quickly during early access; this will move to a dedicated support mailbox before general
        availability.
      </p>

      <h2>7. How long we keep your information</h2>
      <p>
        We intend to retain your case data only for as long as needed to complete your case, plus a limited period
        afterward in case you need to follow up or as required by law. An automated job runs daily to purge expired
        or used login-session and password-reset records once they are no longer needed (currently 30 days). You can
        also request deletion of your own account and its data at any time — see section 8 — which takes effect
        immediately rather than waiting for the scheduled job.
      </p>

      <h2>8. Your rights</h2>
      <p>Under POPIA, you have the right to:</p>
      <ul>
        <li>Access the personal information we hold about you.</li>
        <li>Request a copy of your data in a portable format.</li>
        <li>Correct inaccurate information.</li>
        <li>Request deletion of your account and associated data ("right to erasure").</li>
        <li>Object to processing, or withdraw consent, though this may mean we can no longer assist with your case.</li>
        <li>Lodge a complaint with the Information Regulator of South Africa if you believe we have mishandled your information.</li>
      </ul>
      <p>
        <strong>Self-service tools are available now:</strong> from your dashboard's Account &amp; Data page you can
        download a full export of your data (JSON) and permanently delete your account at any time — both take
        effect immediately, with no need to contact us first. Correction of inaccurate information, objection to
        processing, and complaints to the Information Regulator can still be exercised by contacting us — see our{" "}
        <a href="/contact">Contact page</a>. We aim to respond to any such request within the timeframe required by POPIA.
      </p>

      <h2>9. Where your data is stored</h2>
      <p>
        Our infrastructure is currently hosted with a general-purpose cloud hosting provider, in{" "}
        <strong>a data center outside South Africa (placeholder: Frankfurt, Germany)</strong>.{" "}
        <em>
          [PLACEHOLDER — this location has not been formally confirmed against our actual hosting contract, and the
          POPIA section 72 cross-border transfer safeguards this would require have not yet been put in place]
        </em>{" "}
        We will update this section with a confirmed, verified answer, and complete those safeguards if the
        confirmed location is outside South Africa, before this moves out of early access.
      </p>

      <h2>10. Security incidents</h2>
      <p>
        If a security incident occurs that compromises your personal information, we will notify the Information
        Regulator and affected users as required under POPIA section 22, as soon as reasonably possible.
      </p>

      <h2>11. Children and diversion records</h2>
      <p>
        Our platform is intended for adults managing their own criminal records. Where a record relates to a
        diversion order made when you were under 18, we handle that information with the same protections described
        above, for the sole purpose of assisting you (now an adult) with your own record.
      </p>

      <h2>12. Cookies and local storage</h2>
      <p>
        We use strictly necessary cookies and browser storage to keep you logged in securely and to remember your
        display preferences (such as light or dark mode). We do not use third-party advertising or tracking
        cookies.
      </p>

      <h2>13. Changes to this policy</h2>
      <p>
        The version number at the top of this page identifies which version applied when you registered. If we make
        a material change, we will post the update here and note the new version date; an automatic re-consent
        prompt on login is planned but not built yet, so please check back periodically or contact us if you want to
        confirm which version currently applies to you.
      </p>

      <h2>14. Contact us</h2>
      <p>
        For any privacy question, or a data access/export/deletion request, please use our{" "}
        <a href="/contact">Contact page</a>. Our registered Information Officer under POPIA is{" "}
        <strong>Jane Dlamini</strong> ( <strong>informationofficer@clearpathjustice.org.za</strong>).{" "}
        <em>
          [PLACEHOLDER — this is not a real named individual; POPIA requires a specific, actually-appointed person
          in this role, not a placeholder]
        </em>
      </p>
    </article>
  );
}
