import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About Us",
  description: "ClearPath Justice combines AI-assisted document analysis with human legal review to make criminal record expungement faster and easier to navigate in South Africa.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <article>
      <h1>About ClearPath Justice</h1>
      <p>
        ClearPath Justice exists to remove barriers to employment and
        opportunity by simplifying the criminal record expungement process
        in South Africa. Millions of South Africans carry old, minor
        convictions that quietly block jobs, housing, and credit long after
        they&apos;ve served their sentence.
      </p>
      <p>
        We combine AI-assisted document analysis with human legal review to
        make the expungement process faster and easier to navigate — without
        replacing the judgment of qualified people.
      </p>
      <div className="disclaimer-banner">
        ClearPath Justice is not a law firm and does not provide legal
        advice. We provide informational tools and administrative
        assistance; every eligibility result is reviewed by a person before
        it is treated as final.
      </div>
    </article>
  );
}
