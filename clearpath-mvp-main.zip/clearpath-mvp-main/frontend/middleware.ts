import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";

// Real server-side auth boundary (closes the gap TODO.md item 6 flagged:
// this used to only check for a non-httpOnly `cp_session` presence cookie
// the CLIENT set itself via `document.cookie` — trivially forgeable, and
// not a security control at all). `cp_access` is httpOnly, set only by the
// backend on login/refresh (see backend/src/routes/auth.routes.ts), and
// carries the actual signed access token. This verifies its signature,
// issuer, audience, and expiry — mirroring exactly what
// backend/src/middleware/auth.ts asserts on every API request — before this
// server will render a single byte of /dashboard or /admin.
//
// This does not replace the backend's own per-request checks (every data
// fetch is still authorized independently via the Bearer token from
// sessionStorage, and that remains the real data boundary) — it closes the
// gap where the PAGE SHELL itself was served to anyone who set a cookie.
const JWT_ISSUER = "clearpath-justice";
const JWT_AUDIENCE = "clearpath-justice-api";
const ADMIN_ROLES = new Set(["admin", "super_admin"]);

const secret = process.env.JWT_ACCESS_SECRET ? new TextEncoder().encode(process.env.JWT_ACCESS_SECRET) : null;

async function getVerifiedRole(token: string | undefined): Promise<string | null> {
  if (!token || !secret) return null;
  try {
    const { payload } = await jwtVerify(token, secret, {
      algorithms: ["HS256"],
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
    });
    return typeof payload.role === "string" ? payload.role : null;
  } catch {
    return null;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const loginUrl = new URL("/login", req.url);

  if (pathname === "/admin" || pathname.startsWith("/admin/")) {
    const role = await getVerifiedRole(req.cookies.get("cp_access")?.value);
    if (!role || !ADMIN_ROLES.has(role)) {
      return NextResponse.redirect(loginUrl);
    }
    return NextResponse.next();
  }

  if (pathname === "/dashboard" || pathname.startsWith("/dashboard/")) {
    const role = await getVerifiedRole(req.cookies.get("cp_access")?.value);
    if (!role) {
      return NextResponse.redirect(loginUrl);
    }
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*"],
};
