"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { trackEvent } from "@/lib/analytics";

// Fires the top-of-funnel "visitor" event once per browser tab session (not
// on every client-side route change) — MVP spec §8 tracks visitors as a
// funnel step, not a per-page-view hit.
export default function AnalyticsTracker() {
  const pathname = usePathname();

  useEffect(() => {
    try {
      if (sessionStorage.getItem("cp_visitor_tracked")) return;
      sessionStorage.setItem("cp_visitor_tracked", "1");
      trackEvent("visitor", { source: pathname });
    } catch {
      trackEvent("visitor");
    }
    // Intentionally runs once per mount, not on every pathname change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return null;
}
