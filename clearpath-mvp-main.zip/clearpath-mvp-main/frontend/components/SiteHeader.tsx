"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import ThemeToggle from "./ThemeToggle";

// A logged-in visitor is detected via the non-httpOnly `cp_session` presence
// cookie set by LoginForm.tsx — UI-only (which nav to show), not a security
// signal. The real gate is middleware.ts, which verifies the separate
// httpOnly `cp_access` cookie's JWT instead.
function hasSessionCookie(): boolean {
  return document.cookie.split("; ").some((c) => c.startsWith("cp_session="));
}

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    setOpen(false);
    setLoggedIn(hasSessionCookie());
  }, [pathname]);

  async function handleLogout() {
    setLoggingOut(true);
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/logout`, {
      method: "POST",
      credentials: "include",
    }).catch(() => undefined);
    sessionStorage.removeItem("accessToken");
    document.cookie = "cp_session=; path=/; max-age=0";
    setLoggedIn(false);
    setLoggingOut(false);
    router.push("/");
  }

  return (
    <header className="site-header">
      <Link href="/" className="brand">
        <span className="brand-logo">
          <Image src="/clearpath-logo.jpeg" alt="ClearPath Justice" width={88} height={88} priority />
        </span>
        ClearPath Justice
      </Link>

      <nav className={`nav-links${open ? " is-open" : ""}`}>
        <Link href="/about" className={pathname === "/about" ? "is-active" : ""}>About</Link>
        <Link href="/how-it-works" className={pathname === "/how-it-works" ? "is-active" : ""}>How it Works</Link>
        <Link href="/demo" className={pathname === "/demo" ? "is-active" : ""}>Watch Demo</Link>
        <Link href="/screener" className={pathname === "/screener" ? "is-active" : ""}>Quick Screener</Link>
        <Link href="/refer" className={pathname === "/refer" ? "is-active" : ""}>Get Help</Link>
        <Link href="/faq" className={pathname === "/faq" ? "is-active" : ""}>FAQ</Link>
        <Link href="/contact" className={pathname === "/contact" ? "is-active" : ""}>Contact</Link>
        {loggedIn ? (
          <>
            <Link href="/dashboard" className={pathname === "/dashboard" ? "is-active" : ""}>Dashboard</Link>
            <button type="button" className="cta" onClick={handleLogout} disabled={loggingOut}>
              {loggingOut ? "Logging out..." : "Log out"}
            </button>
          </>
        ) : (
          <>
            <Link href="/login" className={pathname === "/login" ? "is-active" : ""}>Log in</Link>
            <Link href="/register" className="cta">Get Started</Link>
          </>
        )}
      </nav>

      <div className="header-actions">
        <ThemeToggle />
        <button
          type="button"
          className="hamburger-btn"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? "✕" : "☰"}
        </button>
      </div>
    </header>
  );
}
