"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

// Stopgap client-side guard: this codebase currently keeps the access token
// only in sessionStorage (see app/login/LoginForm.tsx), so there is no
// session cookie a Next.js middleware could check server-side. This check
// keeps an unauthenticated visitor from ever seeing the page content, but it
// is not a substitute for server-side authorization — every real data fetch
// still must (and, once wired up, will) require a valid access token
// verified by the backend on every request. See TODO.md.
export default function AuthGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!sessionStorage.getItem("accessToken")) {
      router.replace("/login");
      return;
    }
    setReady(true);
  }, [router]);

  if (!ready) return null;
  return <>{children}</>;
}
