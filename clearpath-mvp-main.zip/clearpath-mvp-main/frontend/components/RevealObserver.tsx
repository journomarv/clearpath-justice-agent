"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";

// Adds a subtle fade/rise-in the first time a card or section scrolls into
// view. Targets only the shared design-system classes so it applies across
// every page without each one wiring up its own observer. Respects
// prefers-reduced-motion by doing nothing (the CSS fallback there shows
// everything at full opacity immediately).
// .hero is excluded: it already gets its own dedicated keyframe entrance
// (see .hero-eyebrow/.hero h1/.hero p in globals.css) and wrapping it in
// this generic reveal too caused a double-animation that visually cancelled
// out — the outer .hero got "reveal" and "is-visible" added in the same
// synchronous pass, before the browser ever painted the opacity:0 state, so
// the transition never had two frames to interpolate between and just
// snapped straight to visible with nothing to see.
const REVEAL_SELECTOR = ".step-card, .screener-card, .disclaimer-banner, main > section:not(.hero)";

export default function RevealObserver() {
  const pathname = usePathname();

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    // Run after paint so freshly-rendered elements for this route exist.
    const raf = requestAnimationFrame(() => {
      const targets = document.querySelectorAll<HTMLElement>(REVEAL_SELECTOR);
      const observer = new IntersectionObserver(
        (entries) => {
          for (const entry of entries) {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              observer.unobserve(entry.target);
            }
          }
        },
        { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
      );

      const alreadyOnScreen: HTMLElement[] = [];

      targets.forEach((el, i) => {
        el.classList.add("reveal");
        el.style.setProperty("--reveal-index", String(i % 6));
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          alreadyOnScreen.push(el);
        } else {
          // Off-screen: let the observer reveal it once the visitor
          // actually scrolls it into view.
          observer.observe(el);
        }
      });

      // Force the browser to commit the opacity:0/translateY starting state
      // to a real paint before flipping to "is-visible" — adding both
      // classes in the same synchronous pass gives the browser nothing to
      // transition *from*, so the fade never has a visible first frame.
      void document.body.offsetHeight;
      requestAnimationFrame(() => {
        alreadyOnScreen.forEach((el) => el.classList.add("is-visible"));
      });

      return () => observer.disconnect();
    });

    return () => cancelAnimationFrame(raf);
  }, [pathname]);

  return null;
}
