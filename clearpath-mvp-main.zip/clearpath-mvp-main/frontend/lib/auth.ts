const API_BASE = process.env.NEXT_PUBLIC_API_URL;

function getAccessToken(): string | null {
  if (typeof window === "undefined") return null;
  return sessionStorage.getItem("accessToken");
}

function setAccessToken(token: string): void {
  sessionStorage.setItem("accessToken", token);
}

async function refreshAccessToken(): Promise<string | null> {
  const res = await fetch(`${API_BASE}/api/v1/auth/refresh`, { method: "POST", credentials: "include" });
  if (!res.ok) return null;
  const { accessToken } = await res.json();
  setAccessToken(accessToken);
  return accessToken;
}

/**
 * Centralizes what every dashboard/admin page needs: attach the access
 * token, and if it's expired, try exactly one silent refresh (rotating the
 * refresh cookie, see backend POST /auth/refresh) before giving up. On a
 * hard failure it clears the session and sends the caller to /login rather
 * than leaving a page stuck retrying against a dead session.
 */
export async function apiFetch(path: string, init: RequestInit = {}): Promise<Response> {
  const doFetch = (token: string | null) =>
    fetch(`${API_BASE}${path}`, {
      ...init,
      credentials: "include",
      headers: {
        ...(init.body && !(init.headers && "Content-Type" in init.headers) ? { "Content-Type": "application/json" } : {}),
        ...init.headers,
        Authorization: `Bearer ${token ?? ""}`,
      },
    });

  let res = await doFetch(getAccessToken());

  if (res.status === 401) {
    const refreshed = await refreshAccessToken();
    if (refreshed) {
      res = await doFetch(refreshed);
    } else {
      sessionStorage.removeItem("accessToken");
      document.cookie = "cp_session=; path=/; max-age=0";
      if (typeof window !== "undefined") window.location.href = "/login";
    }
  }

  return res;
}

export async function apiFetchJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await apiFetch(path, init);
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(body?.error?.message ?? `Request failed (${res.status})`);
  }
  return res.json();
}
