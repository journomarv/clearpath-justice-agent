const API_BASE = process.env.NEXT_PUBLIC_API_URL;
const STORAGE_KEY = "cp_anon_id";

export type AnalyticsEvent =
  | "visitor"
  | "assessment_started"
  | "assessment_completed"
  | "pathway_identified"
  | "action_plan_generated"
  | "case_created"
  | "referral_clicked";

export interface AnalyticsMeta {
  outcome?: "pathway" | "more_info" | "not_met";
  referral?: string;
  source?: string;
}

/**
 * A random, client-generated id — never a user id, email, or anything that
 * ties back to a real identity. Used only so the funnel can distinguish
 * unique visitors from repeat events, per MVP spec §8 ("measure service
 * performance, not monitor individuals").
 */
function getAnonId(): string {
  if (typeof window === "undefined") return "server";
  let id = localStorage.getItem(STORAGE_KEY);
  if (!id) {
    id = crypto.randomUUID();
    try {
      localStorage.setItem(STORAGE_KEY, id);
    } catch {
      // Private-browsing/storage-blocked: fall back to an in-memory id for
      // this page load rather than throwing.
    }
  }
  return id;
}

/**
 * Fire-and-forget. Analytics must never block or break the page it's called
 * from — failures are swallowed silently, no PII is ever included.
 */
export function trackEvent(event: AnalyticsEvent, meta?: AnalyticsMeta): void {
  if (typeof window === "undefined" || !API_BASE) return;
  try {
    const body = JSON.stringify({ event, anonId: getAnonId(), meta });
    if (navigator.sendBeacon) {
      const blob = new Blob([body], { type: "application/json" });
      navigator.sendBeacon(`${API_BASE}/api/v1/analytics/event`, blob);
      return;
    }
    fetch(`${API_BASE}/api/v1/analytics/event`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      keepalive: true,
    }).catch(() => undefined);
  } catch {
    // Never let a tracking failure surface to the user.
  }
}
