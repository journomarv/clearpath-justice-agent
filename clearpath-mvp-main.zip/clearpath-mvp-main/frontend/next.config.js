/** @type {import('next').NextConfig} */

const API_ORIGIN = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

/**
 * Content-Security-Policy.
 *
 * KNOWN LIMITATION — script-src includes 'unsafe-inline'. Next.js App Router
 * streams its RSC payload through inline <script> tags whose contents change
 * every build, so they cannot be hashed, and the only robust alternative is
 * per-request nonces via middleware — which forces every page to render
 * dynamically. That trade wasn't worth making for a mostly-static marketing
 * site at pilot scale.
 *
 * What this policy still buys, even with that gap:
 *   - default-src/script-src 'self'  → no loading attacker-hosted scripts
 *   - connect-src pinned to self + our API → injected code cannot exfiltrate
 *     data to an arbitrary domain, which is the step that turns an XSS into
 *     a breach of criminal-record data
 *   - object-src 'none', base-uri 'self' → no plugin or <base> injection
 *   - form-action 'self' → a fake form cannot post credentials elsewhere
 *   - frame-ancestors 'none' → clickjacking blocked
 *
 * UPGRADE TRIGGER: the moment this app renders user-supplied content —
 * reviewer notes, AI assistant replies, uploaded filenames — 'unsafe-inline'
 * becomes a real risk and this must move to nonce-based CSP. Nothing renders
 * such content today.
 */
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data:",
  `connect-src 'self' ${API_ORIGIN}`,
  "font-src 'self' data:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  "upgrade-insecure-requests",
].join("; ");

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false, // don't advertise the framework to attackers
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "Content-Security-Policy", value: CSP },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          // No page here uses these; denying them limits what injected code
          // could reach for.
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()",
          },
          { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
          { key: "X-DNS-Prefetch-Control", value: "off" },
        ],
      },
      {
        // Belt-and-braces: dashboard/admin are already noindex via metadata,
        // but this also covers non-HTML responses under those paths.
        source: "/(dashboard|admin)/:path*",
        headers: [
          { key: "X-Robots-Tag", value: "noindex, nofollow" },
          { key: "Cache-Control", value: "no-store, must-revalidate" },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
