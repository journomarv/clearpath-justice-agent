# ClearPath Justice — MVP

AI-assisted South African legal-tech platform helping eligible individuals
determine whether they qualify for criminal record expungement, and
automating as much of the application process as legally permissible —
with a human reviewer as the final decision-maker on every case.

**Start here:** [`docs/01-product-specification.md`](docs/01-product-specification.md).
Full deliverable set is in [`/docs`](docs):

| Doc | Contents |
|---|---|
| `01-product-specification.md` | Scope, users, legal guardrails, success metrics, NFRs |
| `02-wireframes.md` | Screen-by-screen wireframes |
| `03-database-schema.md` | Schema design (see also `backend/prisma/schema.prisma`) |
| `04-api-architecture.md` | REST API, service boundaries, async job design |
| `05-ai-workflow.md` | Extraction → rules engine → reasoning → human review pipeline |
| `06-user-journey.md` | End-to-end applicant journey |
| `07-admin-workflow.md` | Reviewer/Admin/Super Admin workflow |
| `08-security-architecture.md` | **PCI-DSS-grade control baseline + POPIA compliance** |
| `09-product-roadmap.md` | Phase 0–5 roadmap |
| `10-sprint-plan.md` | 2-week sprint breakdown |
| `11-development-timeline.md` | Timeline to pilot launch |
| `12-budget.md` | Indicative build + run cost |
| `13-risks-mitigations.md` | Key risks and mitigations |
| `14-future-roadmap.md` | Phase 2–5 detail (payments, integrations, Digital Justice Passport) |

## A note on "PCI-level security"
This MVP does not process payments, so it is not literally in PCI-DSS scope.
We applied PCI-DSS's control *rigor* — encryption everywhere, strict
access control, comprehensive audit logging, formal key management,
vulnerability scanning cadence — to the data that matters here: criminal
records and ID numbers under POPIA. See `docs/08-security-architecture.md`
§0 for the full reasoning and the recommended path if payments are added
later (use a PCI-DSS Level 1 gateway; never store card data yourself).

## Technology stack

| Layer | Choice | Why |
|---|---|---|
| Frontend | Next.js (React, TypeScript), App Router | SSR for fast marketing pages + SEO, one framework for both static site and app, mobile-first responsive by default |
| Backend | Node.js + Express, TypeScript | Same language as frontend (one team can own both), mature ecosystem for security middleware (Helmet, rate-limiting), async-friendly for AI/job workloads |
| Database | PostgreSQL (via Prisma ORM) | Strong relational integrity for legal case data, mature encryption/backup tooling, Prisma prevents raw-SQL injection by construction |
| Authentication | Custom JWT (access) + httpOnly rotating refresh cookie, Argon2id password hashing, TOTP MFA for staff | Full control over session revocation (critical for a legal platform — instant logout on compromise), Argon2id is the current OWASP-recommended hash, avoids vendor lock-in of a third-party auth SaaS while keeping to bcrypt-successor standards |
| OCR | Cloud OCR (e.g. AWS Textract / Google Document AI) — swappable | Handles scanned/photographed SAPS records reliably; avoids maintaining a Tesseract pipeline ourselves in the MVP |
| AI integration | Claude (Anthropic) | Strong structured-extraction and long-context document handling; enterprise data-handling commitments (no training on API inputs by default) suit sensitive criminal-record data |
| Cloud hosting | Managed cloud (e.g. AWS/Azure, Africa region where available) | Data residency for POPIA, managed encryption-at-rest, autoscaling without a dedicated ops team |
| File storage | Encrypted object storage (S3-compatible, SSE-KMS), private buckets, signed URLs | Documents never public; envelope encryption keeps a bucket leak from exposing plaintext |
| Job queue | BullMQ + Redis | Keeps OCR/AI/PDF-generation/malware-scan work off the request path, caps AI-cost exposure via concurrency limits |
| Security framework | Helmet, express-rate-limit, Zod validation, RBAC middleware, append-only audit log, ClamAV-style malware scanning | See `docs/08-security-architecture.md` for the complete control set |

## Repository layout
```
docs/        Full MVP specification (14 deliverables)
backend/     Express + TypeScript API, Prisma schema, security middleware
frontend/    Next.js marketing site + dashboard + admin skeleton
```

## Running locally

### Backend
```bash
cd backend
cp .env.example .env    # fill in real secrets — see comments in the file
npm install
npm run prisma:generate
npm run prisma:migrate  # requires a running Postgres instance
npm run dev             # http://localhost:4000
```

### Frontend
```bash
cd frontend
npm install
echo "NEXT_PUBLIC_API_URL=http://localhost:4000" > .env.local
npm run dev              # http://localhost:3000
```

## What is and isn't implemented in this scaffold
This repository ships a **complete product specification** (all 14
deliverables) and a **working code skeleton** demonstrating the security
architecture, data model, and API/route shapes described in the docs. It is
not a production-ready application yet. Explicitly left as documented TODOs
in the code (see comments in the relevant files):
- OCR + Claude extraction worker wiring (BullMQ processor)
- Deterministic eligibility rules engine implementation
- Encrypted object storage upload (S3-compatible client)
- Malware scanning integration (ClamAV or cloud equivalent)
- Password reset / MFA setup-verify endpoints
- PDF template generation for the application + affidavit (requires
  attorney-reviewed templates before real use — see `docs/13-risks-mitigations.md`)
- Frontend auth context/provider and authenticated-route guards
- CI/CD, infrastructure-as-code, and the actual cloud deployment

Before any pilot with real users: complete the above, run a third-party
penetration test, and have the generated legal document templates reviewed
by a South African attorney (see `docs/11-development-timeline.md` for the
recommended buffer).
