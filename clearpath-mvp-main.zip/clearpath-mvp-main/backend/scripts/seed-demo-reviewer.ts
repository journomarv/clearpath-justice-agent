import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/utils/password";
import { encryptField } from "../src/utils/encryption";

const prisma = new PrismaClient();

async function main() {
  const email = "reviewer-demo@example.com";
  const passwordHash = await hashPassword("demo-reviewer-pass-123");
  await prisma.user.upsert({
    where: { email },
    update: {},
    create: {
      email,
      passwordHash,
      fullNameEnc: encryptField("Demo Reviewer"),
      role: "reviewer",
      consentVersion: "2026-08-01",
      consentAt: new Date(),
      status: "active",
    },
  });
  console.log("Seeded reviewer:", email);
}

main().finally(() => prisma.$disconnect());
