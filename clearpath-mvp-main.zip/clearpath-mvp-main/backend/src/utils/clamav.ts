import { createScanner, isCleanReply } from "clamdjs";
import { env } from "../config/env";

const scanner = createScanner(env.CLAMAV_HOST, env.CLAMAV_PORT);
const SCAN_TIMEOUT_MS = 30_000;

/**
 * Scans a buffer against clamd before it's ever persisted (docs/05-ai-workflow.md
 * pipeline step 2). Throws on a scanner-connectivity failure — callers must
 * treat "couldn't scan" as "don't store", not as "assume clean".
 */
export async function scanBuffer(buffer: Buffer): Promise<{ infected: boolean; virusName: string | null }> {
  const reply = await scanner.scanBuffer(buffer, SCAN_TIMEOUT_MS, 64 * 1024);
  if (isCleanReply(reply)) {
    return { infected: false, virusName: null };
  }
  const match = reply.match(/:\s*(.+)\s+FOUND/);
  return { infected: true, virusName: match?.[1] ?? "unknown" };
}
