import pino from "pino";

const SENSITIVE_FIELDS = [
  "password",
  "passwordHash",
  "idNumber",
  "idNumberEnc",
  "mfaSecret",
  "authorization",
  "refreshToken",
  "accessToken",
];

// Redact known-sensitive keys wherever they appear in logged objects —
// belt-and-suspenders alongside never logging raw PII in the first place.
export const logger = pino({
  redact: { paths: SENSITIVE_FIELDS, censor: "[REDACTED]" },
  level: process.env.NODE_ENV === "production" ? "info" : "debug",
});
