import { Queue } from "bullmq";
import IORedis from "ioredis";
import { env } from "../config/env";

/**
 * A fresh connection per caller. BullMQ Workers issue blocking commands
 * (BRPOPLPUSH-style) on their connection; sharing one ioredis instance
 * between a Worker and a Queue causes the Queue's commands to stall behind
 * the Worker's blocking read — reproduced as a hang in this exact process
 * (the worker process never progressed past `queue.add()` once a Worker had
 * been constructed on the same shared connection). Each Queue/Worker gets
 * its own connection instead.
 */
export function createRedisConnection(): IORedis {
  // BullMQ requires this exact option on every connection it's given.
  return new IORedis(env.REDIS_URL, { maxRetriesPerRequest: null });
}

export const ELIGIBILITY_QUEUE_NAME = "eligibility";

export const eligibilityQueue = new Queue(ELIGIBILITY_QUEUE_NAME, { connection: createRedisConnection() });

export const RETENTION_QUEUE_NAME = "retention";

export const retentionQueue = new Queue(RETENTION_QUEUE_NAME, { connection: createRedisConnection() });
