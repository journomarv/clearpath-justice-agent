import argon2 from "argon2";

// Argon2id — memory-hard, resistant to GPU cracking, OWASP-recommended over
// bcrypt/scrypt for new systems. See docs/08-security-architecture.md §2.
const ARGON2_OPTIONS: argon2.Options = {
  type: argon2.argon2id,
  memoryCost: 19456, // ~19 MB, OWASP minimum recommendation
  timeCost: 2,
  parallelism: 1,
};

export async function hashPassword(plaintext: string): Promise<string> {
  return argon2.hash(plaintext, ARGON2_OPTIONS);
}

export async function verifyPassword(hash: string, plaintext: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plaintext);
  } catch {
    // Malformed hash (e.g. legacy format) — treat as verification failure,
    // never throw into an auth code path.
    return false;
  }
}

export function isPasswordStrongEnough(plaintext: string): boolean {
  // Length-based policy (NIST 800-63B guidance: prefer length over forced
  // complexity rules that push users toward predictable substitutions).
  return plaintext.length >= 12 && plaintext.length <= 128;
}

// A real Argon2id hash of a value nobody can log in with. Verifying against
// this costs the same as verifying a genuine account's hash.
const DUMMY_HASH_PROMISE: Promise<string> = argon2.hash(
  "clearpath-nonexistent-account-placeholder",
  ARGON2_OPTIONS
);

/**
 * Spends roughly the same time a real password check would, then discards
 * the result. Call this on the "no such user" branch of login so that branch
 * is not measurably faster than "user exists, wrong password" — otherwise
 * response latency alone reveals which email addresses have accounts. On
 * this platform an account implies a criminal record, so that inference is
 * itself sensitive.
 */
export async function burnPasswordVerifyTime(candidate: string): Promise<void> {
  try {
    await argon2.verify(await DUMMY_HASH_PROMISE, candidate);
  } catch {
    // Result is irrelevant; we only want the elapsed cost.
  }
}
