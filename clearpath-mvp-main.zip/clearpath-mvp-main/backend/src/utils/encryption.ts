import crypto from "crypto";
import { env } from "../config/env";

// AES-256-GCM field-level encryption for special personal information
// (ID numbers, offence descriptions, MFA secrets, etc — see
// docs/08-security-architecture.md §3). This is a defense-in-depth layer
// ON TOP OF provider-managed encryption-at-rest: a raw DB backup/leak alone
// is not enough to disclose plaintext.
//
// In production FIELD_ENCRYPTION_KEY_BASE64 must be sourced from a managed
// KMS/secrets manager, not a .env file — see .env.example.

const KEY = Buffer.from(env.FIELD_ENCRYPTION_KEY_BASE64, "base64");
if (KEY.length !== 32) {
  throw new Error(
    "FIELD_ENCRYPTION_KEY_BASE64 must decode to exactly 32 bytes (AES-256)."
  );
}

const IV_LENGTH = 12; // 96-bit IV recommended for GCM
const AUTH_TAG_LENGTH = 16;

/** Encrypts plaintext, returning a single base64 string: iv || authTag || ciphertext */
export function encryptField(plaintext: string): string {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, ciphertext]).toString("base64");
}

/** Reverses encryptField. Throws if the ciphertext has been tampered with. */
export function decryptField(payload: string): string {
  const raw = Buffer.from(payload, "base64");
  const iv = raw.subarray(0, IV_LENGTH);
  const authTag = raw.subarray(IV_LENGTH, IV_LENGTH + AUTH_TAG_LENGTH);
  const ciphertext = raw.subarray(IV_LENGTH + AUTH_TAG_LENGTH);
  const decipher = crypto.createDecipheriv("aes-256-gcm", KEY, iv);
  decipher.setAuthTag(authTag);
  const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  return plaintext.toString("utf8");
}

/** SHA-256 checksum for uploaded file integrity verification. */
export function sha256(buffer: Buffer): string {
  return crypto.createHash("sha256").update(buffer).digest("hex");
}

/**
 * Binary counterpart to encryptField, for document bytes. Layered on top of
 * MinIO's own server-side encryption (docs/08-security-architecture.md §3
 * "defense in depth against a raw DB/storage backup leak") — a compromise of
 * the object store alone still isn't enough to read a stored document.
 * Returns iv || authTag || ciphertext as a single Buffer.
 */
export function encryptBuffer(plaintext: Buffer): Buffer {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, ciphertext]);
}

/** Reverses encryptBuffer. Throws if the ciphertext has been tampered with. */
export function decryptBuffer(payload: Buffer): Buffer {
  const iv = payload.subarray(0, IV_LENGTH);
  const authTag = payload.subarray(IV_LENGTH, IV_LENGTH + AUTH_TAG_LENGTH);
  const ciphertext = payload.subarray(IV_LENGTH + AUTH_TAG_LENGTH);
  const decipher = crypto.createDecipheriv("aes-256-gcm", KEY, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}
