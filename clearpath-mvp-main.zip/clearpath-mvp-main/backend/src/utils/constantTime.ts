import type { CookieOptions, Response } from "express";

/**
 * Pads every login outcome to the same wall-clock floor before any bytes go
 * back to the client.
 *
 * Login branches do measurably different amounts of work: an unknown address
 * performs one read, while a known address with a wrong password also writes
 * a failed-login counter and an audit row. Measured on this codebase that was
 * ~28ms vs ~62ms — enough to determine, from latency alone, whether an email
 * address has an account. Because an account here implies a criminal record,
 * that inference is sensitive by itself.
 *
 * IMPORTANT — why this returns a payload instead of wrapping the handler:
 * res.json() flushes the response as soon as it is called, so sleeping after
 * the handler finishes delays nothing the client can observe. The response
 * must be *described* first, held for the remainder of the floor, and only
 * then sent. An earlier version of this file got that wrong and provided no
 * protection at all.
 *
 * Keep the floor comfortably above the slowest real branch; if genuine work
 * ever exceeds it, the padding stops hiding anything.
 */
export const LOGIN_MIN_RESPONSE_MS = 250;

export interface DeferredResponse {
  status: number;
  body: unknown;
  cookies?: { name: string; value: string; options: CookieOptions }[];
}

export async function sendAfterMinimumDuration(
  res: Response,
  minMs: number,
  work: () => Promise<DeferredResponse>
): Promise<void> {
  const startedAt = Date.now();
  let payload: DeferredResponse;

  try {
    payload = await work();
  } catch (err) {
    // Pad failures too — an error path that returns faster than a success
    // path is its own signal. Rethrow after waiting so the central error
    // handler still produces the 500.
    await sleepRemaining(startedAt, minMs);
    throw err;
  }

  await sleepRemaining(startedAt, minMs);

  for (const cookie of payload.cookies ?? []) {
    res.cookie(cookie.name, cookie.value, cookie.options);
  }
  res.status(payload.status).json(payload.body);
}

async function sleepRemaining(startedAt: number, minMs: number): Promise<void> {
  const remaining = minMs - (Date.now() - startedAt);
  if (remaining > 0) {
    await new Promise((resolve) => setTimeout(resolve, remaining));
  }
}
