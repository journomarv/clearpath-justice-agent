import { Request, Response, NextFunction, RequestHandler } from "express";

/**
 * Wraps an async route handler so a rejected promise is forwarded to
 * Express's error middleware instead of becoming an unhandled rejection.
 *
 * WHY THIS EXISTS — this is not a style preference, it fixes a verified
 * remote denial-of-service:
 *
 * Express 4 does not await route handlers. If an `async` handler rejects,
 * Express never sees the error, the client gets no response, and Node 20
 * (whose default is `--unhandled-rejections=throw`) TERMINATES THE PROCESS.
 * A single failing database call therefore takes down the whole API for
 * every user, and any input that reliably throws becomes a trivial DoS.
 *
 * Every async handler in this codebase MUST be wrapped in this. If you add
 * a route and forget, you reintroduce the crash.
 */
export function asyncHandler(
  handler: (req: Request, res: Response, next: NextFunction) => Promise<unknown>
): RequestHandler {
  return (req, res, next) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
}
