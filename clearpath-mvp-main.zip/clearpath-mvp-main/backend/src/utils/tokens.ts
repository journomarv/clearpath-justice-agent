import jwt from "jsonwebtoken";
import { env } from "../config/env";

export const JWT_ALGORITHM = "HS256" as const;
export const JWT_ISSUER = "clearpath-justice";
export const JWT_AUDIENCE = "clearpath-justice-api";

/**
 * Signs a short-lived access token.
 *
 * `algorithm`, `issuer` and `audience` are set explicitly here and asserted
 * explicitly on the verify side. Pinning the algorithm is what stops an
 * attacker-supplied token header from choosing a weaker one (the classic
 * "alg confusion" class of bug); issuer/audience stop a token minted for a
 * different service from being replayed against this one.
 */
export function signAccessToken(userId: string, role: string): string {
  return jwt.sign({ role }, env.JWT_ACCESS_SECRET, {
    subject: userId,
    algorithm: JWT_ALGORITHM,
    issuer: JWT_ISSUER,
    audience: JWT_AUDIENCE,
    expiresIn: env.JWT_ACCESS_TTL as jwt.SignOptions["expiresIn"],
  });
}

// A distinct audience (and the refresh secret, not the access secret) so an
// MFA challenge token can never be replayed as — or confused with — a real
// access token; it proves only "this user just passed the password check",
// nothing more, and expires in 5 minutes.
export const MFA_CHALLENGE_AUDIENCE = "clearpath-justice-mfa-challenge";

export function signMfaChallengeToken(userId: string): string {
  return jwt.sign({}, env.JWT_REFRESH_SECRET, {
    subject: userId,
    algorithm: JWT_ALGORITHM,
    issuer: JWT_ISSUER,
    audience: MFA_CHALLENGE_AUDIENCE,
    expiresIn: "5m",
  });
}

/** Returns the user id the challenge token was issued for, or null if invalid/expired. */
export function verifyMfaChallengeToken(token: string): string | null {
  try {
    const payload = jwt.verify(token, env.JWT_REFRESH_SECRET, {
      algorithms: [JWT_ALGORITHM],
      issuer: JWT_ISSUER,
      audience: MFA_CHALLENGE_AUDIENCE,
    }) as jwt.JwtPayload;
    return typeof payload.sub === "string" ? payload.sub : null;
  } catch {
    return null;
  }
}
