import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  ListObjectsV2Command,
} from "@aws-sdk/client-s3";
import { env } from "../config/env";
import { prisma } from "./prisma";

// Talks to a self-hosted MinIO container (S3-compatible API) rather than a
// real cloud bucket — see development-status.md for why: no cloud account
// was available, and this host already runs MinIO for another project.
// forcePathStyle is required for MinIO (virtual-hosted-style bucket URLs
// don't work against it the way they do against real AWS).
const client = new S3Client({
  region: env.STORAGE_REGION,
  endpoint: env.STORAGE_ENDPOINT,
  forcePathStyle: Boolean(env.STORAGE_ENDPOINT),
  credentials:
    env.STORAGE_ACCESS_KEY_ID && env.STORAGE_SECRET_ACCESS_KEY
      ? { accessKeyId: env.STORAGE_ACCESS_KEY_ID, secretAccessKey: env.STORAGE_SECRET_ACCESS_KEY }
      : undefined,
});

async function streamToBuffer(stream: unknown): Promise<Buffer> {
  const chunks: Buffer[] = [];
  for await (const chunk of stream as AsyncIterable<Buffer>) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}

/** Uploads already-encrypted bytes (see encryptBuffer) at the given key. */
export async function putObject(key: string, body: Buffer): Promise<void> {
  await client.send(
    new PutObjectCommand({ Bucket: env.STORAGE_BUCKET, Key: key, Body: body })
  );
}

/** Fetches the raw (still-encrypted) bytes stored at the given key. */
export async function getObject(key: string): Promise<Buffer> {
  const result = await client.send(
    new GetObjectCommand({ Bucket: env.STORAGE_BUCKET, Key: key })
  );
  return streamToBuffer(result.Body);
}

export async function deleteObject(key: string): Promise<void> {
  await client.send(new DeleteObjectCommand({ Bucket: env.STORAGE_BUCKET, Key: key }));
}

/**
 * Called on account deletion (see account.routes.ts POST /delete) and by the
 * retention job as a backstop for anything missed at delete-time. Storage
 * keys are namespaced `${userId}/...` (see documents.routes.ts), so listing
 * by that prefix is enough to find every object without a DB join.
 */
export async function deleteUserDocuments(userId: string): Promise<void> {
  const documents = await prisma.document.findMany({
    where: { userId },
    select: { storageKey: true },
  });

  for (const { storageKey } of documents) {
    await deleteObject(storageKey).catch(() => undefined);
  }

  // Defense in depth: also sweep by prefix in case a document row was ever
  // deleted without its object being cleaned up (should not happen, but a
  // storage-layer leak of that kind must not survive an erasure request).
  let continuationToken: string | undefined;
  do {
    const page = await client.send(
      new ListObjectsV2Command({
        Bucket: env.STORAGE_BUCKET,
        Prefix: `${userId}/`,
        ContinuationToken: continuationToken,
      })
    );
    for (const obj of page.Contents ?? []) {
      if (obj.Key) await deleteObject(obj.Key).catch(() => undefined);
    }
    continuationToken = page.IsTruncated ? page.NextContinuationToken : undefined;
  } while (continuationToken);
}
