import { PrismaClient } from "@prisma/client";

// Single shared Prisma client. Query logging is deliberately minimal in
// production to avoid leaking special personal information into logs
// (docs/08-security-architecture.md §4).
export const prisma = new PrismaClient({
  log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
});
