import Anthropic from "@anthropic-ai/sdk";
import { z } from "zod";
import { env } from "../config/env";
import { logger } from "../utils/logger";

const anthropic = env.ANTHROPIC_API_KEY ? new Anthropic({ apiKey: env.ANTHROPIC_API_KEY }) : null;

const SENTENCE_TYPES = ["fine", "imprisonment", "imprisonment_suspended", "caution", "other"] as const;

export interface ExtractedOffence {
  offenceDescription: string;
  offenceDate: string | null;
  court: string | null;
  sentenceType: (typeof SENTENCE_TYPES)[number] | null;
  sentenceDetails: string | null;
  confidence: number; // 0-1
}

const EXTRACTION_SYSTEM_PROMPT = `You extract structured offence data from South African SAPS
criminal record documents. Return ONLY a raw JSON array — no markdown code fences, no prose
before or after it — matching the schema you are given. sentenceType must be exactly one of:
"fine", "imprisonment", "imprisonment_suspended", "caution", "other", or null if unclear.
confidence must be a number from 0 to 1 (not a word like "high"). Never infer facts that are
not present in the document text — mark low confidence instead of guessing. This output feeds
a downstream legal eligibility check; accuracy matters more than completeness.`;

// Model output is untrusted input from here on — validated field by field
// rather than cast, since a malformed or out-of-enum value (observed in
// practice: Claude returning sentenceType as free text like "Fine or
// imprisonment", or confidence as the word "high") would otherwise reach
// Prisma's typed enum column and throw.
const extractedOffenceSchema = z.object({
  offenceDescription: z.string().min(1),
  offenceDate: z.string().nullable().default(null),
  court: z.string().nullable().default(null),
  sentenceType: z
    .union([z.enum(SENTENCE_TYPES), z.string()])
    .nullable()
    .default(null)
    .transform((v) => (v && (SENTENCE_TYPES as readonly string[]).includes(v) ? (v as ExtractedOffence["sentenceType"]) : null)),
  sentenceDetails: z.string().nullable().default(null),
  confidence: z
    .union([z.number(), z.string()])
    .default(0.5)
    .transform((v) => {
      if (typeof v === "number") return Math.min(Math.max(v, 0), 1);
      const wordScale: Record<string, number> = { high: 0.9, medium: 0.6, low: 0.3 };
      return wordScale[v.toLowerCase()] ?? 0.5;
    }),
});

/** Strips a ```json ... ``` or ``` ... ``` wrapper some models add despite being told not to. */
function stripMarkdownFence(text: string): string {
  const match = text.trim().match(/^```(?:json)?\s*([\s\S]*?)\s*```$/);
  return match?.[1] ?? text;
}

/**
 * Step 1 of the AI workflow (docs/05-ai-workflow.md): structured extraction
 * only. The actual eligibility VERDICT is produced by the deterministic
 * rules engine (see rulesEngine.service.ts) — the LLM never decides
 * eligibility directly.
 */
export async function extractOffencesFromText(documentText: string): Promise<ExtractedOffence[]> {
  if (!anthropic) {
    throw new Error("ANTHROPIC_API_KEY not configured");
  }

  const message = await anthropic.messages.create({
    model: env.ANTHROPIC_MODEL,
    max_tokens: 4096,
    system: EXTRACTION_SYSTEM_PROMPT,
    messages: [
      {
        role: "user",
        content: `Extract all offences from this SAPS criminal record text as a JSON array
matching: [{ offenceDescription, offenceDate, court, sentenceType, sentenceDetails, confidence }]

DOCUMENT TEXT:
"""
${documentText}
"""`,
      },
    ],
  });

  const textBlock = message.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") return [];

  let parsed: unknown;
  try {
    parsed = JSON.parse(stripMarkdownFence(textBlock.text));
  } catch (err) {
    // Malformed model output — surface as empty result so the pipeline
    // routes this document to manual review rather than crashing.
    logger.warn({ err, rawResponse: textBlock.text }, "Extraction response was not valid JSON");
    return [];
  }

  const result = z.array(extractedOffenceSchema).safeParse(parsed);
  if (!result.success) {
    logger.warn({ issues: result.error.issues, rawResponse: textBlock.text }, "Extraction response failed schema validation");
    return [];
  }
  return result.data;
}

/**
 * Step 3 of the AI workflow: given the deterministic rules-engine verdict,
 * produce a plain-language explanation for the applicant. The verdict
 * itself is a PARAMETER here, never derived by the model.
 */
export async function explainEligibilityVerdict(params: {
  offence: ExtractedOffence;
  verdict: "eligible" | "not_eligible" | "uncertain";
  ruleReasonCodes: string[];
}): Promise<string> {
  if (!anthropic) {
    throw new Error("ANTHROPIC_API_KEY not configured");
  }

  const message = await anthropic.messages.create({
    model: env.ANTHROPIC_MODEL,
    max_tokens: 512,
    system: `You explain South African expungement eligibility results in plain,
compassionate language for a non-lawyer. You are given the FINAL verdict already
decided by a rules engine — do not contradict it or invent a different outcome.
Always end with: "This is an AI-assisted estimate, not a legal decision. A ClearPath
reviewer will confirm before your application is generated."`,
    messages: [
      {
        role: "user",
        content: `Offence: ${JSON.stringify(params.offence)}\nVerdict: ${params.verdict}\nReason codes: ${params.ruleReasonCodes.join(", ")}`,
      },
    ],
  });

  const textBlock = message.content.find((b) => b.type === "text");
  return textBlock && textBlock.type === "text" ? textBlock.text : "";
}
