import type { SentenceType } from "@prisma/client";

/**
 * Shape of RulesVersion.ruleset (see migration
 * 20260803160000_seed_initial_rules_version). Legal/rules teams edit future
 * versions by inserting a new rules_versions row, not by changing this code
 * — see docs/05-ai-workflow.md "Deterministic rules engine vs. LLM".
 */
export interface Ruleset {
  waitingPeriodDaysBySentenceType: Partial<Record<SentenceType, number>>;
  excludedOffenceKeywords: string[];
}

export type Verdict = "eligible" | "not_eligible" | "uncertain";

export interface RuleEvaluation {
  verdict: Verdict;
  reasonCodes: string[];
}

/** Decrypted offence facts — callers decrypt offenceDescriptionEnc before calling in. */
export interface OffenceFacts {
  offenceDescription: string;
  offenceDate: Date | null;
  sentenceType: SentenceType | null;
}

/**
 * Deterministic evaluation of a single offence against a versioned ruleset
 * and the applicant's other offences (for the disqualifying-subsequent-
 * conviction check). The LLM never decides this — see aiEligibility.service.ts.
 *
 * NOT yet reviewed by a South African attorney — see TODO.md item 3. This
 * encodes the Criminal Procedure Act 271A-style criteria described in
 * docs/05-ai-workflow.md at MVP fidelity, not a legal opinion.
 */
export function evaluateOffence(
  offence: OffenceFacts,
  otherOffences: Pick<OffenceFacts, "offenceDate">[],
  ruleset: Ruleset
): RuleEvaluation {
  if (!offence.offenceDate || !offence.sentenceType) {
    return { verdict: "uncertain", reasonCodes: ["INSUFFICIENT_DATA"] };
  }

  if (isExcludedOffence(offence.offenceDescription, ruleset.excludedOffenceKeywords)) {
    return { verdict: "not_eligible", reasonCodes: ["EXCLUDED_OFFENCE_SCHEDULE"] };
  }

  const waitingPeriodDays = ruleset.waitingPeriodDaysBySentenceType[offence.sentenceType];
  if (waitingPeriodDays === undefined) {
    return { verdict: "uncertain", reasonCodes: ["UNKNOWN_SENTENCE_TYPE_FOR_RULESET"] };
  }

  const waitingPeriodEndsAt = new Date(offence.offenceDate.getTime() + waitingPeriodDays * 24 * 60 * 60 * 1000);
  if (waitingPeriodEndsAt > new Date()) {
    return { verdict: "not_eligible", reasonCodes: ["WAITING_PERIOD_NOT_ELAPSED"] };
  }

  const hasDisqualifyingSubsequentConviction = otherOffences.some(
    (other) =>
      other.offenceDate &&
      other.offenceDate > offence.offenceDate! &&
      other.offenceDate <= waitingPeriodEndsAt
  );
  if (hasDisqualifyingSubsequentConviction) {
    return { verdict: "not_eligible", reasonCodes: ["SUBSEQUENT_CONVICTION_DURING_WAITING_PERIOD"] };
  }

  return { verdict: "eligible", reasonCodes: ["WAITING_PERIOD_SATISFIED_NO_EXCLUSIONS"] };
}

function isExcludedOffence(description: string, keywords: string[]): boolean {
  const lower = description.toLowerCase();
  return keywords.some((keyword) => lower.includes(keyword.toLowerCase()));
}
