import nodemailer from "nodemailer";
import { env } from "../config/env";
import { logger } from "../utils/logger";

/**
 * Mail is handed to the local postfix instance on 127.0.0.1:25 rather than an
 * external API. That instance already signs outbound mail with OpenDKIM for
 * terminalvelocityai.tech, so messages sent from an address at that domain
 * carry a valid DKIM signature and align with the domain's SPF/DMARC records.
 * Sending "from" a Gmail address instead would fail DMARC and land in spam.
 */
const transporter = nodemailer.createTransport({
  host: env.SMTP_HOST,
  port: env.SMTP_PORT,
  secure: false,
  // Local submission on loopback; no credentials, and TLS is unnecessary for
  // a connection that never leaves the host.
  tls: { rejectUnauthorized: false },
});

/**
 * Strips CR/LF from any value that will be placed in a mail header.
 *
 * Without this, a newline in a submitted name or subject lets the submitter
 * terminate the header and inject their own — adding Bcc recipients and
 * turning this endpoint into an open relay for spam. Nodemailer guards much
 * of this, but the sanitising happens here so the guarantee doesn't depend on
 * a library's internals.
 */
function sanitiseHeaderValue(value: string, maxLength = 200): string {
  return value.replace(/[\r\n]+/g, " ").trim().slice(0, maxLength);
}

export interface ContactSubmission {
  name: string;
  email: string;
  message: string;
  submittedAt: Date;
  ip?: string;
}

export async function sendContactSubmission(submission: ContactSubmission): Promise<void> {
  const name = sanitiseHeaderValue(submission.name);
  const email = sanitiseHeaderValue(submission.email, 320);

  // Body is plain text, so message content cannot inject markup or headers.
  // The submitter's address goes in Reply-To (not From) so the message still
  // passes DMARC for our own domain while remaining easy to reply to.
  const text = [
    "New contact form submission from the ClearPath Justice website.",
    "",
    `Name:    ${name}`,
    `Email:   ${email}`,
    `Time:    ${submission.submittedAt.toISOString()}`,
    `Source IP: ${submission.ip ?? "unknown"}`,
    "",
    "Message:",
    "--------",
    submission.message,
  ].join("\n");

  await transporter.sendMail({
    from: { name: "ClearPath Justice Website", address: env.MAIL_FROM },
    to: env.CONTACT_RECIPIENT,
    replyTo: `${name} <${email}>`,
    subject: sanitiseHeaderValue(`ClearPath Justice contact form — ${name}`),
    text,
  });

  // Deliberately does not log the message body or the submitter's address:
  // people contacting an expungement service may disclose criminal-record
  // details, which must not end up in application logs.
  logger.info({ submittedAt: submission.submittedAt }, "Contact submission emailed");
}

export async function sendPasswordResetEmail(to: string, resetUrl: string): Promise<void> {
  const text = [
    "We received a request to reset the password on your ClearPath Justice account.",
    "",
    "If this was you, choose a new password here (link expires in 1 hour):",
    resetUrl,
    "",
    "If you didn't request this, you can safely ignore this email — your password will not be changed.",
    "",
    "ClearPath Justice is not a law firm and does not provide legal advice.",
  ].join("\n");

  await transporter.sendMail({
    from: { name: "ClearPath Justice", address: env.MAIL_FROM },
    to: sanitiseHeaderValue(to, 320),
    subject: "Reset your ClearPath Justice password",
    text,
  });

  // No email address or token in the log — see the same reasoning as
  // sendContactSubmission above.
  logger.info("Password reset email sent");
}

/** Verifies the local MTA is reachable. Used at boot for a clear failure signal. */
export async function verifyMailTransport(): Promise<boolean> {
  try {
    await transporter.verify();
    return true;
  } catch (err) {
    logger.error({ err }, "Mail transport verification failed");
    return false;
  }
}
