import { PDFParse } from "pdf-parse";
import { createWorker } from "tesseract.js";

export interface ExtractionResult {
  text: string;
  needsManualReview: boolean;
}

/**
 * MVP scope (see development-status.md): pdf-parse handles text-layer PDFs,
 * tesseract.js (pure JS/WASM, no system binary) handles JPEG/PNG. A scanned
 * or image-only PDF has no extractable text layer — rather than silently
 * returning nothing, that's detected and routed to manual review. Full
 * PDF-page-rasterization OCR (needs a poppler/graphicsmagick system
 * dependency) is an explicit follow-up, not attempted here.
 */
export async function extractText(buffer: Buffer, mimeType: string): Promise<ExtractionResult> {
  if (mimeType === "application/pdf") {
    const parser = new PDFParse({ data: buffer });
    try {
      const result = await parser.getText();
      const text = result.text.trim();
      if (text.length < 20) {
        return { text: "", needsManualReview: true };
      }
      return { text, needsManualReview: false };
    } finally {
      await parser.destroy();
    }
  }

  if (mimeType === "image/jpeg" || mimeType === "image/png") {
    const worker = await createWorker("eng");
    try {
      const { data } = await worker.recognize(buffer);
      return { text: data.text.trim(), needsManualReview: data.text.trim().length < 20 };
    } finally {
      await worker.terminate();
    }
  }

  return { text: "", needsManualReview: true };
}
