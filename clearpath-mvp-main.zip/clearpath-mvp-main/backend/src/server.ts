import { app } from "./app";
import { env } from "./config/env";
import { logger } from "./utils/logger";
import { prisma } from "./utils/prisma";

const server = app.listen(env.PORT, () => {
  logger.info(`ClearPath Justice API listening on port ${env.PORT} (${env.NODE_ENV})`);
});

// Slowloris-style protection: a client that opens a connection and dribbles
// headers forever would otherwise hold a socket indefinitely.
server.headersTimeout = 20_000;
server.requestTimeout = 60_000;
server.keepAliveTimeout = 15_000;

/**
 * Last-resort safety nets.
 *
 * Every async route is wrapped in asyncHandler(), so a rejection should
 * reach Express's error middleware and never arrive here. These handlers
 * exist because if one ever *does* slip through, Node 20's default
 * behaviour is to kill the process instantly — dropping every in-flight
 * request from every other user with no log line explaining why.
 *
 * We log first, then shut down deliberately: an unknown-state process
 * handling criminal-record data should not keep serving traffic, but it
 * should leave evidence and let in-flight work finish.
 */
function shutdown(reason: string, error: unknown, exitCode: number) {
  logger.fatal({ err: error, reason }, "Fatal error — shutting down");

  // Force-exit if graceful close stalls, so the supervisor can restart us.
  const forceExit = setTimeout(() => process.exit(exitCode), 10_000);
  forceExit.unref();

  server.close(() => {
    void prisma.$disconnect().finally(() => process.exit(exitCode));
  });
}

process.on("unhandledRejection", (reason) => shutdown("unhandledRejection", reason, 1));
process.on("uncaughtException", (error) => shutdown("uncaughtException", error, 1));

// Graceful shutdown on supervisor signals (pm2 restart/stop).
for (const signal of ["SIGTERM", "SIGINT"] as const) {
  process.on(signal, () => {
    logger.info({ signal }, "Received shutdown signal");
    const forceExit = setTimeout(() => process.exit(0), 10_000);
    forceExit.unref();
    server.close(() => {
      void prisma.$disconnect().finally(() => process.exit(0));
    });
  });
}
