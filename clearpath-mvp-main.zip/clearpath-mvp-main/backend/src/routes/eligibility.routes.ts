import { Router, type Request } from "express";
import crypto from "crypto";
import { z } from "zod";
import { requireAuth } from "../middleware/auth";
import { prisma } from "../utils/prisma";
import { aiRateLimit } from "../middleware/security";
import { asyncHandler } from "../utils/asyncHandler";
import { eligibilityQueue } from "../utils/queue";
import { decryptField, encryptField } from "../utils/encryption";
import { evaluateOffence, type Ruleset } from "../services/rulesEngine.service";
import { explainEligibilityVerdict } from "../services/aiEligibility.service";
import { env } from "../config/env";
import { writeAuditLog } from "../middleware/auditLog";
import { logger } from "../utils/logger";
import type { EligibilityJobData, EligibilityJobResult } from "../workers/eligibility.worker";

export const eligibilityRouter = Router();

const analyzeSchema = z.object({ documentId: z.string().uuid() });

eligibilityRouter.post(
  "/analyze",
  requireAuth,
  // Rate-limited separately from ordinary API calls: this path is the one
  // that spends money on model inference once a real key is configured.
  aiRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = analyzeSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "A valid documentId is required." } });
    }

    const document = await prisma.document.findFirst({
      where: { id: parsed.data.documentId, userId: req.auth!.sub },
    });
    if (!document) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Document not found" } });
    }
    if (document.virusScanStatus !== "clean") {
      return res.status(409).json({ error: { code: "NOT_AVAILABLE", message: "This document is not available for analysis." } });
    }

    // A random job id, not derived from documentId — the previous placeholder
    // used `job_${documentId}`, which would have let one user guess and poll
    // the status of another user's analysis job.
    const jobId = crypto.randomUUID();
    const data: EligibilityJobData = { documentId: document.id, userId: req.auth!.sub };
    // Anthropic's API returns a transient 529 "Overloaded" under real load
    // (observed directly in production during this feature's rollout) —
    // retried with backoff here rather than hard-failing the job on what is
    // usually a momentary capacity blip, not a real extraction failure.
    await eligibilityQueue.add("analyze", data, {
      jobId,
      attempts: 3,
      backoff: { type: "exponential", delay: 5000 },
    });

    return res.status(202).json({ jobId, status: "queued" });
  })
);

eligibilityRouter.get(
  "/analyze/:jobId",
  requireAuth,
  asyncHandler(async (req, res) => {
    const jobId = req.params.jobId;
    if (!jobId) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "A job id is required." } });
    }
    const job = await eligibilityQueue.getJob(jobId);
    // Ownership is checked against the job's own payload, not trusted from
    // the URL — a job id alone must never reveal another user's job status.
    if (!job || job.data.userId !== req.auth!.sub) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Job not found" } });
    }

    const state = await job.getState();
    if (state === "completed") {
      return res.json({ jobId: job.id, status: "completed", result: job.returnvalue as EligibilityJobResult });
    }
    if (state === "failed") {
      return res.json({ jobId: job.id, status: "failed" });
    }
    return res.json({ jobId: job.id, status: "processing" });
  })
);

eligibilityRouter.get(
  "/offences",
  requireAuth,
  asyncHandler(async (req, res) => {
    const offences = await prisma.offence.findMany({
      where: { userId: req.auth!.sub },
      select: {
        id: true,
        offenceDescriptionEnc: true,
        offenceDate: true,
        court: true,
        sentenceType: true,
        sentenceDetails: true,
        userConfirmed: true,
        extractionConfidence: true,
        assessments: {
          orderBy: { createdAt: "desc" },
          take: 1,
          select: { aiRecommendation: true, aiReasoning: true, finalDecision: true, decidedAt: true },
        },
      },
    });
    return res.json({
      offences: offences.map(({ offenceDescriptionEnc, assessments, ...rest }) => ({
        ...rest,
        offenceDescription: decryptField(offenceDescriptionEnc),
        latestAssessment: assessments[0] ?? null,
      })),
    });
  })
);

const createOffenceSchema = z.object({
  documentId: z.string().uuid(),
  offenceDescription: z.string().min(1).max(2000),
  offenceDate: z.string().datetime().nullable().optional(),
  court: z.string().max(200).nullable().optional(),
  sentenceType: z.enum(["fine", "imprisonment", "imprisonment_suspended", "caution", "other"]).nullable().optional(),
  sentenceDetails: z.string().max(2000).nullable().optional(),
});

/**
 * Manual-entry fallback for gate 1 (docs/05-ai-workflow.md): lets an
 * applicant add an offence by hand when AI extraction produced nothing
 * (scanned/image-only document, ANTHROPIC_API_KEY not configured, or a
 * failed extraction) rather than being stuck with an empty results page.
 * extractionConfidence is left null so the UI can distinguish manually
 * entered offences from AI-extracted ones; userConfirmed still starts
 * false so it goes through the same confirm-then-evaluate gate.
 */
eligibilityRouter.post(
  "/offences",
  requireAuth,
  asyncHandler(async (req, res) => {
    const parsed = createOffenceSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid offence." } });
    }

    const document = await prisma.document.findFirst({
      where: { id: parsed.data.documentId, userId: req.auth!.sub },
    });
    if (!document) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Document not found" } });
    }

    const { offenceDescription, offenceDate, court, sentenceType, sentenceDetails } = parsed.data;
    const created = await prisma.offence.create({
      data: {
        documentId: document.id,
        userId: req.auth!.sub,
        offenceDescriptionEnc: encryptField(offenceDescription),
        offenceDate: offenceDate ? new Date(offenceDate) : null,
        court: court ?? null,
        sentenceType: sentenceType ?? undefined,
        sentenceDetails: sentenceDetails ?? null,
        userConfirmed: false,
        extractionConfidence: null,
      },
    });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "offence.manual_create",
      targetType: "offence",
      targetId: created.id,
    });

    return res.status(201).json({ id: created.id });
  })
);

const patchOffenceSchema = z.object({
  offenceDescription: z.string().min(1).max(2000).optional(),
  offenceDate: z.string().datetime().nullable().optional(),
  court: z.string().max(200).nullable().optional(),
  sentenceType: z.enum(["fine", "imprisonment", "imprisonment_suspended", "caution", "other"]).nullable().optional(),
  sentenceDetails: z.string().max(2000).nullable().optional(),
  userConfirmed: z.boolean().optional(),
});

/**
 * Gate 1 of docs/05-ai-workflow.md: the user reviews/edits what Claude
 * extracted, then confirms it. Confirming (userConfirmed: true) is what
 * triggers the deterministic rules-engine evaluation + AI explanation for
 * this offence — nothing runs the rules engine before the user has had a
 * chance to correct an extraction error.
 */
eligibilityRouter.patch(
  "/offences/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const parsed = patchOffenceSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid offence update." } });
    }

    // Ownership-scoped, same pattern as every other per-user resource in
    // this codebase (documents, applications, timeline notes).
    const existing = await prisma.offence.findFirst({ where: { id: req.params.id, userId: req.auth!.sub } });
    if (!existing) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Offence not found" } });
    }

    const { offenceDescription, offenceDate, court, sentenceType, sentenceDetails, userConfirmed } = parsed.data;
    const updated = await prisma.offence.update({
      where: { id: existing.id },
      data: {
        ...(offenceDescription !== undefined && { offenceDescriptionEnc: encryptField(offenceDescription) }),
        ...(offenceDate !== undefined && { offenceDate: offenceDate ? new Date(offenceDate) : null }),
        ...(court !== undefined && { court }),
        ...(sentenceType !== undefined && { sentenceType }),
        ...(sentenceDetails !== undefined && { sentenceDetails }),
        ...(userConfirmed !== undefined && { userConfirmed }),
      },
    });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "offence.update",
      targetType: "offence",
      targetId: updated.id,
    });

    const justConfirmed = userConfirmed === true && !existing.userConfirmed;
    if (justConfirmed) {
      await runRulesEngineForOffence(updated.id, req);
    }

    return res.json({ id: updated.id, userConfirmed: updated.userConfirmed });
  })
);

/** Gate-1-triggered rules-engine + explanation pass for a single offence. */
async function runRulesEngineForOffence(offenceId: string, req: Request): Promise<void> {
  const offence = await prisma.offence.findUnique({ where: { id: offenceId } });
  if (!offence) return;

  const rulesVersion = await prisma.rulesVersion.findFirst({ orderBy: { effectiveFrom: "desc" } });
  if (!rulesVersion) {
    logger.error("No rules_versions row found — cannot evaluate eligibility. Seed one via a migration.");
    return;
  }

  const otherOffences = await prisma.offence.findMany({
    where: { userId: offence.userId, id: { not: offence.id } },
    select: { offenceDate: true },
  });

  const evaluation = evaluateOffence(
    {
      offenceDescription: decryptField(offence.offenceDescriptionEnc),
      offenceDate: offence.offenceDate,
      sentenceType: offence.sentenceType,
    },
    otherOffences,
    rulesVersion.ruleset as unknown as Ruleset
  );

  let aiReasoning: string;
  let aiConfidence: number;
  if (env.ANTHROPIC_API_KEY) {
    try {
      aiReasoning = await explainEligibilityVerdict({
        offence: {
          offenceDescription: decryptField(offence.offenceDescriptionEnc),
          offenceDate: offence.offenceDate?.toISOString() ?? null,
          court: offence.court,
          sentenceType: offence.sentenceType,
          sentenceDetails: offence.sentenceDetails,
          confidence: offence.extractionConfidence ?? 0,
        },
        verdict: evaluation.verdict,
        ruleReasonCodes: evaluation.reasonCodes,
      });
      aiConfidence = offence.extractionConfidence ?? 0.5;
    } catch (err) {
      logger.error({ err, offenceId }, "AI explanation failed; recording verdict without narrative explanation");
      aiReasoning = "An AI-generated explanation could not be produced. A reviewer will confirm this result directly.";
      aiConfidence = 0;
    }
  } else {
    aiReasoning =
      "AI-generated plain-language explanation is not yet configured for this deployment. A reviewer will confirm this result directly.";
    aiConfidence = 0;
  }

  await prisma.eligibilityAssessment.create({
    data: {
      offenceId: offence.id,
      rulesVersionId: rulesVersion.id,
      aiRecommendation: evaluation.verdict,
      aiReasoning,
      aiConfidence,
    },
  });

  await writeAuditLog({
    req,
    actorId: offence.userId,
    action: "eligibility_assessment.created",
    targetType: "offence",
    targetId: offence.id,
    after: { verdict: evaluation.verdict, reasonCodes: evaluation.reasonCodes },
  });
}
