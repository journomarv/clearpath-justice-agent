import { Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../utils/asyncHandler";
import { analyticsRateLimit } from "../middleware/security";
import { prisma } from "../utils/prisma";

export const analyticsRouter = Router();

// Fixed, allow-listed funnel steps — see MVP spec §8. Anything outside this
// enum is rejected rather than silently accepted, so this table can never
// become a dumping ground for arbitrary client-supplied event names.
const EVENT_TYPES = [
  "visitor",
  "assessment_started",
  "assessment_completed",
  "pathway_identified",
  "action_plan_generated",
  "case_created",
  "referral_clicked",
] as const;

// Meta is intentionally a tiny, allow-listed shape — never free text, so a
// caller cannot smuggle a name/ID/criminal-record fragment into it. Values
// are short enums/strings only, never anything resembling a document or
// personal identifier.
const metaSchema = z
  .object({
    outcome: z.enum(["pathway", "more_info", "not_met"]).optional(),
    referral: z.string().trim().max(60).optional(),
    source: z.string().trim().max(60).optional(),
  })
  .strict()
  .optional();

const eventSchema = z.object({
  event: z.enum(EVENT_TYPES),
  // Random client-generated id (crypto.randomUUID()), never a user id / email.
  anonId: z.string().uuid(),
  meta: metaSchema,
});

analyticsRouter.post(
  "/event",
  analyticsRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = eventSchema.safeParse(req.body);
    if (!parsed.success) {
      // Analytics must never break the page it's embedded on; still reject
      // malformed payloads, but with a plain 202 rather than surfacing detail.
      return res.status(202).json({ ok: true });
    }

    const { event, anonId, meta } = parsed.data;
    await prisma.analyticsEvent.create({ data: { event, anonId, meta: meta ?? undefined } });
    return res.status(202).json({ ok: true });
  })
);
