import { Router } from "express";
import { z } from "zod";
import { prisma } from "../utils/prisma";
import { asyncHandler } from "../utils/asyncHandler";
import { analyticsRateLimit } from "../middleware/security";

export const passportRouter = Router();

const idParamSchema = z.string().uuid();

/**
 * Public, unauthenticated by design — this is the whole point of a
 * Digital Justice Passport (MVP concept): a third party (e.g. an employer)
 * can verify that a justice process concluded WITHOUT ever seeing the
 * applicant's identity, offence, or case detail. Reuses the analytics
 * endpoint's rate limit shape since this is another public, no-auth-cost
 * endpoint that needs its own abuse budget.
 */
passportRouter.get(
  "/:id/verify",
  analyticsRateLimit,
  asyncHandler(async (req, res) => {
    const parsedId = idParamSchema.safeParse(req.params.id);
    if (!parsedId.success) {
      return res.status(404).json({ valid: false });
    }

    const passport = await prisma.passport.findUnique({
      where: { id: parsedId.data },
      select: { outcome: true, issuedAt: true, revokedAt: true },
    });
    if (!passport) {
      return res.status(404).json({ valid: false });
    }

    return res.json({
      valid: !passport.revokedAt,
      outcome: passport.outcome,
      issuedAt: passport.issuedAt,
      revoked: !!passport.revokedAt,
    });
  })
);
