import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { asyncHandler } from "../utils/asyncHandler";
import { sendContactSubmission } from "../services/email.service";
import { logger } from "../utils/logger";

export const contactRouter = Router();

// This is one of the few unauthenticated endpoints that causes an outbound
// side effect, which makes it the most attractive target on the API for spam
// relaying. The limit is deliberately much tighter than the general API one.
const contactRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: { code: "RATE_LIMITED", message: "Too many messages sent. Please try again later." },
  },
});

const contactSchema = z.object({
  name: z.string().trim().min(1).max(200),
  email: z.string().trim().email().max(320),
  message: z.string().trim().min(1).max(5000),
  // Honeypot: a field hidden from real users. Anything that fills it in is
  // almost certainly an automated form-filler. Accepted by the schema on
  // purpose so the request reaches the handler and can be silently dropped —
  // rejecting it here would tell the bot exactly which field gave it away.
  website: z.string().max(500).optional(),
});

contactRouter.post(
  "/",
  contactRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = contactSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: { code: "VALIDATION_ERROR", message: "Please provide a valid name, email address, and message." },
      });
    }

    const { name, email, message, website } = parsed.data;

    // Silently accept-and-drop bot submissions: returning success gives the
    // bot no signal to adapt to, while nothing is sent.
    if (website) {
      logger.warn("Contact submission rejected by honeypot");
      return res.status(202).json({ message: "Thanks — your message has been sent." });
    }

    try {
      await sendContactSubmission({
        name,
        email,
        message,
        submittedAt: new Date(),
        ip: req.ip,
      });
    } catch (err) {
      // Log the real cause server-side; tell the visitor something actionable
      // without exposing mail-infrastructure detail.
      logger.error({ err }, "Contact submission failed to send");
      return res.status(502).json({
        error: {
          code: "SEND_FAILED",
          message: "We couldn't send your message right now. Please try again shortly.",
        },
      });
    }

    return res.status(202).json({ message: "Thanks — your message has been sent." });
  })
);
