import { Router } from "express";
import { z } from "zod";
import { requireAuth, requireRole } from "../middleware/auth";
import { prisma } from "../utils/prisma";
import { writeAuditLog } from "../middleware/auditLog";
import { asyncHandler } from "../utils/asyncHandler";
import { decryptField } from "../utils/encryption";

export const adminRouter = Router();

// Every route below is gated server-side by role — see
// docs/08-security-architecture.md §2 and docs/07-admin-workflow.md.
adminRouter.use(requireAuth, requireRole("reviewer", "admin", "super_admin"));

const MAX_PAGE_SIZE = 100;

adminRouter.get(
  "/cases",
  asyncHandler(async (req, res) => {
    // Caller-supplied paging is clamped; an unbounded `take` would let one
    // request pull the entire case table.
    const requested = Number.parseInt(String(req.query.limit ?? "50"), 10);
    const take = Number.isFinite(requested) ? Math.min(Math.max(requested, 1), MAX_PAGE_SIZE) : 50;

    const cases = await prisma.application.findMany({
      orderBy: { createdAt: "desc" },
      take,
      select: { id: true, status: true, assignedReviewerId: true, createdAt: true, userId: true },
    });
    return res.json({ cases });
  })
);

adminRouter.get(
  "/cases/:id",
  asyncHandler(async (req, res) => {
    const application = await prisma.application.findUnique({ where: { id: req.params.id } });
    if (!application) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Case not found" } });
    }

    // Reviewers reading a case file is itself a sensitive event on a platform
    // holding criminal records, so it is recorded, not just the writes.
    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "case.view",
      targetType: "application",
      targetId: application.id,
    });

    return res.json(application);
  })
);

/**
 * Lets the admin/reviewer UI discover which offence ids exist for this
 * case's applicant, and their latest assessment — POST /cases/:id/decision
 * below requires an offenceId, and without this there was no way for a
 * reviewer to find one short of reading the database directly.
 */
adminRouter.get(
  "/cases/:id/offences",
  asyncHandler(async (req, res) => {
    const application = await prisma.application.findUnique({ where: { id: req.params.id } });
    if (!application) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Case not found" } });
    }

    const offences = await prisma.offence.findMany({
      where: { userId: application.userId },
      include: { assessments: { orderBy: { createdAt: "desc" }, take: 1 } },
    });

    return res.json({
      offences: offences.map((o) => ({
        id: o.id,
        offenceDescription: decryptField(o.offenceDescriptionEnc),
        offenceDate: o.offenceDate,
        sentenceType: o.sentenceType,
        userConfirmed: o.userConfirmed,
        latestAssessment: o.assessments[0]
          ? {
              id: o.assessments[0].id,
              aiRecommendation: o.assessments[0].aiRecommendation,
              aiReasoning: o.assessments[0].aiReasoning,
              finalDecision: o.assessments[0].finalDecision,
              decidedAt: o.assessments[0].decidedAt,
            }
          : null,
      })),
    });
  })
);

const decisionSchema = z.object({
  offenceId: z.string().uuid(),
  decision: z.enum(["eligible", "not_eligible", "uncertain"]),
  overrideReason: z.string().min(1).max(2000).optional(),
});

adminRouter.post(
  "/cases/:id/decision",
  asyncHandler(async (req, res) => {
    const parsed = decisionSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "offenceId and a valid decision are required" } });
    }
    const { offenceId, decision, overrideReason } = parsed.data;

    const application = await prisma.application.findUnique({
      where: { id: req.params.id },
      select: { id: true, userId: true },
    });
    if (!application) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Case not found" } });
    }

    // The offence must actually belong to the case named in the URL.
    // Previously `:id` was accepted and then never used, so a decision could
    // be recorded against any offence in the system while the audit trail
    // claimed it happened on this case — corrupting exactly the record that
    // is supposed to prove who decided what.
    const offence = await prisma.offence.findFirst({
      where: { id: offenceId, userId: application.userId },
      select: { id: true },
    });
    if (!offence) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Offence not found on this case" } });
    }

    const assessment = await prisma.eligibilityAssessment.findFirst({
      where: { offenceId: offence.id },
      orderBy: { createdAt: "desc" },
    });
    if (!assessment) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "No assessment found for offence" } });
    }
    if (assessment.decidedAt) {
      return res.status(409).json({
        error: { code: "ALREADY_DECIDED", message: "This assessment has already been decided." },
      });
    }

    const isOverride = decision !== assessment.aiRecommendation;
    if (isOverride && !overrideReason) {
      return res.status(400).json({
        error: { code: "REASON_REQUIRED", message: "An override reason is required when disagreeing with the AI recommendation" },
      });
    }

    const updated = await prisma.eligibilityAssessment.update({
      where: { id: assessment.id },
      data: {
        reviewerId: req.auth!.sub,
        finalDecision: decision,
        overrideReason: isOverride ? overrideReason : null,
        decidedAt: new Date(),
      },
    });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: isOverride ? "assessment.override" : "assessment.confirm",
      targetType: "eligibility_assessment",
      targetId: assessment.id,
      before: { aiRecommendation: assessment.aiRecommendation },
      after: { applicationId: application.id, finalDecision: decision, overrideReason: overrideReason ?? null },
    });

    return res.json(updated);
  })
);

const statusSchema = z.object({
  status: z.enum(["submitted", "under_review", "waiting_for_information", "approved", "rejected"]),
});

adminRouter.patch(
  "/cases/:id/status",
  asyncHandler(async (req, res) => {
    const parsed = statusSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid status" } });
    }
    const { status } = parsed.data;

    // Existence is checked before the update. Calling update() on a missing
    // id raises Prisma P2025, which used to escape as an unhandled rejection
    // and take the process down.
    const before = await prisma.application.findUnique({ where: { id: req.params.id } });
    if (!before) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Case not found" } });
    }

    const updated = await prisma.application.update({
      where: { id: before.id },
      data: { status },
    });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "application.status_change",
      targetType: "application",
      targetId: before.id,
      before: { status: before.status },
      after: { status },
    });

    return res.json(updated);
  })
);

// Admin-only aggregate dashboard (MVP spec §9). Pulls counts only — never a
// row of individual user/case data — from the privacy-conscious analytics
// table plus existing case/application tables.
adminRouter.get(
  "/analytics/summary",
  requireRole("admin", "super_admin"),
  asyncHandler(async (_req, res) => {
    const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    const [funnelRows, casesByStage, assessmentOutcomes, totalCases, totalAssessments] = await Promise.all([
      prisma.analyticsEvent.groupBy({
        by: ["event"],
        where: { createdAt: { gte: since } },
        _count: { _all: true },
      }),
      prisma.application.groupBy({ by: ["status"], _count: { _all: true } }),
      prisma.eligibilityAssessment.groupBy({ by: ["aiRecommendation"], _count: { _all: true } }),
      prisma.application.count(),
      prisma.eligibilityAssessment.count(),
    ]);

    const funnel: Record<string, number> = {};
    for (const row of funnelRows) funnel[row.event] = row._count._all;

    return res.json({
      windowDays: 30,
      funnel,
      casesByStage: casesByStage.map((r) => ({ status: r.status, count: r._count._all })),
      assessmentOutcomes: assessmentOutcomes.map((r) => ({ outcome: r.aiRecommendation, count: r._count._all })),
      totalCases,
      totalAssessments,
    });
  })
);

// Super-admin-only: raw audit log access. Reading the audit log is itself
// audited — otherwise the one record that shows who looked at what has a
// blind spot exactly where it matters most.
adminRouter.get(
  "/audit-logs",
  requireRole("super_admin"),
  asyncHandler(async (req, res) => {
    const requested = Number.parseInt(String(req.query.limit ?? "100"), 10);
    const take = Number.isFinite(requested) ? Math.min(Math.max(requested, 1), MAX_PAGE_SIZE) : 100;

    const logs = await prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "audit_log.read",
      targetType: "audit_log",
    });

    return res.json({ logs });
  })
);
