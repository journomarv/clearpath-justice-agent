import { Router } from "express";
import { z } from "zod";
import { requireAuth } from "../middleware/auth";
import { prisma } from "../utils/prisma";
import { writeAuditLog } from "../middleware/auditLog";
import { asyncHandler } from "../utils/asyncHandler";

export const applicationsRouter = Router();

const verifySchema = z
  .object({
    referenceNumber: z.string().trim().min(1).max(100).nullable().optional(),
    submittedAt: z.string().datetime().nullable().optional(),
    outcome: z.enum(["granted", "refused", "withdrawn"]).nullable().optional(),
    outcomeDate: z.string().datetime().nullable().optional(),
  })
  .strict();

const noteSchema = z.object({
  body: z.string().trim().min(1).max(2000),
});

applicationsRouter.post(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    const application = await prisma.application.create({
      data: { userId: req.auth!.sub, status: "submitted" },
    });
    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "application.create",
      targetType: "application",
      targetId: application.id,
    });
    return res.status(201).json({ id: application.id, status: application.status });
  })
);

applicationsRouter.get(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    const applications = await prisma.application.findMany({
      where: { userId: req.auth!.sub },
      orderBy: { createdAt: "desc" },
    });
    return res.json({ applications });
  })
);

applicationsRouter.get(
  "/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const application = await prisma.application.findFirst({
      where: { id: req.params.id, userId: req.auth!.sub },
    });
    if (!application) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Application not found" } });
    }
    return res.json(application);
  })
);

applicationsRouter.get(
  "/:id/timeline",
  requireAuth,
  asyncHandler(async (req, res) => {
    // Ownership is enforced here, not just on the parent record. This query
    // previously filtered only on applicationId, so any logged-in user could
    // read the reviewer notes on ANY case just by supplying its id — an IDOR
    // exposing another person's expungement case commentary. The notes are
    // reached *through* an ownership-checked application for that reason.
    const application = await prisma.application.findFirst({
      where: { id: req.params.id, userId: req.auth!.sub },
      select: { id: true },
    });
    if (!application) {
      // Deliberately identical to the "no such application" case so this
      // can't be used to probe which case ids exist.
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Application not found" } });
    }

    const notes = await prisma.applicationNote.findMany({
      where: { applicationId: application.id, visibility: "user_visible" },
      orderBy: { createdAt: "asc" },
      select: { id: true, body: true, createdAt: true },
    });
    return res.json({ notes });
  })
);

// VERIFY (MVP spec §5): the applicant records what actually happened after
// submission — a reference number, when it was submitted, the final
// outcome, and its date. This is self-reported by the user, distinct from
// `status` (ClearPath's own case-management stage) and from reviewer notes.
applicationsRouter.patch(
  "/:id/verify",
  requireAuth,
  asyncHandler(async (req, res) => {
    const parsed = verifySchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid request." } });
    }

    const application = await prisma.application.findFirst({
      where: { id: req.params.id, userId: req.auth!.sub },
      select: { id: true },
    });
    if (!application) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Application not found" } });
    }

    const { referenceNumber, submittedAt, outcome, outcomeDate } = parsed.data;
    const updated = await prisma.application.update({
      where: { id: application.id },
      data: {
        ...(referenceNumber !== undefined ? { referenceNumber } : {}),
        ...(submittedAt !== undefined ? { submittedAt: submittedAt ? new Date(submittedAt) : null } : {}),
        ...(outcome !== undefined ? { outcome } : {}),
        ...(outcomeDate !== undefined ? { outcomeDate: outcomeDate ? new Date(outcomeDate) : null } : {}),
      },
    });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "application.verify_update",
      targetType: "application",
      targetId: application.id,
      after: parsed.data,
    });

    return res.json(updated);
  })
);

// Lets the applicant record their own correspondence (e.g. "called SAPS CRC,
// told to wait 6 weeks") on the timeline alongside reviewer notes. Always
// user_visible since the author IS the user — there is nothing to hide from
// themselves.
applicationsRouter.post(
  "/:id/notes",
  requireAuth,
  asyncHandler(async (req, res) => {
    const parsed = noteSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid request." } });
    }

    const application = await prisma.application.findFirst({
      where: { id: req.params.id, userId: req.auth!.sub },
      select: { id: true },
    });
    if (!application) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Application not found" } });
    }

    const note = await prisma.applicationNote.create({
      data: {
        applicationId: application.id,
        authorId: req.auth!.sub,
        visibility: "user_visible",
        body: parsed.data.body,
      },
    });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "application.note_create",
      targetType: "application_note",
      targetId: note.id,
    });

    return res.status(201).json({ id: note.id, body: note.body, createdAt: note.createdAt });
  })
);

// Digital Justice Passport: issued only once an outcome has been recorded
// (VERIFY), and only ever exposes {outcome, issuedAt} publicly — see
// passport.routes.ts for the public verification endpoint. Re-issuing an
// already-issued passport returns the existing one rather than creating a
// second credential for the same case.
applicationsRouter.post(
  "/:id/passport",
  requireAuth,
  asyncHandler(async (req, res) => {
    const application = await prisma.application.findFirst({
      where: { id: req.params.id, userId: req.auth!.sub },
    });
    if (!application) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Application not found" } });
    }
    if (!application.outcome) {
      return res.status(400).json({
        error: { code: "NO_OUTCOME", message: "Record an outcome under VERIFY before issuing a passport." },
      });
    }

    const existing = await prisma.passport.findFirst({ where: { applicationId: application.id, revokedAt: null } });
    if (existing) {
      return res.json(existing);
    }

    const passport = await prisma.passport.create({
      data: { applicationId: application.id, userId: req.auth!.sub, outcome: application.outcome },
    });

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "passport.issue",
      targetType: "passport",
      targetId: passport.id,
    });

    return res.status(201).json(passport);
  })
);

// NOTE: POST /:id/generate-documents (template fill for the DOJ&CD
// application + affidavit) requires a legally-reviewed template and is
// intentionally left as a documented contract only — see
// docs/05-ai-workflow.md step 9 and docs/13-risks-mitigations.md.
