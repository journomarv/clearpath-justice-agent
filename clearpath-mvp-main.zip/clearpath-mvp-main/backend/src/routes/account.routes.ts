import { Router } from "express";
import crypto from "crypto";
import { z } from "zod";
import { requireAuth } from "../middleware/auth";
import { prisma } from "../utils/prisma";
import { decryptField, encryptField } from "../utils/encryption";
import { verifyPassword } from "../utils/password";
import { writeAuditLog } from "../middleware/auditLog";
import { asyncHandler } from "../utils/asyncHandler";
import { authRateLimit } from "../middleware/security";
import { deleteUserDocuments } from "../utils/objectStorage";

export const accountRouter = Router();

/**
 * Self-service POPIA data-access request (Privacy Policy §7/§10 previously
 * said "request manually via Contact" — this is the endpoint that replaces
 * that). Returns everything the platform holds about the caller, decrypted,
 * as one JSON bundle. Document bytes are not included here — file content is
 * fetched separately via GET /documents/:id/download so this export stays a
 * bounded, fast response even for an account with many uploads.
 */
accountRouter.get(
  "/export",
  requireAuth,
  asyncHandler(async (req, res) => {
    const userId = req.auth!.sub;

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Account not found" } });
    }

    const [documents, offences, applications, notifications] = await Promise.all([
      prisma.document.findMany({ where: { userId } }),
      prisma.offence.findMany({ where: { userId } }),
      prisma.application.findMany({ where: { userId } }),
      prisma.notification.findMany({ where: { userId } }),
    ]);

    const bundle = {
      exportedAt: new Date().toISOString(),
      account: {
        id: user.id,
        email: user.email,
        fullName: decryptField(user.fullNameEnc),
        idNumber: user.idNumberEnc ? decryptField(user.idNumberEnc) : null,
        phone: user.phoneEnc ? decryptField(user.phoneEnc) : null,
        role: user.role,
        consentVersion: user.consentVersion,
        consentAt: user.consentAt,
        createdAt: user.createdAt,
      },
      documents: documents.map((d) => ({
        id: d.id,
        type: d.type,
        mimeType: d.mimeType,
        virusScanStatus: d.virusScanStatus,
        uploadedAt: d.uploadedAt,
      })),
      offences: offences.map((o) => ({
        id: o.id,
        offenceDescription: decryptField(o.offenceDescriptionEnc),
        offenceDate: o.offenceDate,
        court: o.court,
        sentenceType: o.sentenceType,
        sentenceDetails: o.sentenceDetails,
        userConfirmed: o.userConfirmed,
      })),
      applications,
      notifications,
    };

    await writeAuditLog({ req, actorId: userId, action: "account.export", targetType: "user", targetId: userId });

    res.setHeader("Content-Disposition", `attachment; filename="clearpath-data-export.json"`);
    return res.json(bundle);
  })
);

const deleteSchema = z.object({ password: z.string().min(1).max(200) });

// A fixed placeholder, re-encrypted fresh each call so ciphertexts for
// deleted accounts don't share a static value — matches the intent of
// encryptField's random IV per call, just made explicit here.
const REDACTED = "[deleted]";

/**
 * Self-service POPIA erasure request. Requires the current password so a
 * hijacked but not-yet-expired browser tab can't be used to nuke an account
 * the attacker doesn't actually control the credentials for. Never a hard
 * delete — Session/AuditLog/etc. hold foreign keys to User, and the audit
 * trail must stay append-only — so this follows the same soft-delete
 * convention already used for test-account cleanup in earlier sessions.
 */
accountRouter.post(
  "/delete",
  requireAuth,
  authRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = deleteSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Password is required." } });
    }

    const userId = req.auth!.sub;
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || user.status !== "active") {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Account not found" } });
    }

    const valid = await verifyPassword(user.passwordHash, parsed.data.password);
    if (!valid) {
      return res.status(401).json({ error: { code: "INVALID_CREDENTIALS", message: "Incorrect password." } });
    }

    const redactedEmail = `deleted-${crypto.randomUUID()}@deleted.clearpath-mvp.invalid`;

    await prisma.$transaction([
      prisma.user.update({
        where: { id: userId },
        data: {
          status: "deleted",
          email: redactedEmail,
          fullNameEnc: encryptField(REDACTED),
          idNumberEnc: user.idNumberEnc ? encryptField(REDACTED) : null,
          phoneEnc: user.phoneEnc ? encryptField(REDACTED) : null,
          mfaSecretEnc: null,
          mfaEnabled: false,
        },
      }),
      prisma.session.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } }),
      prisma.passwordResetToken.updateMany({ where: { userId, usedAt: null }, data: { usedAt: new Date() } }),
    ]);

    // Best-effort: remove stored file bytes now rather than waiting for the
    // retention job. Safe no-op until Phase 3 (object storage) ships.
    await deleteUserDocuments(userId).catch(() => undefined);

    res.clearCookie("refresh_token", { path: "/api/v1/auth" });

    await writeAuditLog({ req, actorId: userId, action: "account.delete", targetType: "user", targetId: userId });

    return res.status(200).json({ message: "Your account has been deleted." });
  })
);
