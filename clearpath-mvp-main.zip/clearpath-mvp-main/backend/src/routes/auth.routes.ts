import { Router, type Request } from "express";
import { z } from "zod";
import crypto from "crypto";
import { authenticator } from "otplib";
import QRCode from "qrcode";
import { Prisma, type User } from "@prisma/client";
import { prisma } from "../utils/prisma";
import { hashPassword, verifyPassword, isPasswordStrongEnough, burnPasswordVerifyTime } from "../utils/password";
import { encryptField, decryptField } from "../utils/encryption";
import { env } from "../config/env";
import { authRateLimit } from "../middleware/security";
import { requireAuth } from "../middleware/auth";
import { writeAuditLog } from "../middleware/auditLog";
import { asyncHandler } from "../utils/asyncHandler";
import { signAccessToken, signMfaChallengeToken, verifyMfaChallengeToken } from "../utils/tokens";
import { sendAfterMinimumDuration, LOGIN_MIN_RESPONSE_MS, type DeferredResponse } from "../utils/constantTime";
import { sendPasswordResetEmail } from "../services/email.service";

export const authRouter = Router();

const PRIVACY_POLICY_VERSION = "2026-08-03-3";
const LOCKOUT_THRESHOLD = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000;
const REFRESH_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const ACCESS_TTL_MS = 15 * 60 * 1000;

// Identical response whether or not the address is already registered —
// the caller must not be able to tell an existing account from a new one.
const REGISTER_RESPONSE = { message: "If that email is available, your account is ready — you can log in now." };

const registerSchema = z.object({
  email: z.string().email().max(320),
  password: z.string().min(1).max(200),
  fullName: z.string().min(1).max(200),
  acceptedPrivacyPolicy: z.literal(true),
});

authRouter.post(
  "/register",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      // Don't echo Zod's full issue list back — it describes internal shape.
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid registration details." } });
    }
    const { email, password, fullName } = parsed.data;

    if (!isPasswordStrongEnough(password)) {
      return res.status(400).json({
        error: { code: "WEAK_PASSWORD", message: "Password must be 12-128 characters." },
      });
    }

    const normalisedEmail = email.trim().toLowerCase();

    try {
      const user = await prisma.user.create({
        data: {
          email: normalisedEmail,
          passwordHash: await hashPassword(password),
          fullNameEnc: encryptField(fullName),
          consentVersion: PRIVACY_POLICY_VERSION,
          consentAt: new Date(),
        },
      });

      await writeAuditLog({ req, actorId: user.id, action: "user.register", targetType: "user", targetId: user.id });
    } catch (err) {
      // P2002 = unique constraint violation on email. Previously this code
      // did findUnique-then-create, which is a TOCTOU race: two concurrent
      // registrations for the same address both passed the check, the second
      // create threw, and the unhandled rejection CRASHED THE PROCESS
      // (verified). Rely on the database's unique constraint instead of a
      // read-then-write check, and swallow the collision into the same
      // generic response so it also stays non-enumerable.
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
        return res.status(201).json(REGISTER_RESPONSE);
      }
      throw err;
    }

    return res.status(201).json(REGISTER_RESPONSE);
  })
);

const loginSchema = z.object({
  email: z.string().email().max(320),
  password: z.string().min(1).max(200),
});

function refreshCookieOptions() {
  return {
    httpOnly: true,
    secure: env.NODE_ENV === "production",
    sameSite: "strict" as const,
    maxAge: REFRESH_TTL_MS,
    path: "/api/v1/auth",
  };
}

// A real, server-verifiable session signal for the Next.js frontend's own
// middleware (see frontend/middleware.ts) — that middleware previously only
// checked for a non-httpOnly `cp_session` cookie the CLIENT set itself,
// which proved nothing and was trivially forgeable. This cookie carries the
// actual signed access token so the frontend server can verify its
// signature, issuer, audience, and expiry before ever rendering a
// /dashboard or /admin page — the same checks the backend already applies
// in middleware/auth.ts. Path "/" (not scoped to /api/v1/auth like the
// refresh cookie) because the frontend server, not just the API, must read it.
function accessCookieOptions() {
  return {
    httpOnly: true,
    secure: env.NODE_ENV === "production",
    sameSite: "strict" as const,
    maxAge: ACCESS_TTL_MS,
    path: "/",
  };
}

authRouter.post(
  "/login",
  authRateLimit,
  asyncHandler(async (req, res) =>
    // Every outcome — bad input, unknown address, wrong password, locked, or
    // success — is held to the same floor before any bytes are written, so
    // response latency reveals nothing about whether the address has an
    // account. The handler therefore *describes* its response rather than
    // sending it; see constantTime.ts.
    sendAfterMinimumDuration(res, LOGIN_MIN_RESPONSE_MS, async (): Promise<DeferredResponse> => {
      const parsed = loginSchema.safeParse(req.body);
      if (!parsed.success) {
        return { status: 400, body: { error: { code: "VALIDATION_ERROR", message: "Invalid credentials." } } };
      }
      const { email, password } = parsed.data;

      const user = await prisma.user.findUnique({ where: { email: email.trim().toLowerCase() } });
      const genericFailure: DeferredResponse = {
        status: 401,
        body: { error: { code: "INVALID_CREDENTIALS", message: "Invalid email or password" } },
      };

      // Still burn comparable hashing time on the unknown-address branch.
      // The floor above is the real guarantee, but keeping the underlying
      // work similar means the floor isn't the only thing standing between
      // an observer and the answer.
      if (!user || user.status !== "active") {
        await burnPasswordVerifyTime(password);
        return genericFailure;
      }

      if (user.lockedUntil && user.lockedUntil > new Date()) {
        return { status: 423, body: { error: { code: "ACCOUNT_LOCKED", message: "Account temporarily locked" } } };
      }

      const valid = await verifyPassword(user.passwordHash, password);
      if (!valid) {
        // If a previous lockout has expired, start counting again from zero
        // rather than carrying the old total forward — otherwise every later
        // failure instantly re-locks the account, letting anyone who knows the
        // address keep its owner locked out indefinitely.
        const lockoutExpired = user.lockedUntil !== null && user.lockedUntil <= new Date();
        const failedLoginCount = (lockoutExpired ? 0 : user.failedLoginCount) + 1;
        const lockedUntil =
          failedLoginCount >= LOCKOUT_THRESHOLD ? new Date(Date.now() + LOCKOUT_DURATION_MS) : null;
        await prisma.user.update({ where: { id: user.id }, data: { failedLoginCount, lockedUntil } });
        await writeAuditLog({ req, actorId: user.id, action: "user.login_failed", targetType: "user", targetId: user.id });
        return genericFailure;
      }

      await prisma.user.update({ where: { id: user.id }, data: { failedLoginCount: 0, lockedUntil: null } });

      // MFA accounts don't get a session yet — only a short-lived challenge
      // token proving the password check passed. The real session is issued
      // by POST /auth/mfa/challenge once the TOTP code also checks out.
      if (user.mfaEnabled) {
        return { status: 200, body: { mfaRequired: true, challengeToken: signMfaChallengeToken(user.id) } };
      }

      return establishSession(req, user);
    })
  )
);

/**
 * Shared by the non-MFA branch of /login and by /mfa/challenge once a code
 * is verified — both end the same way: a new rotating-refresh session and a
 * login audit entry.
 */
async function establishSession(req: Request, user: User): Promise<DeferredResponse> {
  const refreshToken = crypto.randomBytes(48).toString("hex");
  const refreshTokenHash = crypto.createHash("sha256").update(refreshToken).digest("hex");
  await prisma.session.create({
    data: {
      userId: user.id,
      refreshTokenHash,
      userAgent: req.headers["user-agent"]?.slice(0, 500) ?? null,
      ip: req.ip,
      expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
    },
  });

  await writeAuditLog({ req, actorId: user.id, action: "user.login", targetType: "user", targetId: user.id });

  const accessToken = signAccessToken(user.id, user.role);

  return {
    status: 200,
    body: { accessToken, role: user.role },
    cookies: [
      { name: "refresh_token", value: refreshToken, options: refreshCookieOptions() },
      { name: "cp_access", value: accessToken, options: accessCookieOptions() },
    ],
  };
}

const mfaChallengeSchema = z.object({
  challengeToken: z.string().min(1),
  code: z.string().min(6).max(10),
});

/**
 * Second step of login for accounts with MFA enabled. Rate-limited like
 * every other auth endpoint — a 6-digit TOTP code has limited entropy per
 * attempt, so brute-forcing must be blunted the same way password guessing is.
 */
authRouter.post(
  "/mfa/challenge",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = mfaChallengeSchema.safeParse(req.body);
    const invalid = () =>
      res.status(401).json({ error: { code: "INVALID_CHALLENGE", message: "Invalid or expired code. Please log in again." } });
    if (!parsed.success) return invalid();

    const userId = verifyMfaChallengeToken(parsed.data.challengeToken);
    if (!userId) return invalid();

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || user.status !== "active" || !user.mfaEnabled || !user.mfaSecretEnc) return invalid();

    const secret = decryptField(user.mfaSecretEnc);
    if (!safeTotpCheck(parsed.data.code, secret)) return invalid();

    const session = await establishSession(req, user);
    for (const cookie of session.cookies ?? []) res.cookie(cookie.name, cookie.value, cookie.options);
    return res.status(session.status).json(session.body);
  })
);

/**
 * Exchanges a valid, unrevoked, unexpired refresh cookie for a new access
 * token, rotating the refresh token in the process. Rotation means a stolen
 * refresh token is single-use: the legitimate client's next refresh fails
 * and the theft surfaces instead of granting silent long-term access.
 */
authRouter.post(
  "/refresh",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const presented = req.cookies?.refresh_token;
    const invalid = () =>
      res.status(401).json({ error: { code: "INVALID_REFRESH", message: "Please log in again." } });

    if (typeof presented !== "string" || presented.length === 0) return invalid();

    const refreshTokenHash = crypto.createHash("sha256").update(presented).digest("hex");
    const session = await prisma.session.findFirst({
      where: { refreshTokenHash, revokedAt: null, expiresAt: { gt: new Date() } },
      include: { user: true },
    });
    if (!session || session.user.status !== "active") return invalid();

    const nextToken = crypto.randomBytes(48).toString("hex");
    const nextHash = crypto.createHash("sha256").update(nextToken).digest("hex");

    await prisma.$transaction([
      prisma.session.update({ where: { id: session.id }, data: { revokedAt: new Date() } }),
      prisma.session.create({
        data: {
          userId: session.userId,
          refreshTokenHash: nextHash,
          userAgent: req.headers["user-agent"]?.slice(0, 500) ?? null,
          ip: req.ip,
          expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
        },
      }),
    ]);

    res.cookie("refresh_token", nextToken, refreshCookieOptions());

    const accessToken = signAccessToken(session.userId, session.user.role);
    res.cookie("cp_access", accessToken, accessCookieOptions());

    return res.json({ accessToken, role: session.user.role });
  })
);

authRouter.post(
  "/logout",
  asyncHandler(async (req, res) => {
    const refreshToken = req.cookies?.refresh_token;
    if (typeof refreshToken === "string" && refreshToken.length > 0) {
      const refreshTokenHash = crypto.createHash("sha256").update(refreshToken).digest("hex");
      await prisma.session.updateMany({
        where: { refreshTokenHash, revokedAt: null },
        data: { revokedAt: new Date() },
      });
    }
    res.clearCookie("refresh_token", { path: "/api/v1/auth" });
    res.clearCookie("cp_access", { path: "/" });
    return res.status(204).send();
  })
);

const PASSWORD_RESET_TTL_MS = 60 * 60 * 1000; // 1 hour

// Identical response whether or not the address has an account — same
// anti-enumeration reasoning as REGISTER_RESPONSE above.
const FORGOT_PASSWORD_RESPONSE = { message: "If an account exists for that email, a reset link is on its way." };

const forgotPasswordSchema = z.object({ email: z.string().email().max(320) });

authRouter.post(
  "/password/forgot",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = forgotPasswordSchema.safeParse(req.body);
    if (!parsed.success) {
      // Even validation failure gets the generic response — a 400 here would
      // itself distinguish "malformed" from "well-formed but unknown".
      return res.status(202).json(FORGOT_PASSWORD_RESPONSE);
    }

    const user = await prisma.user.findUnique({ where: { email: parsed.data.email.trim().toLowerCase() } });

    // Real work only happens if the account exists and is active. Nothing
    // about the response depends on it, so this branch cannot be timed —
    // unlike login, there is no wrong-password path to compare against.
    if (user && user.status === "active") {
      const token = crypto.randomBytes(32).toString("hex");
      const tokenHash = crypto.createHash("sha256").update(token).digest("hex");

      await prisma.passwordResetToken.create({
        data: {
          userId: user.id,
          tokenHash,
          expiresAt: new Date(Date.now() + PASSWORD_RESET_TTL_MS),
          requestIp: req.ip,
        },
      });

      const resetUrl = `${env.FRONTEND_ORIGIN}/reset-password/confirm?token=${token}`;
      await sendPasswordResetEmail(user.email, resetUrl);

      await writeAuditLog({
        req,
        actorId: user.id,
        action: "user.password_reset_requested",
        targetType: "user",
        targetId: user.id,
      });
    }

    return res.status(202).json(FORGOT_PASSWORD_RESPONSE);
  })
);

const resetPasswordSchema = z.object({
  token: z.string().min(1),
  newPassword: z.string().min(1).max(200),
});

authRouter.post(
  "/password/reset",
  authRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = resetPasswordSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid request." } });
    }
    const { token, newPassword } = parsed.data;

    const invalidToken = () =>
      res.status(400).json({
        error: { code: "INVALID_TOKEN", message: "This reset link is invalid or has expired. Please request a new one." },
      });

    if (!isPasswordStrongEnough(newPassword)) {
      return res.status(400).json({ error: { code: "WEAK_PASSWORD", message: "Password must be 12-128 characters." } });
    }

    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
    const resetToken = await prisma.passwordResetToken.findUnique({
      where: { tokenHash },
      include: { user: true },
    });

    if (!resetToken || resetToken.usedAt || resetToken.expiresAt <= new Date() || resetToken.user.status !== "active") {
      return invalidToken();
    }

    const newPasswordHash = await hashPassword(newPassword);

    // All of this happens together: consuming the token, changing the
    // password, and revoking every existing session. That last part matters
    // — if an attacker's session were already active on the account, a
    // password reset by the real owner must not leave it valid.
    await prisma.$transaction([
      prisma.passwordResetToken.update({ where: { id: resetToken.id }, data: { usedAt: new Date() } }),
      // Any other outstanding reset tokens for this user are invalidated too,
      // so an older, still-unexpired link can't be replayed after this one
      // is used.
      prisma.passwordResetToken.updateMany({
        where: { userId: resetToken.userId, usedAt: null, id: { not: resetToken.id } },
        data: { usedAt: new Date() },
      }),
      prisma.user.update({
        where: { id: resetToken.userId },
        data: { passwordHash: newPasswordHash, failedLoginCount: 0, lockedUntil: null },
      }),
      prisma.session.updateMany({
        where: { userId: resetToken.userId, revokedAt: null },
        data: { revokedAt: new Date() },
      }),
    ]);

    res.clearCookie("refresh_token", { path: "/api/v1/auth" });

    await writeAuditLog({
      req,
      actorId: resetToken.userId,
      action: "user.password_reset_completed",
      targetType: "user",
      targetId: resetToken.userId,
    });

    return res.status(200).json({ message: "Your password has been reset. Please log in." });
  })
);

/** otplib throws on a malformed secret/token rather than returning false. */
function safeTotpCheck(code: string, secret: string): boolean {
  try {
    return authenticator.check(code, secret);
  } catch {
    return false;
  }
}

/**
 * Begins TOTP enrollment: generates a secret, stores it encrypted, but does
 * NOT enable MFA yet — that only happens once /mfa/verify confirms the user
 * actually has it working in an authenticator app. Calling this again before
 * verifying simply overwrites the pending secret (safe: nothing depends on
 * the old one until it's confirmed).
 */
authRouter.post(
  "/mfa/setup",
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: req.auth!.sub } });
    if (!user) return res.status(404).json({ error: { code: "NOT_FOUND", message: "Account not found" } });
    if (user.mfaEnabled) {
      return res.status(409).json({ error: { code: "MFA_ALREADY_ENABLED", message: "MFA is already enabled." } });
    }

    const secret = authenticator.generateSecret();
    await prisma.user.update({ where: { id: user.id }, data: { mfaSecretEnc: encryptField(secret) } });

    const otpauthUrl = authenticator.keyuri(user.email, "ClearPath Justice", secret);
    const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl);

    await writeAuditLog({ req, actorId: user.id, action: "user.mfa_setup_started", targetType: "user", targetId: user.id });

    return res.json({ otpauthUrl, qrCodeDataUrl });
  })
);

const mfaVerifySchema = z.object({ code: z.string().min(6).max(10) });

authRouter.post(
  "/mfa/verify",
  requireAuth,
  asyncHandler(async (req, res) => {
    const parsed = mfaVerifySchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "A 6-digit code is required." } });
    }

    const user = await prisma.user.findUnique({ where: { id: req.auth!.sub } });
    if (!user || !user.mfaSecretEnc) {
      return res.status(400).json({ error: { code: "MFA_NOT_SETUP", message: "Start MFA setup first." } });
    }

    const secret = decryptField(user.mfaSecretEnc);
    if (!safeTotpCheck(parsed.data.code, secret)) {
      return res.status(400).json({ error: { code: "INVALID_CODE", message: "Incorrect code." } });
    }

    await prisma.user.update({ where: { id: user.id }, data: { mfaEnabled: true } });
    await writeAuditLog({ req, actorId: user.id, action: "user.mfa_enabled", targetType: "user", targetId: user.id });

    return res.json({ message: "MFA enabled." });
  })
);

const mfaDisableSchema = z.object({ password: z.string().min(1).max(200), code: z.string().min(6).max(10) });

authRouter.post(
  "/mfa/disable",
  requireAuth,
  authRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = mfaDisableSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Password and code are required." } });
    }

    const user = await prisma.user.findUnique({ where: { id: req.auth!.sub } });
    if (!user || !user.mfaEnabled || !user.mfaSecretEnc) {
      return res.status(400).json({ error: { code: "MFA_NOT_ENABLED", message: "MFA is not enabled." } });
    }

    // Both checks run regardless of whether the first already failed, so a
    // caller can't learn which of the two was wrong from timing/short-circuiting.
    const [passwordValid, codeValid] = await Promise.all([
      verifyPassword(user.passwordHash, parsed.data.password),
      Promise.resolve(safeTotpCheck(parsed.data.code, decryptField(user.mfaSecretEnc))),
    ]);
    if (!passwordValid || !codeValid) {
      return res.status(401).json({ error: { code: "INVALID_CREDENTIALS", message: "Incorrect password or code." } });
    }

    await prisma.user.update({ where: { id: user.id }, data: { mfaEnabled: false, mfaSecretEnc: null } });
    await writeAuditLog({ req, actorId: user.id, action: "user.mfa_disabled", targetType: "user", targetId: user.id });

    return res.json({ message: "MFA disabled." });
  })
);
