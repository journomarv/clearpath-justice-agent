import { Router } from "express";
import { requireAuth } from "../middleware/auth";
import { prisma } from "../utils/prisma";
import { asyncHandler } from "../utils/asyncHandler";

export const prepareRouter = Router();

interface PlanStep {
  id: string;
  title: string;
  detail: string;
  done: boolean;
}

/**
 * PREPARE (MVP spec §2): a personalised action plan. Deliberately computed
 * on the fly from existing records rather than stored — every input here
 * (documents, offences, application, VERIFY fields) already has its own
 * source of truth, and duplicating it into a separate "plan" table would
 * just create a second place for it to drift out of sync.
 */
prepareRouter.get(
  "/plan",
  requireAuth,
  asyncHandler(async (req, res) => {
    const userId = req.auth!.sub;

    const [documents, offences, applications] = await Promise.all([
      prisma.document.findMany({ where: { userId }, select: { id: true, virusScanStatus: true } }),
      prisma.offence.findMany({
        where: { userId },
        select: {
          id: true,
          userConfirmed: true,
          assessments: { orderBy: { createdAt: "desc" }, take: 1, select: { finalDecision: true } },
        },
      }),
      prisma.application.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 1 }),
    ]);

    const cleanDocuments = documents.filter((d) => d.virusScanStatus === "clean");
    const unconfirmedOffences = offences.filter((o) => !o.userConfirmed);
    const decidedOffences = offences.filter((o) => o.assessments[0]?.finalDecision);
    const application = applications[0] ?? null;

    const steps: PlanStep[] = [
      {
        id: "upload_document",
        title: "Upload your SAPS criminal record",
        detail: "A clear PDF, JPG, or PNG of your record so ClearPath can identify what's on it.",
        done: cleanDocuments.length > 0,
      },
      {
        id: "confirm_offences",
        title: "Confirm your offence details",
        detail:
          offences.length === 0
            ? "Once a document is uploaded, review and confirm the offences ClearPath found (or add them manually)."
            : `${unconfirmedOffences.length} of ${offences.length} still need your confirmation.`,
        done: offences.length > 0 && unconfirmedOffences.length === 0,
      },
      {
        id: "review_eligibility",
        title: "Review your eligibility result",
        detail: "See your preliminary pathway on the Eligibility Results page.",
        done: decidedOffences.length > 0,
      },
      {
        id: "start_case",
        title: "Start your ClearPath case",
        detail: "Create a case so you have a reference to track progress against.",
        done: application !== null,
      },
      {
        id: "submit_application",
        title: "Submit your application",
        detail: "Once you've submitted to DOJ/SAPS, record the date and reference number under Case Tracking.",
        done: !!application?.submittedAt,
      },
      {
        id: "record_outcome",
        title: "Record the final outcome",
        detail: "When you hear back, log the outcome and date so your case is complete.",
        done: !!application?.outcome,
      },
    ];

    return res.json({
      steps,
      missing: {
        documentsMissing: cleanDocuments.length === 0,
        unconfirmedOffenceCount: unconfirmedOffences.length,
      },
    });
  })
);
