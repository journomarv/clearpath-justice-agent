import { Router } from "express";
import multer from "multer";
import crypto from "crypto";
import { prisma } from "../utils/prisma";
import { requireAuth } from "../middleware/auth";
import { sha256, encryptBuffer, decryptBuffer } from "../utils/encryption";
import { writeAuditLog } from "../middleware/auditLog";
import { asyncHandler } from "../utils/asyncHandler";
import { scanBuffer } from "../utils/clamav";
import { putObject, getObject } from "../utils/objectStorage";
import { logger } from "../utils/logger";

export const documentsRouter = Router();

const ALLOWED_MIME_TYPES = new Set(["application/pdf", "image/jpeg", "image/png"]);
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

const upload = multer({
  storage: multer.memoryStorage(), // never write to local disk unencrypted
  limits: {
    fileSize: MAX_FILE_SIZE_BYTES,
    files: 1,
    // Without these, a caller can stream unbounded numbers of fields and
    // exhaust memory without ever exceeding the file-size limit.
    fields: 10,
    parts: 15,
  },
  fileFilter: (_req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
      return cb(new Error("UNSUPPORTED_FILE_TYPE"));
    }
    cb(null, true);
  },
});

documentsRouter.post(
  "/",
  requireAuth,
  upload.single("file"),
  asyncHandler(async (req, res) => {
    if (!req.file || !req.auth) {
      return res.status(400).json({ error: { code: "NO_FILE", message: "No file provided" } });
    }

    // Magic-byte check as defense-in-depth beyond MIME/extension, which are
    // client-supplied and spoofable (docs/08-security-architecture.md §4).
    if (!hasValidMagicBytes(req.file.buffer, req.file.mimetype)) {
      return res.status(400).json({ error: { code: "INVALID_FILE", message: "File content does not match its declared type" } });
    }

    const storageKey = `${req.auth.sub}/${crypto.randomUUID()}`;
    const checksum = sha256(req.file.buffer);

    // Scan before anything is ever written to storage — an infected file
    // must never reach the object store, even encrypted.
    let scanResult: { infected: boolean; virusName: string | null };
    try {
      scanResult = await scanBuffer(req.file.buffer);
    } catch (err) {
      logger.error({ err }, "ClamAV scan failed; refusing to store unscanned file");
      return res.status(503).json({
        error: { code: "SCAN_UNAVAILABLE", message: "Could not scan the file right now. Please try again shortly." },
      });
    }

    if (scanResult.infected) {
      const document = await prisma.document.create({
        data: {
          userId: req.auth.sub,
          type: "saps_record",
          storageKey,
          mimeType: req.file.mimetype,
          checksumSha256: checksum,
          virusScanStatus: "infected",
        },
      });
      await writeAuditLog({
        req,
        actorId: req.auth.sub,
        action: "document.upload_rejected_infected",
        targetType: "document",
        targetId: document.id,
        after: { virusName: scanResult.virusName },
      });
      return res.status(400).json({
        error: { code: "INFECTED_FILE", message: "This file was rejected by malware scanning." },
      });
    }

    // Encrypted at the application layer (AES-256-GCM, same key material as
    // other [ENCRYPTED] fields) on top of MinIO's own server-side storage —
    // see development-status.md for why a self-hosted MinIO container is
    // used here instead of a cloud bucket.
    await putObject(storageKey, encryptBuffer(req.file.buffer));

    const document = await prisma.document.create({
      data: {
        userId: req.auth.sub,
        type: "saps_record",
        storageKey,
        mimeType: req.file.mimetype,
        checksumSha256: checksum,
        virusScanStatus: "clean",
      },
    });

    await writeAuditLog({
      req,
      actorId: req.auth.sub,
      action: "document.upload",
      targetType: "document",
      targetId: document.id,
    });

    return res.status(201).json({ id: document.id, virusScanStatus: document.virusScanStatus });
  })
);

function hasValidMagicBytes(buffer: Buffer, mimeType: string): boolean {
  const magicNumbers: Record<string, number[]> = {
    "application/pdf": [0x25, 0x50, 0x44, 0x46],
    "image/jpeg": [0xff, 0xd8, 0xff],
    "image/png": [0x89, 0x50, 0x4e, 0x47],
  };
  const expected = magicNumbers[mimeType];
  if (!expected) return false;
  if (buffer.length < expected.length) return false;
  return expected.every((byte, i) => buffer[i] === byte);
}

documentsRouter.get(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    const documents = await prisma.document.findMany({
      where: { userId: req.auth!.sub },
      select: { id: true, type: true, mimeType: true, virusScanStatus: true, uploadedAt: true },
      orderBy: { uploadedAt: "desc" },
    });
    return res.json({ documents });
  })
);

documentsRouter.get(
  "/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    // Scoped to the caller: a document id must never be enough on its own to
    // retrieve someone else's criminal record.
    const document = await prisma.document.findFirst({
      where: { id: req.params.id, userId: req.auth!.sub },
      select: { id: true, type: true, mimeType: true, virusScanStatus: true, uploadedAt: true },
    });
    if (!document) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Document not found" } });
    }

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "document.access",
      targetType: "document",
      targetId: document.id,
    });

    return res.json({ document });
  })
);

documentsRouter.get(
  "/:id/download",
  requireAuth,
  asyncHandler(async (req, res) => {
    // Same ownership scoping as GET /:id above — a document id alone must
    // never be enough to retrieve someone else's file bytes.
    const document = await prisma.document.findFirst({
      where: { id: req.params.id, userId: req.auth!.sub },
    });
    if (!document) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Document not found" } });
    }
    if (document.virusScanStatus !== "clean") {
      return res.status(409).json({
        error: { code: "NOT_AVAILABLE", message: "This file is not available for download." },
      });
    }

    const encrypted = await getObject(document.storageKey);
    const plaintext = decryptBuffer(encrypted);

    await writeAuditLog({
      req,
      actorId: req.auth!.sub,
      action: "document.download",
      targetType: "document",
      targetId: document.id,
    });

    res.setHeader("Content-Type", document.mimeType);
    res.setHeader("Content-Disposition", `attachment; filename="document-${document.id}"`);
    return res.send(plaintext);
  })
);
