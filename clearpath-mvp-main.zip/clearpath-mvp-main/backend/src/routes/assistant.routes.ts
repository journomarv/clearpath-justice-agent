import { Router } from "express";
import { z } from "zod";
import { requireAuth } from "../middleware/auth";
import { aiRateLimit } from "../middleware/security";
import { asyncHandler } from "../utils/asyncHandler";
import { writeAuditLog } from "../middleware/auditLog";
import { getAssistantReply } from "../services/aiAssistant.service";

export const assistantRouter = Router();

const turnSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().min(1).max(2000),
});

const messageSchema = z.object({
  message: z.string().min(1).max(2000),
  // Capped so a client can't grow the prompt (and cost) unbounded across a
  // long session — the assistant only needs recent context, not full history.
  history: z.array(turnSchema).max(10).default([]),
});

assistantRouter.post(
  "/message",
  requireAuth,
  aiRateLimit,
  asyncHandler(async (req, res) => {
    const parsed = messageSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "Invalid request." } });
    }

    let reply: string;
    try {
      reply = await getAssistantReply(parsed.data.message, parsed.data.history);
    } catch (err) {
      if (err instanceof Error && err.message === "ANTHROPIC_API_KEY not configured") {
        return res.status(503).json({
          error: { code: "ASSISTANT_UNAVAILABLE", message: "The assistant is temporarily unavailable." },
        });
      }
      throw err;
    }

    // Content is never logged — only that an interaction occurred, matching
    // the privacy posture of the rest of this platform's sensitive flows.
    await writeAuditLog({ req, actorId: req.auth!.sub, action: "assistant.message", targetType: "user", targetId: req.auth!.sub });

    return res.json({ reply });
  })
);
