declare module "clamdjs" {
  export interface Scanner {
    scanBuffer(buffer: Buffer, timeout?: number, chunkSize?: number): Promise<string>;
    scanStream(stream: NodeJS.ReadableStream, timeout?: number): Promise<string>;
    ping(): Promise<void>;
    version(): Promise<string>;
  }

  export function createScanner(host: string, port: number): Scanner;
  export function isCleanReply(reply: string): boolean;
}
