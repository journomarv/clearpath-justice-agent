// Loaded explicitly and first, before any other import. Every other module
// here gets its env vars transitively via config/env.ts's own `import
// "dotenv/config"`, which is normally enough — but empirically, under this
// host's pm2 (fork mode), letting dotenv load only via that transitive path
// left the process hanging forever before ever opening a Redis connection,
// every single time; loading it here directly, first, made it connect
// immediately, every time. Reproduced repeatedly with byte-identical logic
// otherwise. Keep this line first if this file is ever restructured.
import "dotenv/config";
import { startEligibilityWorker } from "./eligibility.worker";
import { startRetentionWorker, scheduleRetentionJob } from "./retention.worker";
import { logger } from "../utils/logger";

// Single pm2 process (clearpath-mvp-worker) running both queues — see
// ecosystem.config.js. Kept as separate files/exports so each can also be
// run standalone for testing (each has its own require.main bootstrap).
async function main() {
  const eligibilityWorker = startEligibilityWorker();
  await eligibilityWorker.waitUntilReady();
  logger.info("Eligibility worker connection ready");
  await scheduleRetentionJob();
  logger.info("Retention job scheduled");
  const retentionWorker = startRetentionWorker();
  await retentionWorker.waitUntilReady();
  logger.info("Workers started: eligibility, retention");

  const shutdown = async () => {
    logger.info("Workers shutting down");
    await Promise.all([eligibilityWorker.close(), retentionWorker.close()]);
    process.exit(0);
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

void main();
