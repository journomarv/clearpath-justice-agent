import { Worker } from "bullmq";
import { createRedisConnection, retentionQueue, RETENTION_QUEUE_NAME } from "../utils/queue";
import { prisma } from "../utils/prisma";
import { deleteUserDocuments } from "../utils/objectStorage";
import { env } from "../config/env";
import { logger } from "../utils/logger";

const DAY_MS = 24 * 60 * 60 * 1000;

/**
 * Registers the daily repeatable job. Safe to call on every process start —
 * BullMQ dedupes repeatable jobs by their repeat key, so this doesn't create
 * duplicates on a restart.
 */
export async function scheduleRetentionJob(): Promise<void> {
  await retentionQueue.add("daily-retention", {}, { repeat: { every: DAY_MS }, jobId: "daily-retention" });
}

/**
 * Privacy Policy §7 ("scheduled, automatic retention job... still in
 * development") — this is what closes that item. Purges expired/used
 * password-reset tokens and expired/revoked sessions past a configurable
 * window, and sweeps object storage for any soft-deleted account whose
 * documents weren't already cleaned up at delete-time (see
 * account.routes.ts POST /delete, which does this immediately — this is
 * only a backstop for anything that was missed, e.g. a delete request that
 * ran before Phase 3's object storage existed).
 */
export function startRetentionWorker(): Worker {
  return new Worker(
    RETENTION_QUEUE_NAME,
    async () => {
      const tokenCutoff = new Date(Date.now() - env.RETENTION_TOKEN_DAYS * DAY_MS);
      const sessionCutoff = new Date(Date.now() - env.RETENTION_SESSION_DAYS * DAY_MS);

      const purgedTokens = await prisma.passwordResetToken.deleteMany({
        where: {
          OR: [{ usedAt: { not: null, lt: tokenCutoff } }, { expiresAt: { lt: tokenCutoff } }],
        },
      });

      const purgedSessions = await prisma.session.deleteMany({
        where: {
          OR: [{ revokedAt: { not: null, lt: sessionCutoff } }, { expiresAt: { lt: sessionCutoff } }],
        },
      });

      const deletedUsers = await prisma.user.findMany({ where: { status: "deleted" }, select: { id: true } });
      let sweptDocumentCount = 0;
      for (const user of deletedUsers) {
        const documentCount = await prisma.document.count({ where: { userId: user.id } });
        if (documentCount > 0) {
          await deleteUserDocuments(user.id).catch((err) =>
            logger.error({ err, userId: user.id }, "Retention sweep: failed to delete stray documents")
          );
          sweptDocumentCount += documentCount;
        }
      }

      const summary = {
        purgedTokens: purgedTokens.count,
        purgedSessions: purgedSessions.count,
        sweptDocumentCount,
      };
      logger.info(summary, "Retention job completed");
      return summary;
    },
    { connection: createRedisConnection() }
  );
}

if (require.main === module) {
  void (async () => {
    await scheduleRetentionJob();
    startRetentionWorker();
    logger.info("Retention worker started");
  })();
}
