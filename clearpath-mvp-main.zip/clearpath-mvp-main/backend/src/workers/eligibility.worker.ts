import { Worker, type Job } from "bullmq";
import { prisma } from "../utils/prisma";
import { createRedisConnection, ELIGIBILITY_QUEUE_NAME } from "../utils/queue";
import { getObject } from "../utils/objectStorage";
import { decryptBuffer, encryptField } from "../utils/encryption";
import { extractText } from "../services/textExtraction.service";
import { extractOffencesFromText } from "../services/aiEligibility.service";
import { env } from "../config/env";
import { logger } from "../utils/logger";

export interface EligibilityJobData {
  documentId: string;
  userId: string;
}

export type EligibilityJobResult =
  | { status: "needs_manual_review"; reason: string }
  | { status: "extracted"; offenceIds: string[] }
  | { status: "ai_not_configured" };

/**
 * Runs the extraction half of the pipeline documented in
 * docs/05-ai-workflow.md (steps 1-4): fetch the uploaded bytes, extract text,
 * run Claude structured extraction, create Offence rows awaiting the user's
 * confirmation (gate 1). The rules-engine + explanation half (steps 6-7)
 * runs separately, per-offence, when the user confirms via
 * PATCH /eligibility/offences/:id — see eligibility.routes.ts.
 */
export function startEligibilityWorker(): Worker<EligibilityJobData, EligibilityJobResult> {
  return new Worker<EligibilityJobData, EligibilityJobResult>(
    ELIGIBILITY_QUEUE_NAME,
    async (job: Job<EligibilityJobData>): Promise<EligibilityJobResult> => {
      const { documentId, userId } = job.data;

      const document = await prisma.document.findFirst({ where: { id: documentId, userId } });
      if (!document) {
        throw new Error("Document not found for this user");
      }

      const encrypted = await getObject(document.storageKey);
      const plaintext = decryptBuffer(encrypted);

      const { text, needsManualReview } = await extractText(plaintext, document.mimeType);
      if (needsManualReview) {
        return { status: "needs_manual_review", reason: "No extractable text (likely a scanned/image-only PDF)." };
      }

      if (!env.ANTHROPIC_API_KEY) {
        // Documented, expected state until a real key is configured — see
        // development-status.md. Don't crash the worker for this.
        logger.warn({ documentId }, "Skipping AI extraction: ANTHROPIC_API_KEY not configured");
        return { status: "ai_not_configured" };
      }

      const extracted = await extractOffencesFromText(text);

      const offences = await Promise.all(
        extracted.map((o) =>
          prisma.offence.create({
            data: {
              documentId: document.id,
              userId,
              offenceDescriptionEnc: encryptField(o.offenceDescription),
              offenceDate: o.offenceDate ? new Date(o.offenceDate) : null,
              court: o.court,
              sentenceType: o.sentenceType ?? undefined,
              sentenceDetails: o.sentenceDetails,
              userConfirmed: false,
              extractionConfidence: o.confidence,
            },
          })
        )
      );

      return { status: "extracted", offenceIds: offences.map((o) => o.id) };
    },
    { connection: createRedisConnection(), concurrency: 2 }
  );
}

if (require.main === module) {
  const worker = startEligibilityWorker();
  logger.info("Eligibility worker started");

  const shutdown = async () => {
    logger.info("Eligibility worker shutting down");
    await worker.close();
    process.exit(0);
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}
