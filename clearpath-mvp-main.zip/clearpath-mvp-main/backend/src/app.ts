import express from "express";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import multer from "multer";
import { randomUUID } from "crypto";
import { securityHeaders, corsPolicy, apiRateLimit } from "./middleware/security";
import { auditLogContext } from "./middleware/auditLog";
import { logger } from "./utils/logger";
import { authRouter } from "./routes/auth.routes";
import { accountRouter } from "./routes/account.routes";
import { documentsRouter } from "./routes/documents.routes";
import { eligibilityRouter } from "./routes/eligibility.routes";
import { applicationsRouter } from "./routes/applications.routes";
import { adminRouter } from "./routes/admin.routes";
import { contactRouter } from "./routes/contact.routes";
import { analyticsRouter } from "./routes/analytics.routes";
import { assistantRouter } from "./routes/assistant.routes";
import { prepareRouter } from "./routes/prepare.routes";
import { passportRouter } from "./routes/passport.routes";

export const app = express();

// One hop only: nginx. nginx sets X-Forwarded-For with
// $proxy_add_x_forwarded_for, which appends the real socket address as the
// LAST entry, and Express with trust proxy = 1 reads that last entry. A
// client that sends its own X-Forwarded-For therefore cannot shift what
// req.ip resolves to (verified by test), so rate limiting and audit-log IPs
// can't be spoofed. Changing either side of that pairing breaks the
// guarantee — keep them in sync.
app.set("trust proxy", 1);

app.use(securityHeaders);
app.use(corsPolicy);
app.use(
  pinoHttp({
    logger,
    genReqId: (req, res) => {
      const id = randomUUID();
      res.setHeader("X-Request-Id", id);
      return id;
    },
    // The default serialiser logs every request/response header, which puts
    // Authorization, Cookie and Set-Cookie into the log stream in plain text.
    serializers: {
      req: (req) => ({ id: req.id, method: req.method, url: req.url }),
      res: (res) => ({ statusCode: res.statusCode }),
    },
  })
);
app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
app.use(auditLogContext);

app.get("/health", (_req, res) => res.json({ status: "ok" }));

// Everything under /api/v1 returns account-specific data. Marking it
// no-store keeps criminal-record data out of browser disk caches and any
// intermediary that would otherwise honour default heuristics.
app.use("/api/v1", apiRateLimit, (_req, res, next) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, private");
  res.setHeader("Pragma", "no-cache");
  next();
});

app.use("/api/v1/auth", authRouter);
app.use("/api/v1/account", accountRouter);
app.use("/api/v1/documents", documentsRouter);
app.use("/api/v1/eligibility", eligibilityRouter);
app.use("/api/v1/applications", applicationsRouter);
app.use("/api/v1/admin", adminRouter);
app.use("/api/v1/contact", contactRouter);
app.use("/api/v1/analytics", analyticsRouter);
app.use("/api/v1/assistant", assistantRouter);
app.use("/api/v1/prepare", prepareRouter);
app.use("/api/v1/passport", passportRouter);

app.use((req, res) => {
  res.status(404).json({ error: { code: "NOT_FOUND", message: "Not found" } });
});

// Centralized error handler — never leak stack traces or internal detail.
// Reached only because every async handler is wrapped in asyncHandler();
// see src/utils/asyncHandler.ts for why that wrapper is mandatory.
app.use((err: Error, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const requestId = (req as express.Request & { id?: string }).id ?? null;

  if (err instanceof multer.MulterError) {
    const status = err.code === "LIMIT_FILE_SIZE" ? 413 : 400;
    logger.warn({ code: err.code, requestId }, "Upload rejected");
    return res.status(status).json({
      error: {
        code: err.code === "LIMIT_FILE_SIZE" ? "FILE_TOO_LARGE" : "INVALID_UPLOAD",
        message: err.code === "LIMIT_FILE_SIZE" ? "File exceeds the 10MB limit." : "Upload rejected.",
        requestId,
      },
    });
  }

  if (err.message === "UNSUPPORTED_FILE_TYPE") {
    return res.status(400).json({
      error: { code: "UNSUPPORTED_FILE_TYPE", message: "Only PDF, JPG, and PNG files are accepted.", requestId },
    });
  }

  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({ error: { code: "INVALID_JSON", message: "Malformed JSON body.", requestId } });
  }

  // Full detail to the server log, an opaque reference to the caller.
  logger.error({ err, path: req.path, requestId }, "Unhandled error");
  res.status(500).json({ error: { code: "INTERNAL_ERROR", message: "Something went wrong", requestId } });
});
