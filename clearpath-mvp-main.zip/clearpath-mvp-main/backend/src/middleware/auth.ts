import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/env";
import { JWT_ALGORITHM, JWT_ISSUER, JWT_AUDIENCE } from "../utils/tokens";

export type Role = "applicant" | "reviewer" | "admin" | "super_admin";

export interface AuthPayload {
  sub: string; // user id
  role: Role;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthPayload;
    }
  }
}

/** Verifies the short-lived access token. No route is trusted without this. */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ error: { code: "UNAUTHENTICATED", message: "Missing token" } });
  }
  const token = header.slice("Bearer ".length);
  try {
    // `algorithms` is pinned deliberately: without it the library will accept
    // whatever algorithm the token's own header asks for, which lets an
    // attacker influence how their token is validated. Issuer and audience
    // are asserted for the same reason — a token must have been minted by
    // this service, for this service.
    const payload = jwt.verify(token, env.JWT_ACCESS_SECRET, {
      algorithms: [JWT_ALGORITHM],
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
    }) as jwt.JwtPayload & { role?: string };

    if (typeof payload.sub !== "string" || !isRole(payload.role)) {
      return res.status(401).json({ error: { code: "UNAUTHENTICATED", message: "Invalid token" } });
    }

    req.auth = { sub: payload.sub, role: payload.role };
    next();
  } catch {
    return res.status(401).json({ error: { code: "UNAUTHENTICATED", message: "Invalid or expired token" } });
  }
}

const ROLES: readonly Role[] = ["applicant", "reviewer", "admin", "super_admin"];

function isRole(value: unknown): value is Role {
  return typeof value === "string" && (ROLES as readonly string[]).includes(value);
}

/**
 * Server-side RBAC gate. UI hiding is not a security control — every
 * privileged route must also enforce this. See docs/08-security-architecture.md §2.
 */
export function requireRole(...allowed: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth || !allowed.includes(req.auth.role)) {
      return res.status(403).json({ error: { code: "FORBIDDEN", message: "Insufficient permissions" } });
    }
    next();
  };
}
