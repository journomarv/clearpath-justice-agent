import { Request, Response, NextFunction } from "express";
import { prisma } from "../utils/prisma";

/**
 * Writes an append-only audit_logs row. Call explicitly from route handlers
 * for state-changing actions (login, document access, admin overrides,
 * status changes, exports, deletion) — see docs/08-security-architecture.md §5.
 * Never UPDATE/DELETE an AuditLog row from application code.
 */
export async function writeAuditLog(params: {
  req: Request;
  actorId: string | null;
  action: string;
  targetType: string;
  targetId?: string;
  before?: unknown;
  after?: unknown;
}) {
  const { req, actorId, action, targetType, targetId, before, after } = params;
  await prisma.auditLog.create({
    data: {
      actorId,
      action,
      targetType,
      targetId,
      before: before === undefined ? undefined : (before as object),
      after: after === undefined ? undefined : (after as object),
      ip: req.ip,
      userAgent: req.headers["user-agent"] ?? null,
    },
  });
}

/** Attaches req.auditLog() so any handler can log without re-importing prisma. */
export function auditLogContext(req: Request, _res: Response, next: NextFunction) {
  (req as Request & { auditLog: typeof writeAuditLog }).auditLog = writeAuditLog;
  next();
}
