import "dotenv/config";
import { z } from "zod";

// Fail fast on boot if security-critical config is missing/malformed —
// never fall back to an insecure default for secrets.
const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().default(4000),
  DATABASE_URL: z.string().min(1),
  JWT_ACCESS_SECRET: z.string().min(32),
  JWT_REFRESH_SECRET: z.string().min(32),
  JWT_ACCESS_TTL: z.string().default("15m"),
  JWT_REFRESH_TTL: z.string().default("7d"),
  FIELD_ENCRYPTION_KEY_BASE64: z.string().min(1),
  REDIS_URL: z.string().min(1),
  STORAGE_BUCKET: z.string().min(1),
  STORAGE_REGION: z.string().min(1),
  // Self-hosted MinIO endpoint (S3-compatible). Unset means "use AWS S3
  // directly" — set this to talk to a MinIO container instead.
  STORAGE_ENDPOINT: z.string().url().optional(),
  STORAGE_ACCESS_KEY_ID: z.string().default(""),
  STORAGE_SECRET_ACCESS_KEY: z.string().default(""),
  CLAMAV_HOST: z.string().default("127.0.0.1"),
  CLAMAV_PORT: z.coerce.number().default(3310),

  // Retention job (src/workers/retention.worker.ts) — how long expired/used
  // tokens and expired/revoked sessions are kept before being purged.
  RETENTION_TOKEN_DAYS: z.coerce.number().default(30),
  RETENTION_SESSION_DAYS: z.coerce.number().default(30),
  ANTHROPIC_API_KEY: z.string().optional(),
  ANTHROPIC_MODEL: z.string().default("claude-sonnet-5"),
  FRONTEND_ORIGIN: z.string().url(),

  // Outbound mail. Defaults target the host's local postfix, which applies
  // DKIM signing for terminalvelocityai.tech — see services/email.service.ts.
  SMTP_HOST: z.string().default("127.0.0.1"),
  SMTP_PORT: z.coerce.number().default(25),
  MAIL_FROM: z.string().email().default("noreply@terminalvelocityai.tech"),
  CONTACT_RECIPIENT: z.string().email(),
});

export const env = envSchema.parse(process.env);
