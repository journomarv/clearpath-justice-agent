-- AI Assistant chatbot cut from MVP scope (see docs/05-ai-workflow.md) —
-- the extraction and eligibility-explanation Claude calls remain; only the
-- RAG chat endpoint and its storage are removed.
DROP TABLE IF EXISTS "chat_messages";
DROP TYPE IF EXISTS "ChatRole";
