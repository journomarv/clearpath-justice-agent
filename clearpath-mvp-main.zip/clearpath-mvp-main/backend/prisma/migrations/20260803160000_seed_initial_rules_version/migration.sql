-- Seeds the initial versioned ruleset the deterministic eligibility engine
-- (src/services/rulesEngine.service.ts) evaluates offences against. Encodes
-- the Criminal Procedure Act 271A-style criteria already described in
-- docs/05-ai-workflow.md (waiting period by sentence type, an excluded-
-- offence schedule, disqualifying-subsequent-conviction check) at MVP
-- fidelity — NOT yet reviewed by a South African attorney (see TODO.md
-- item 3). Rules teams edit future versions via new rows in this table, not
-- code deploys, so every eligibility_assessments row stays reproducible
-- against the exact ruleset that produced it.
INSERT INTO "rules_versions" ("id", "version", "effective_from", "ruleset", "created_by", "created_at")
VALUES (
  '00000000-0000-4000-8000-000000000001',
  '2026-08-03-cpa271a-v1',
  CURRENT_TIMESTAMP,
  '{
    "waitingPeriodDaysBySentenceType": {
      "fine": 3650,
      "caution": 3650,
      "imprisonment_suspended": 3650,
      "imprisonment": 7300,
      "other": 3650
    },
    "excludedOffenceKeywords": [
      "rape", "sexual assault", "sexual offence", "sexual offense",
      "child", "minor", "incest", "human trafficking",
      "murder", "attempted murder", "terrorism"
    ]
  }'::jsonb,
  NULL,
  CURRENT_TIMESTAMP
)
ON CONFLICT ("version") DO NOTHING;
