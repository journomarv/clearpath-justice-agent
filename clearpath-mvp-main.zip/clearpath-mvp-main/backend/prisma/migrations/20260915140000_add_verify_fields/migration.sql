-- CreateEnum
CREATE TYPE "ApplicationOutcome" AS ENUM ('granted', 'refused', 'withdrawn');

-- AlterTable
ALTER TABLE "applications"
  ADD COLUMN "reference_number" TEXT,
  ADD COLUMN "submitted_at" TIMESTAMP(3),
  ADD COLUMN "outcome" "ApplicationOutcome",
  ADD COLUMN "outcome_date" TIMESTAMP(3);
