# API Architecture

REST + JSON over HTTPS. OpenAPI 3.1 spec generated from Zod schemas (single
source of truth for validation + docs). Versioned under `/api/v1`.

## Conventions
- Auth: `Authorization: Bearer <access_token>` (15 min) + httpOnly refresh cookie.
- Errors: `{ error: { code, message, requestId } }`, no stack traces/internal detail leaked to client.
- Every mutating request writes an `audit_logs` row (middleware, not per-handler code).
- Pagination: cursor-based (`?cursor=&limit=`).

## Endpoints

### Auth
- `POST /auth/register`
- `POST /auth/login` (+ MFA challenge step if enabled)
- `POST /auth/refresh`
- `POST /auth/logout`
- `POST /auth/password/forgot`
- `POST /auth/password/reset`
- `POST /auth/mfa/setup`, `POST /auth/mfa/verify`

### User / Profile
- `GET /me`
- `PATCH /me`
- `GET /me/export` (POPIA data export)
- `DELETE /me` (right to erasure — soft delete + purge job)
- `GET /me/notifications`, `PATCH /me/notifications/:id/read`

### Documents
- `POST /documents` (multipart upload → virus scan → encrypted storage)
- `GET /documents/:id` (returns short-TTL signed URL, not raw file)
- `GET /documents` (list mine)

### Eligibility
- `POST /eligibility/analyze` `{ documentId }` → triggers OCR + extraction + AI reasoning pipeline (async job, returns `jobId`)
- `GET /eligibility/analyze/:jobId` → poll status/result
- `GET /eligibility/offences` → extracted (or manually entered) offences + confirmations
- `POST /eligibility/offences` `{ documentId, offenceDescription, ... }` → manual-entry fallback when extraction produced nothing
- `PATCH /eligibility/offences/:id` (user confirms/edits extracted data)

### Applications
- `POST /applications` (create case from confirmed offences)
- `GET /applications/:id`
- `GET /applications/:id/timeline`
- `POST /applications/:id/generate-documents` (fills templates)

### Admin (role: reviewer/admin/super_admin, enforced server-side)
- `GET /admin/cases` (filter/sort queue)
- `GET /admin/cases/:id`
- `POST /admin/cases/:id/decision` `{ offenceId, decision, overrideReason? }`
- `POST /admin/cases/:id/documents/:docId/approve`
- `PATCH /admin/cases/:id/status`
- `GET /admin/reports/export?format=csv|pdf`
- `GET /admin/audit-logs` (super_admin only)

## Async / Background Jobs
Long-running work (OCR, LLM calls, PDF generation, malware scan) runs in a
queue (BullMQ/Redis or cloud-native equivalent) — API responds immediately
with a job reference; frontend polls or receives a websocket/SSE push. This
keeps request timeouts short and makes AI-cost/rate spikes controllable
(per-user concurrency limits on the queue).

## Internal service boundaries
```
Frontend (Next.js)
   │  HTTPS/JSON
   ▼
API Gateway (rate limit, auth, RBAC, WAF)
   │
   ▼
Core API (Express/Node, TypeScript)
   ├─▶ Postgres (Prisma)
   ├─▶ Object storage (encrypted documents)
   ├─▶ Job queue → Worker (OCR, AI eligibility, PDF gen, AV scan)
   │        └─▶ Claude API (extraction + eligibility reasoning + assistant)
   └─▶ Audit log store (append-only)
```
