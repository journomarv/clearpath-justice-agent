# Administrator Workflow

## Roles
- **Reviewer**: works assigned cases — confirms/overrides AI eligibility, approves generated documents, updates status, adds notes.
- **Admin**: everything a Reviewer can do, plus manages the case queue/assignment and exports reports.
- **Super Admin**: everything above, plus manages staff accounts/roles and has read access to raw audit logs.

## Case Queue → Decision Flow
```
New case appears in queue (status: Submitted, unassigned)
   │
   ▼
Admin assigns to a Reviewer (or self-assigns)
   │
   ▼
Reviewer opens Case Detail:
   - views uploaded SAPS record + AI extraction side-by-side
   - views AI eligibility verdict + reasoning + confidence per offence
   - Confirms AI verdict  → moves to document generation
   - OR Overrides verdict → must enter a reason (audit-logged,
     surfaced later in AI-quality review)
   │
   ▼
Reviewer reviews auto-generated application + affidavit
   - Approve → document becomes visible/downloadable to user,
     case status advances
   - Request changes → status → "Waiting for Information",
     user-visible note explains what's needed
   │
   ▼
Final status set: Approved / Rejected (with user-visible reasoning)
   │
   ▼
User notified automatically on every status change
```

## Reporting (Admin/Super Admin)
- Export CSV/PDF: case volumes, status breakdown, average turnaround time, AI/Reviewer agreement rate, offence-type distribution.
- Filterable by date range, reviewer, outcome — supports funder/NGO impact reporting (ties to `01-product-specification.md` §6 success metrics).

## Governance controls
- Reviewers cannot edit their own AI-override audit entries (append-only).
- Super Admin can view but not silently alter another reviewer's decision — any change is itself a new audit-logged action with a reason.
- Staff account creation/role changes require Super Admin action and are logged.
