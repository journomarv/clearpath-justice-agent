# Estimated Development Budget (MVP, ~3–4 months)

Figures are indicative ranges (ZAR), for a lean team building the scope in
this document. Actuals depend on whether you hire contractors, an agency, or
build in-house; use this to scope a proposal, not as a quote.

## Team (3–4 months, part- or full-time mix)
| Role | Notes | Est. cost (ZAR) |
|---|---|---|
| Full-stack engineer(s) x1–2 | Next.js + Node/TS, can be 1 senior or 2 mid | R180,000 – R360,000 |
| Security/DevSecOps (part-time/consulting) | hardening review, IaC, KMS setup | R40,000 – R80,000 |
| UX/UI design (part-time) | wireframes → hi-fi, accessibility pass | R30,000 – R60,000 |
| Legal review (SA attorney, contracted) | validate document templates, POPIA sign-off | R25,000 – R60,000 |
| QA / pen-test (external firm) | pre-launch penetration test | R40,000 – R90,000 |
| **Team subtotal** | | **R315,000 – R650,000** |

## Infrastructure & tooling (first year, low-cost managed stack)
| Item | Est. monthly (ZAR) | Notes |
|---|---|---|
| Cloud hosting (compute+DB+storage) | R2,500 – R8,000 | scales with usage; serverless-first keeps idle cost near zero |
| Claude API usage | R3,000 – R15,000 | scales with document volume; cap via job-queue concurrency limits |
| OCR service (if not self-hosted) | R500 – R3,000 | |
| Email/SMS notifications | R500 – R1,500 | |
| Monitoring/log aggregation | R500 – R2,000 | |
| Domain/SSL/misc | R200 | |
| **Infra subtotal** | **~R7,200 – R29,700/mo** | |

## Total indicative range
- **One-off build cost**: ~R315,000 – R650,000
- **Ongoing run cost**: ~R7,000 – R30,000/month, scaling with pilot user volume

## Cost-control levers already built into the design
- Managed/serverless-first hosting avoids idle infra spend pre-traction.
- Async job queue caps concurrent AI calls, preventing runaway LLM spend.
- MVP scope deliberately excludes government integrations and native mobile — the most expensive, least-certain items — until pilot data justifies the investment.
