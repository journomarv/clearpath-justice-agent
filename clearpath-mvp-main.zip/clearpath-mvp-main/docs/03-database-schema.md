# Database Schema (see also `/backend/prisma/schema.prisma` for the runnable version)

Postgres. All PII/special-category fields marked `[ENCRYPTED]` are stored as
ciphertext (AES-256-GCM, application-level) — see `08-security-architecture.md`.

## users
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| email | citext unique | |
| password_hash | text | Argon2id |
| full_name | text `[ENCRYPTED]` | |
| id_number | text `[ENCRYPTED]` | SA ID, optional at signup |
| phone | text `[ENCRYPTED]` | |
| role | enum(applicant, reviewer, admin, super_admin) | default applicant |
| mfa_secret | text `[ENCRYPTED]` nullable | |
| mfa_enabled | boolean | |
| consent_version | text | Privacy Policy version accepted |
| consent_at | timestamptz | |
| status | enum(active, locked, deleted) | soft delete for erasure requests |
| created_at / updated_at | timestamptz | |

## sessions
id PK, user_id FK, refresh_token_hash, user_agent, ip, created_at, expires_at, revoked_at nullable
— enables server-side session revocation.

## documents
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| user_id | FK users | |
| type | enum(saps_record, supporting_doc, generated_application, generated_affidavit) | |
| storage_key | text | pointer to encrypted object storage, never a public URL |
| mime_type | text | |
| checksum_sha256 | text | integrity check |
| virus_scan_status | enum(pending, clean, infected) | |
| uploaded_at | timestamptz | |

## offences
Extracted per criminal record, one row per offence line item.
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| document_id | FK documents | source SAPS record |
| user_id | FK users | |
| offence_description | text `[ENCRYPTED]` | |
| offence_date | date | |
| court | text | |
| sentence_type | enum(fine, imprisonment, imprisonment_suspended, caution, other) | |
| sentence_details | text | |
| user_confirmed | boolean | user reviewed/edited extraction |
| extraction_confidence | numeric | AI OCR/extraction confidence 0-1 |

## eligibility_assessments
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| offence_id | FK offences | |
| rules_version | text | which versioned rules table was applied |
| ai_recommendation | enum(eligible, not_eligible, uncertain) | |
| ai_reasoning | text | human-readable explanation shown to user |
| ai_confidence | numeric | |
| reviewer_id | FK users nullable | who confirmed/overrode |
| final_decision | enum(eligible, not_eligible, uncertain) nullable | reviewer-confirmed value |
| override_reason | text nullable | required if final != ai_recommendation |
| created_at / decided_at | timestamptz | |

## applications
One expungement application case per user (can bundle multiple offences).
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| user_id | FK users | |
| status | enum(submitted, under_review, waiting_for_information, approved, rejected) | |
| assigned_reviewer_id | FK users nullable | |
| generated_document_id | FK documents nullable | the DOJ&CD application PDF |
| generated_affidavit_id | FK documents nullable | |
| notes | text | reviewer-visible + user-visible split (see application_notes) |
| created_at / updated_at | timestamptz | |

## application_notes
id PK, application_id FK, author_id FK users, visibility enum(internal, user_visible), body text, created_at
— powers the case-tracking timeline shown to the user vs. internal reviewer notes.

## notifications
id PK, user_id FK, type, title, body, read_at nullable, created_at

## audit_logs
id PK, actor_id FK users nullable (nullable for system events), action, target_type, target_id,
before jsonb nullable, after jsonb nullable, ip, user_agent, created_at
— append-only; see security doc §5.

— scoped RAG corpus lives outside the DB (vector store); this table is just the transcript for support/audit.

## rules_versions (Eligibility rule engine, explainability)
id PK, version text unique, effective_from date, ruleset jsonb (waiting periods, excluded offence schedules, sentence-type exclusions), created_by, created_at
— every `eligibility_assessments` row references the exact ruleset that produced it, so results are reproducible and auditable even after the law/rules change.
