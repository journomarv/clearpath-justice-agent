# Product Roadmap

## Phase 0 — MVP (this document set)
Landing site, auth, dashboard, AI eligibility checker, document upload,
application generator, case tracking, AI assistant, admin portal, security/
POPIA baseline. Goal: pilot with 50–100 real users via NGO/legal-aid partners.

## Phase 1 — Pilot hardening (post-MVP, months 2–3 after launch)
- Incorporate pilot feedback; tune extraction accuracy per real SAPS record formats.
- Add partner-attorney co-sign workflow if a partner law firm is involved.
- Formal penetration test + POPIA compliance review with real user data volumes.

## Phase 2 — Scale & self-serve growth (months 4–6)
- Payments (if a paid tier is introduced) via PCI-DSS Level 1 gateway (tokenized, SAQ-A).
- Multi-language UI (isiZulu, isiXhosa, Afrikaans, Sesotho — highest-impact languages first).
- Community Advice Office portal (bulk-assist mode for case workers).

## Phase 3 — Institutional integration (months 6–12)
- Government system integration for status lookups if/when SAPS/DOJ&CD expose an API or MOU-based data-sharing channel.
- Law firm dashboard (multi-client case management, white-label option).
- Analytics dashboard for funders/NGOs (impact reporting at scale).

## Phase 4 — Digital Justice Passport (12+ months)
- Digital Certificate of Expungement issuance workflow (pending legal/government partnership).
- "Digital Justice Passport" — portable, verifiable record of expungement status usable with employers (with user-controlled sharing/consent, POPIA-compliant).

## Phase 5 — Proactive access to justice
- Authorized-dataset batch screening (with proper legal mandate/MOU) to proactively identify and reach out to eligible individuals rather than waiting for self-referral.
- AI-assisted case management for legal aid organizations at scale.
- Native mobile app once usage patterns justify the investment over responsive web.

See `14-future-roadmap.md` for the full detail behind Phases 2–5.
