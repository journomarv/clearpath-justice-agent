# Security Architecture — PCI-DSS-grade control baseline + POPIA compliance

## 0. Framing: why "PCI level" and what it actually means here
The MVP does not take payments, so it is **not in scope for PCI-DSS** (which governs cardholder data specifically). Because you asked for security "to the level of PCI," we adopt **PCI-DSS's control rigor as our baseline security bar** — encryption everywhere, strict network segmentation, least-privilege access, comprehensive logging, quarterly vulnerability scanning, formal key management, secure SDLC — and apply it to the data that actually matters here: **criminal record data, ID numbers, and other special personal information under POPIA**, which South African law treats with *at least* as much sensitivity as card data.

**If/when payments are added** (Phase 2+): never let ClearPath's own servers touch raw card data. Use a PCI-DSS Level 1 certified gateway (Stripe, Paystack, PayFast) with hosted fields / tokenization so ClearPath qualifies for the lightest self-assessment tier (SAQ-A), inheriting PCI compliance without taking on cardholder-data-environment scope.

## 1. Data Classification
| Class | Examples | Controls |
|---|---|---|
| Special personal information (POPIA §26) | Criminal record, ID number, biometric-adjacent OCR text | Field-level encryption, access logged per-field, minimum necessary retention, never in analytics/logs |
| Personal information | Name, email, phone, address | Encrypted at rest, masked in UI/logs |
| Operational | Case status, timestamps, non-identifying metrics | Standard controls |
| Public | Marketing content | No special controls |

## 2. Identity & Access
- **Password storage**: Argon2id (memory-hard), never bcrypt/MD5/SHA. Peppered + per-user salt (library default).
- **MFA**: TOTP-based MFA mandatory for all Admin/Reviewer/Super Admin accounts; optional (encouraged) for applicants.
- **Session**: short-lived JWT access token (15 min) in memory + httpOnly, `Secure`, `SameSite=Strict` refresh cookie (7 days, rotated on use, revocable server-side via a session table so logout/compromise is instant — not "wait for expiry").
- **RBAC**: `applicant`, `reviewer`, `admin`, `super_admin` roles enforced server-side on every route (middleware, not just UI hiding). Reviewers cannot see other reviewers' internal notes across cases they aren't assigned; Super Admin only role that can manage staff accounts and export raw audit logs.
- **Account lockout**: exponential backoff + lockout after 5 failed attempts, alert to user via email.
- **Least privilege infra**: DB users scoped per-service; no shared "root" DB credential between services.

## 3. Encryption
- **In transit**: TLS 1.2+ enforced everywhere (HSTS preload), TLS 1.3 preferred; internal service-to-service traffic also over TLS inside the VPC.
- **At rest**:
  - Database: provider-managed encryption at rest (AES-256) PLUS application-level field encryption (AES-256-GCM, envelope encryption) for ID numbers, offence details, and OCR-extracted text — so a raw DB dump/backup leak is not enough to disclose special personal information.
  - File storage (uploaded SAPS records, generated PDFs): server-side encryption (SSE-KMS or equivalent) + private buckets, signed short-TTL URLs only, no public bucket ever.
- **Key management**: keys held in a managed KMS/secrets manager (not in code, not in env files committed to git); envelope-encryption data keys rotated per policy; separate keys per environment (dev/staging/prod).

## 4. Application Security Controls
- Input validation & schema enforcement (Zod/JSON-schema) on every API boundary.
- Parameterized queries only (Prisma ORM) — no raw string-concatenated SQL.
- File upload hardening: strict MIME/type allow-list (PDF/JPG/PNG only), magic-byte verification (not just extension), size cap (10MB), antivirus/malware scan (ClamAV or cloud equivalent) before the file is persisted, files stored outside the web root with randomized non-guessable object keys.
- OWASP-standard headers via Helmet: CSP, X-Frame-Options=DENY, X-Content-Type-Options=nosniff, Referrer-Policy.
- **CSRF**: no double-submit token is implemented, and none is currently needed. Authenticated requests are authorised by an `Authorization: Bearer` header, which a cross-site attacker cannot cause a browser to attach automatically; the refresh cookie is `SameSite=Strict` and scoped to `/api/v1/auth`. The residual exposure is a forced logout, which is a nuisance rather than a compromise. **If authentication ever moves to cookie-only, CSRF tokens become mandatory** — revisit this line at that point.
- All async route handlers are wrapped in `asyncHandler()`. This is a security control, not a style choice: Express 4 does not catch rejected promises from async handlers, and Node's default behaviour is to terminate the process — making any input that reliably throws into a remote denial-of-service. See `backend/src/utils/asyncHandler.ts`.
- Login responses are padded to a constant floor (`backend/src/utils/constantTime.ts`) so response latency cannot be used to enumerate which email addresses hold accounts.
- JWTs are verified with a pinned algorithm plus issuer/audience assertions, so a token's own header cannot influence how it is validated.
- Rate limiting + progressive throttling on auth, password reset, and AI endpoints (abuse/cost control).
- Dependency & container scanning in CI (npm audit / Snyk / Trivy) gating merges on critical CVEs.
- Secrets never logged; log redaction middleware strips known sensitive field names before writing logs.

## 5. Audit Logging & Monitoring
- Append-only audit log table: `who, what, target record, before/after (for admin overrides), timestamp, IP, user-agent` for: login/logout, MFA events, document access/download, AI eligibility runs, admin approvals/overrides, status changes, data export, account deletion.
- Audit logs are themselves access-controlled (Super Admin only) and tamper-evident (hash-chained or written to write-once storage).
- Centralized log aggregation with alerting on: repeated auth failures, privilege escalation attempts, mass data export, off-hours admin activity.
- Uptime + error monitoring (e.g. health checks, APM) with on-call alerting.

## 6. POPIA Compliance Specifics
- **Lawful processing basis**: explicit, timestamped consent captured at registration, versioned Privacy Policy (re-consent required if policy changes materially).
- **Purpose limitation**: criminal record data used only for eligibility assessment and application generation — never for marketing/analytics.
- **Data subject rights**: in-product "Request my data" (export) and "Delete my account" (right to erasure) flows, fulfilled within POPIA's required timeframe, logged in the audit trail.
- **Retention policy**: documents and case data retained only as long as needed for the case + statutory/legal-defense period, then auto-purged by a scheduled job; retention period configurable and documented in the Privacy Policy.
- **Information Officer**: a named Information Officer registered with the Information Regulator, contactable via the Contact page/Privacy Policy.
- **Cross-border transfer**: default to South African / Africa-region cloud regions for data residency; any sub-processor outside SA must meet POPIA §72 adequacy requirements (contractual safeguards).
- **Breach notification**: documented incident response plan with Information Regulator + data-subject notification workflow per POPIA §22.

## 7. Secure SDLC
- Branch protection + mandatory code review before merge to main.
- Static analysis (ESLint security rules, `eslint-plugin-security`) and SAST in CI.
- Environment separation: dev/staging/prod fully isolated infra and credentials; production data never copied into lower environments unmasked.
- Pre-launch third-party penetration test; quarterly vulnerability scans thereafter (mirrors PCI-DSS §11 cadence).
- Documented incident-response runbook and rollback procedure for every deploy.

## 8. AI-Specific Security
- Uploaded documents and extracted text sent to the LLM provider only over encrypted channels; provider contractually bound not to train on submitted data (data-processing agreement) and provider region selection where available.
- Every AI output that reaches an applicant passes through server-side policy filtering (disclaimer injection, scope check) before display.

## 9. Future Payment Path (Phase 2+, kept out of MVP scope deliberately)
If ClearPath later charges for premium features:
1. Integrate a PCI-DSS Level 1 gateway with hosted checkout / tokenized fields (card data never touches ClearPath servers).
2. Complete the applicable SAQ (typically SAQ-A) annually.
3. No cardholder data stored, transmitted, or processed by ClearPath infrastructure at any point.
