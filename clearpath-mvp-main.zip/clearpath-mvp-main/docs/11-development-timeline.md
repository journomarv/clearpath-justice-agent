# Development Timeline

| Weeks | Milestone |
|---|---|
| 1–2 | Foundations: auth, RBAC, security baseline, DB/storage/KMS |
| 3–4 | Marketing site + dashboard shell + document upload pipeline |
| 5–6 | AI eligibility checker (OCR → extraction → rules engine → reasoning) |
| 7–8 | Application generator + case tracking + notifications |
| 9–10 | Admin portal + reporting + audit log viewer |
| 11 | AI assistant, accessibility/perf hardening, security review |
| 12 | Penetration-test remediation, POPIA sign-off, pilot go-live |

**Total: ~12 weeks (3 months) to pilot launch**, assuming a small dedicated
team (see budget doc) and no major scope changes. Add 2–3 weeks contingency
for legal review of generated document templates (affidavit/application
wording should be sanity-checked by a South African attorney before any
real user relies on the output) and for penetration-test remediation depth.

**Realistic launch window: 14–16 weeks** including that legal-review and
remediation buffer.
