# ClearPath Justice — MVP Product Specification

## 1. Vision
ClearPath Justice is an AI-assisted legal-tech platform that helps eligible South Africans determine whether they qualify for criminal record expungement under the **Criminal Procedure Act 51 of 1977 (as amended)** and the **Judicial Matters Amendment Act**, and automates as much of the paperwork as legally permissible — while keeping a qualified human (initially platform admins / partner attorneys, later paralegal reviewers) in the loop for every decision that affects a legal outcome.

## 2. Problem Statement
A criminal record — even for a minor, decades-old offence — blocks employment, housing, and credit in South Africa. Most eligible people never expunge their record because:
- They don't know expungement exists or that they qualify.
- The application process (SAPS certificate, DOJ&CD application, affidavits) is bureaucratic and paper-based.
- Legal help is expensive or unavailable in their area.

## 3. MVP Scope (In / Out)

### In scope
| Feature | MVP behaviour |
|---|---|
| Marketing site | Static/SSR pages: Home, About, How it Works, FAQ, Contact |
| Auth | Email + password registration, login, password reset, session management |
| Dashboard | Profile, document upload, application status, notifications, document downloads |
| AI Eligibility Checker | OCR + LLM extraction of SAPS record → rule-engine + LLM eligibility reasoning with confidence/uncertainty flags |
| Document upload | PDF/JPG/PNG, virus-scanned, encrypted at rest |
| Application Generator | Auto-fills DOJ&CD expungement application (Annexure) + affidavit templates from extracted + user-confirmed data; **not** auto-submitted to government |
| Case tracking | Submitted → Under Review → Waiting for Information → Approved → Rejected |
| Manual offence entry | Fallback when AI extraction can't run (scanned/image-only document, AI not configured, or extraction failure) — user enters offence details by hand through the same confirm-then-evaluate gate |
| Admin portal | Review users, review AI output, approve/reject generated documents, manage case status, export CSV/PDF reports |
| Security/compliance | POPIA-aligned data handling, encryption at rest/in transit, audit trail, RBAC, hardened cloud hosting |

### Explicitly out of scope for MVP (see `14-future-roadmap.md`)
- AI Assistant chatbot (RAG over expungement law FAQs) — cut from MVP scope; the manual offence-entry fallback covers the "AI unavailable" case without it.
- Direct e-filing / API integration with SAPS or DOJ&CD systems (no public API exists yet — process remains "generate, human reviews, human/attorney lodges").
- Digital Certificate of Expungement / Digital Justice Passport.
- Payments (MVP is free or grant/NGO funded; if introduced later, card data is handled exclusively by a PCI-DSS Level 1 gateway — see `08-security-architecture.md` §9).
- Multi-language UI (English only at launch; copy structured for i18n later).
- Native mobile app (mobile-first responsive web only).
- Law-firm / Community Advice Office multi-tenant dashboards.

## 4. Users & Roles
1. **Applicant (User)** — the person seeking expungement.
2. **Reviewer/Admin (Platform staff or partner paralegal/attorney)** — validates AI output, approves documents, manages case state.
3. **Super Admin** — manages Reviewer accounts, sees audit logs, exports reports.
4. *(Phase 2)* Law firm / Community Advice Office user.

## 5. Legal Guardrails (product decisions driven by law, not just UX)
- The platform **never** tells a user "you are expunged" — only the Department of Justice & Constitutional Development (DOJ&CD) can grant expungement. The platform states: *"Based on the information provided, you appear to meet / not meet the criteria under the Criminal Procedure Act. This is not a legal decision — final approval rests with DOJ&CD."*
- Every AI eligibility determination is reviewable and overridable by a human Reviewer before any document is finalized or downloaded by the user (human-in-the-loop gate, see `05-ai-workflow.md`).
- Eligibility logic encodes the statutory waiting periods and offence exclusions (e.g., sexual offences against children, offences with a term of imprisonment without the option of a fine, Schedule 2/3 exclusions) as an explicit, versioned rules table — not opaque model reasoning — so every decision is explainable and auditable.

## 6. Success Metrics (MVP)
- ≥90% agreement between AI eligibility recommendation and final Reviewer decision (accuracy proxy).
- Median time from "upload record" to "reviewed application ready to lodge" < 48 hours.
- ≥80% of users who start the eligibility checker complete it (funnel completion).
- Zero critical security findings in pre-launch penetration test; POPIA data subject request (access/deletion) fulfilled within 5 business days.
- Pilot cohort of 50–100 real users completes at least one full journey (upload → generated application) before Phase 2 scoping begins.

## 7. Non-Functional Requirements
- **Mobile-first**: all screens usable on a low-end Android device on 3G.
- **Accessible**: WCAG 2.1 AA target — semantic HTML, alt text, keyboard navigation, color-contrast checked.
- **Secure**: see `08-security-architecture.md` — encryption, RBAC, audit logs, PCI-DSS-grade control rigor.
- **Scalable**: stateless API containers behind a load balancer; document storage and DB scale independently.
- **Fast**: <2.5s LCP on 4G for marketing pages; API p95 < 500ms for non-AI endpoints.
- **Low cost**: managed/serverless-first stack (see `technology stack` in README) to minimize ops burden pre-revenue.
- **Maintainable**: TypeScript end-to-end, typed API contracts (OpenAPI), infrastructure as code.
