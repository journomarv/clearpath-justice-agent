# Risks & Mitigations

| Risk | Impact | Mitigation |
|---|---|---|
| AI extraction/eligibility error leads to a user relying on wrong information | High — real legal/employment consequences | Deterministic, versioned rules engine (not free-form LLM judgment) for the actual eligibility decision; mandatory human Reviewer confirmation before any document is generated; explicit "not a legal decision" disclaimers throughout |
| Data breach exposing criminal records / ID numbers | High — POPIA liability, reputational, harm to vulnerable users | Field-level encryption, strict RBAC, audit logging, pre-launch pen-test, incident-response plan (see security doc) |
| Generated legal documents contain wording errors an attorney wouldn't have made | Medium-high | Templates drafted/reviewed by a South African attorney before launch; every document has a mandatory human review step before it reaches the user |
| POPIA non-compliance (consent, retention, data subject rights) | High — regulatory/legal risk | Information Officer appointed, documented retention policy + auto-purge job, in-product data export/erasure flows |
| LLM provider cost spike from high document volume or abuse | Medium | Job-queue concurrency caps, per-user rate limits, file size/type limits, monitoring/alerting on spend |
| Users without smartphones/reliable internet/digital literacy excluded | Medium — undermines access-to-justice mission | Mobile-first, low-bandwidth-friendly UI; partner with Community Advice Offices / NGOs for assisted-access during pilot (Phase 2 CAO portal) |
| SAPS record formats vary widely, breaking OCR/extraction | Medium | User confirmation step catches extraction errors; extraction confidence surfaced; pipeline logs low-confidence cases for prompt/ruleset iteration |
| Government process changes (legislation amendment) invalidate rules engine | Medium | Rules engine is versioned and externally editable by legal advisors without a code deploy; legal review cadence built into ops |
| Scope creep delays MVP launch | Medium | Explicit "out of scope" list (product spec §3); phased roadmap defers integrations/payments/mobile to Phase 2+ |
| Single point of failure: small team, key-person dependency | Medium | Documentation-first approach (this doc set + `development-status.md` maintained per session), IaC for infra reproducibility |
