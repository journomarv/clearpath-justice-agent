# Sprint Plan (2-week sprints, ~12 weeks to MVP launch)

## Sprint 0 — Foundations (weeks 1–2)
- Repo/CI setup, environments (dev/staging/prod), IaC skeleton.
- Auth (register/login/reset/MFA), RBAC, session model.
- Security baseline: Helmet, rate limiting, encryption utilities, audit log middleware.
- DB schema migrated (Prisma), object storage + KMS wired up.

## Sprint 1 — Marketing site + Dashboard shell (weeks 3–4)
- Landing/About/How it Works/FAQ/Contact (CMS-light, static content).
- Dashboard shell, profile, notifications.
- Document upload pipeline (malware scan, encrypted storage, OCR trigger).

## Sprint 2 — AI Eligibility Checker (weeks 5–6)
- OCR + Claude extraction pipeline; extraction confirmation UI.
- Versioned rules engine (v1 ruleset) + Claude reasoning/explanation pass.
- Eligibility result UI with confidence/uncertainty states.

## Sprint 3 — Application Generator + Case Tracking (weeks 7–8)
- DOJ&CD application + affidavit templating (fill from confirmed data).
- Document review/edit UI, case status timeline UI.
- Notifications (email + in-app) on state transitions.

## Sprint 4 — Admin Portal (weeks 9–10)
- Case queue, case detail, AI verdict review/override, document approval.
- Reports/export (CSV/PDF), staff account management (Super Admin).
- Audit log viewer (Super Admin only).

## Sprint 5 — AI Assistant + Hardening (week 11)
- RAG assistant over curated FAQ/legislation corpus + escalation-to-human.
- Accessibility pass (WCAG 2.1 AA), performance pass, mobile QA.
- Security review checklist, dependency/container scan, pre-pen-test fixes.

## Sprint 6 — Pilot readiness (week 12)
- Third-party penetration test remediation window.
- POPIA compliance walkthrough (Information Officer sign-off, Privacy Policy finalized).
- Pilot user onboarding materials, support runbook, go-live.

Each sprint ends with a demo + updated `development-status.md` per CLAUDE.md
workflow requirements, and a test-score log entry (functional/perf/AI-accuracy)
compared against the previous sprint's baseline.
