# AI Workflow

## Pipeline
```
1. Upload (PDF/JPG/PNG)
      │
2. Malware scan → reject if infected
      │
3. OCR (if image/scanned PDF) → raw text
      │
4. Claude extraction pass
      structured JSON: [{ offence, date, court, sentence_type,
      sentence_details }, ...] with per-field confidence
      │
5. User confirms/edits extracted offences (human-in-the-loop #1) —
      or, if extraction produced nothing (scanned/image-only document,
      AI not configured, or a failed extraction pass), the user enters
      offence details by hand via the same confirm-then-evaluate gate
      (`POST /eligibility/offences`)
      │
6. Deterministic rules engine (versioned `rules_versions` table)
      evaluates each offence against SA expungement criteria:
      - waiting period elapsed (e.g. 10yr fine/non-custodial vs
        longer for imprisonment, per current legislation)
      - offence not on excluded-offence schedule (e.g. sexual
        offences against children/mentally disabled persons,
        certain Schedule 2/8 offences)
      - no disqualifying subsequent conviction during waiting period
      → produces a deterministic candidate verdict PER offence
      │
7. Claude reasoning pass takes the rules-engine verdict + extracted
      facts and produces a plain-language explanation for the user,
      and flags "uncertain" when facts are ambiguous/incomplete
      (e.g. sentence type unclear from the document)
      │
8. Reviewer (human) sees AI verdict + reasoning + confidence,
      confirms or overrides with a mandatory reason (human-in-the-
      loop #2 — this is the actual "decision" of record)
      │
9. Only after reviewer confirmation: Application Generator fills
      the DOJ&CD application + affidavit templates
      │
10. User does final review of generated documents before they are
      finalized/downloadable
```

## Why two human-in-the-loop gates
- Gate 1 (user confirms extraction) catches OCR/extraction errors before they propagate into a legal document.
- Gate 2 (reviewer confirms/overrides eligibility) ensures no AI output reaches a user as a final decision without a human accountable for it — this is both a legal-risk control and a POPIA/AI-governance best practice.

## Deterministic rules engine vs. LLM
Eligibility is **not** decided by asking an LLM "is this person eligible?" — that would be unauditable and could hallucinate legal criteria. Instead:
- The waiting periods, excluded offences, and disqualification logic live in a **versioned, human-reviewed rules table** (`rules_versions`), editable by legal advisors without a code deploy.
- The LLM's job is (a) extracting structured facts from messy documents and (b) explaining the deterministic result in plain language — a much narrower, more verifiable task, and the one place where "hallucination" risk is contained and reviewable.

## AI Assistant (chatbot) — cut from MVP scope
Originally speced as a RAG chatbot over a curated legislation/FAQ corpus (see
`14-future-roadmap.md` for the deferred design). Cut for the MVP: it added a
second LLM-dependent surface without being on the critical path (extraction
→ rules engine → reviewer decision), and the manual-entry fallback above
already covers the case where AI isn't available. `POST /assistant/message`
and the `chat_messages` table have been removed; re-introduce as a Phase 2
item if there's demand.

## Model & provider
- Claude (Anthropic) for extraction and reasoning explanations — chosen for strong instruction-following on structured extraction, long-context document handling, and Anthropic's enterprise data-handling commitments (no training on API inputs by default). See `README.md` tech-stack rationale.
- All prompts/PII sent to the model over encrypted channels only; see `08-security-architecture.md` §8.

## Quality feedback loop
- Reviewer override rate per offence-type/rules-version is tracked (`eligibility_assessments.final_decision != ai_recommendation`) — a rising override rate on a rule signals the prompt or ruleset needs revision. This closes the loop referenced in the CLAUDE.md test-score tracking requirement: extraction accuracy and AI/Reviewer agreement rate are logged every release and compared to baseline before shipping prompt or model changes.
