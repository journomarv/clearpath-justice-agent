# Screen-by-Screen Wireframes (ASCII, mobile-first)

Legend: `[ ]` button, `( )` input, `{ }` dynamic content block.

## 1. Landing — Home
```
┌────────────────────────────┐
│ ClearPath Justice   [Menu≡]│
├────────────────────────────┤
│  "Clear your record.       │
│   Reopen your future."     │
│  [ Check My Eligibility ]  │
│  [ How it works ]          │
├────────────────────────────┤
│ {3 trust stats: e.g.        │
│  "X records reviewed"}      │
├────────────────────────────┤
│ How it works (3 steps)     │
│ 1 Upload  2 AI checks  3    │
│   Get your application     │
├────────────────────────────┤
│ Testimonial / partner logos │
├────────────────────────────┤
│ Footer: About/FAQ/Contact/  │
│ Privacy/POPIA notice        │
└────────────────────────────┘
```

## 2. About
```
Mission | Team/Partners | Legal disclaimer banner
("ClearPath Justice is not a law firm and does not
provide legal advice.")
```

## 3. How It Works
Step-by-step visual (Upload → AI Analysis → Review → Generate
Application → Track → Decision), each step expandable with FAQ-style detail.

## 4. FAQ
Accordion list grouped by: Eligibility, Documents, Process & Timelines,
Privacy & Security, Costs.

## 5. Contact
```
(Name) (Email) (Message)
[ Send ]
Alt channels: WhatsApp / email / office hours
```

## 6. Register
```
(Full name) (Email) (Phone - optional)
(Password) (Confirm password)
[ ] I accept POPIA-compliant Privacy Policy & Terms
[ Create account ]
Already have an account? [Log in]
```

## 7. Login
```
(Email) (Password) [Forgot password?]
[ Log in ]           (MFA code field appears if enabled)
```

## 8. Reset Password
```
Step 1: (Email) [Send reset link]
Step 2 (from emailed link): (New password)(Confirm) [Reset]
```

## 9. Dashboard — Home
```
┌────────────────────────────┐
│ Hi {FirstName}       [🔔3] │
├────────────────────────────┤
│ Application status card:   │
│  {status badge}  [View →]  │
├────────────────────────────┤
│ [ Upload Criminal Record ] │
│ [ Check Eligibility ]      │
│ [ My Documents ]           │
├────────────────────────────┤
│ Notifications list         │
└────────────────────────────┘
```

## 10. Profile
Editable: name, ID number (masked, encrypted), contact details, address.
Read-only: account created date, POPIA consent timestamp.
[ Request my data ] [ Delete my account ]

## 11. Document Upload
```
Drag/drop or [Choose file]  (PDF, JPG, PNG — max 10MB)
{upload progress}
{OCR status: "Extracting text..." spinner}
[ Continue to Eligibility Check ]
```

## 12. AI Eligibility Checker — Result
```
{Extracted offences table: Offence | Date | Court | Sentence}
  [Edit / confirm each row]
─────────────────────────────
Eligibility result:
  ✅ "You appear ELIGIBLE for expungement of: Offence X"
     Reason: sentence type + 10-year waiting period satisfied
  ⚠️ "UNCERTAIN for: Offence Y — needs human review"
  ❌ "NOT ELIGIBLE for: Offence Z — excluded offence (Schedule 2)"
Disclaimer: "This is an AI-assisted estimate, not a legal
decision. A ClearPath reviewer will confirm before your
application is generated."
[ Continue ]
```

## 13. Application Generator / Review
```
{Auto-filled DOJ&CD application form preview (PDF viewer)}
{Auto-filled affidavit preview}
[ Edit field ] per section
[ Submit for Reviewer Approval ]
```

## 14. Case Tracking
```
●──●──○──○──○
Submitted → Under Review → Waiting for Info → Approved/Rejected
{timeline with timestamps + reviewer notes visible to user}
[ Download documents ] (enabled once Approved by reviewer)
```

## 15. AI Assistant (chat widget, available on all dashboard screens)
```
┌ ClearPath Assistant ───────┐
│ "I can answer questions    │
│ about expungement, docs,   │
│ and timelines. I do not    │
│ give legal advice."         │
│ {chat thread}               │
│ ( Ask a question... ) [Send]│
│ [ Talk to a human reviewer ]│
└─────────────────────────────┘
```

## 16. Admin — Case Queue
```
Filters: Status | Assigned reviewer | Date
Table: User | Offences | AI recommendation | Confidence | Status | [Open]
```

## 17. Admin — Case Detail
```
{User profile summary}  {Uploaded doc viewer}
{AI extraction + eligibility reasoning, per-offence}
[ Approve AI recommendation ] [ Override → set manually ] (reason required)
{Generated documents} [ Approve for user ] [ Request changes ]
{Status control} [ Update case status ]  {Audit trail of this case}
```

## 18. Admin — Reports
```
[ Export CSV ] [ Export PDF ]
Filters: date range, status, outcome
Charts: applications over time, approval rate, avg turnaround
```
