# Future Roadmap (Phase 2–5 detail)

The MVP's database schema, API architecture, and rules-engine design are
deliberately built so these are additive, not rearchitectures.

## Phase 2: Scale & self-serve growth
- **Payments**: PCI-DSS Level 1 gateway (Stripe/Paystack/PayFast), tokenized/hosted fields, SAQ-A self-assessment — no cardholder data ever touches ClearPath servers.
- **Multi-language UI**: content already structured for i18n (copy not hardcoded in components); add isiZulu, isiXhosa, Afrikaans, Sesotho.
- **Community Advice Office portal**: a `role: cao_worker` on top of existing RBAC, with a "manage on behalf of" case-assignment model reusing the existing `applications`/`documents` schema.
- **AI Assistant chatbot**: cut from MVP scope (see `05-ai-workflow.md`) — RAG over a curated legislation/FAQ corpus, scoped refusal outside expungement/process/documents/timelines, human-reviewer escalation. Re-add here if pilot usage shows applicants need conversational support beyond the manual-entry fallback and FAQ page.

## Phase 3: Institutional integration
- **Government system integration**: `applications.status` design already anticipates an external-status sync field once SAPS/DOJ&CD expose an API or data-sharing MOU — no schema break needed, just a new sync worker.
- **Law firm dashboard**: multi-tenant layer over existing `users`/`applications` (firm_id scoping), optional white-label theming.
- **Analytics dashboard**: aggregate views over `eligibility_assessments`/`applications`/`audit_logs` already captured in MVP — Phase 3 just adds the visualization layer.

## Phase 4: Digital Justice Passport
- **Digital Certificate of Expungement**: once legally recognized digital issuance is possible (requires DOJ&CD partnership/legal framework), issuance workflow attaches to the existing `applications.status = approved` state.
- **Digital Justice Passport**: a user-controlled, POPIA-consented, verifiable credential (e.g. verifiable-credentials standard) referencing the certificate — shareable with employers without exposing the underlying case file.

## Phase 5: Proactive access to justice
- **Authorized-dataset batch screening**: requires a formal legal mandate/MOU with a data holder; reuses the same rules engine as an offline batch job against de-identified-until-matched records, with strict data-minimization and audit controls exceeding the MVP baseline.
- **AI-assisted case management for legal aid orgs at scale**: bulk case-queue tooling, SLA tracking, and caseload analytics building on the Admin Portal.
- **Native mobile app**: once usage data justifies it over the mobile-first responsive web app; the API layer (already versioned REST) supports a mobile client without backend changes.

## Design principle carried through every phase
Every phase preserves the MVP's core guardrail: **AI assists, humans decide**,
and every legally consequential action remains reviewable and auditable.
