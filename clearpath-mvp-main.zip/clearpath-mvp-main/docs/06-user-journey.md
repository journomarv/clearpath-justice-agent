# User Journey

```
Landing Page
   │  (reads About/How it Works/FAQ, clicks "Check My Eligibility")
   ▼
Registration (email/password, POPIA consent checkbox)
   │
   ▼
Dashboard (empty state → CTA: Upload Criminal Record)
   │
   ▼
Upload SAPS Criminal Record (PDF/JPG/PNG)
   │  malware scan → OCR → AI extraction (async, progress shown)
   ▼
Confirm Extracted Offences (user edits any OCR/extraction errors)
   │
   ▼
AI Eligibility Result (per offence: eligible / not eligible /
   uncertain + plain-language reasoning + disclaimer)
   │
   ▼
[Wait for Reviewer confirmation — user sees "Under Review" status;
   receives notification when a human reviewer confirms/overrides]
   │
   ▼
Application Generated (DOJ&CD application + affidavit pre-filled)
   │
   ▼
User Reviews & Confirms Generated Documents
   │
   ▼
Submit for Reviewer Approval → status: Submitted
   │
   ▼
Case Tracking (Submitted → Under Review → Waiting for Information
   ↔ user notified, can upload additional docs if requested →
   Approved / Rejected)
   │
   ▼
Receive Decision
   ├─ Approved → Download finalized application + affidavit,
   │             guidance on lodging with DOJ&CD / next steps
   └─ Rejected/Not eligible → plain-language explanation + (if
                 applicable) guidance on when they may become
                 eligible (e.g. waiting period end date) or referral
                 to a partner attorney/legal aid resource
```

## Touchpoints & notifications
- Email + in-app notification at every state transition (extraction complete, reviewer decision, status change, additional info requested, final decision).
- AI Assistant available throughout for process questions, with a "talk to a human reviewer" escalation at any step.
