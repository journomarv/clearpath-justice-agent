"""API-facing schemas: chat request/response, health check."""
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator

from app.privacy import contains_pii
from app.schemas.rules import ReliefType


class SourceRef(BaseModel):
    """A reference to a knowledge source, returned to the caller for transparency."""

    id: str
    title: str
    source_type: str
    verified_date: Optional[str] = None
    url: Optional[str] = None


class ChatRequest(BaseModel):
    """Incoming message to the agent."""

    message: str = Field(..., min_length=1, max_length=4000)
    user_id: Optional[str] = Field(default=None, max_length=128)
    session_id: Optional[str] = Field(default=None, max_length=128)
    # Optional explicit hint from the client (e.g. a WhatsApp menu selection)
    # so the agent does not have to guess intent from free text alone.
    relief_type_hint: Optional[ReliefType] = None

    @field_validator("message")
    @classmethod
    def _reject_identifiers(cls, value: str) -> str:
        if contains_pii(value):
            raise ValueError(
                "Message appears to contain an ID or phone number. For your "
                "privacy, please don't share ID numbers or phone numbers in "
                "chat; ClearPath will ask for anything it truly needs, "
                "through a secure step, only when necessary."
            )
        return value


class ChatResponse(BaseModel):
    """Structured response returned by the agent."""

    message: str
    next_action: str
    requires_human: bool
    confidence: float = Field(ge=0.0, le=1.0)
    sources: List[SourceRef] = Field(default_factory=list)
    relief_type: Optional[ReliefType] = None


class HealthChecks(BaseModel):
    api: bool
    configuration: bool
    deepseek_available: bool


class HealthResponse(BaseModel):
    status: str
    service: str = "clearpath-justice-agent"
    version: str
    checks: HealthChecks
