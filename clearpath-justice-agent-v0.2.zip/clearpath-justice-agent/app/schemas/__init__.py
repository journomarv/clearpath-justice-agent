"""Pydantic data schemas for ClearPath Justice Agent."""
