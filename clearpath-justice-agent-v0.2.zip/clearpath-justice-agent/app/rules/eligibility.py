"""
Rules engine entry point.

This is the ONLY function the rest of the app (tools, agent) should call
to get an eligibility assessment. It looks up the correct handler via the
registry (app/rules/registry.py) so new relief types can be added without
touching this file or app/agent.py.
"""
from typing import Optional

from app.rules import registry
from app.schemas.rules import EligibilityAssessment, EligibilityStatus, ReliefType, ScreeningAnswers


def assess_expungement_eligibility(answers: ScreeningAnswers) -> EligibilityAssessment:
    """
    Assess eligibility for the relief type given in `answers`.

    If no relief type is set, or the relief type has no registered
    handler, returns an UNKNOWN assessment that routes to human review —
    never guesses at criteria.
    """
    relief_type = answers.relief_type or ReliefType.UNKNOWN
    handler = registry.get_handler(relief_type)

    if handler is None:
        return EligibilityAssessment(
            relief_type=relief_type,
            status=EligibilityStatus.UNKNOWN,
            reasons=[
                "ClearPath does not yet support automated screening for "
                "this type of case."
                if relief_type != ReliefType.UNKNOWN
                else "The type of relief being sought could not be determined "
                "from the information provided."
            ],
            next_steps=[
                "A ClearPath team member will help identify the right "
                "process for your situation.",
            ],
            documents_required=[],
            requires_human_review=True,
            verified_rules_applied=False,
            source_ids=[],
        )

    return handler(answers)


def identify_referral_need(assessment: EligibilityAssessment) -> Optional[str]:
    """
    Return a referral reason string if this assessment should be handed to
    a human, else None. Kept simple and explicit: any non-verified or
    human-review assessment is referred.
    """
    if assessment.requires_human_review or not assessment.verified_rules_applied:
        return "UNCERTAIN_ELIGIBILITY"
    if assessment.status == EligibilityStatus.UNKNOWN:
        return "OUTSIDE_KNOWLEDGE_BASE"
    return None
