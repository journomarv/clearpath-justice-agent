"""
Eligibility rules engine.

This package is deliberately modular so ClearPath can support relief types
beyond cannabis expungement (the original v0.1 scope). To add a new relief
type:

  1. Add a value to ReliefType in app/schemas/rules.py.
  2. Create app/rules/<new_relief_type>.py with a function decorated
     `@register(ReliefType.YOUR_NEW_TYPE)` (see registry.py).
  3. Import that module below so the decorator runs and the handler is
     registered.

Importing this package registers every known relief-type handler. Nothing
else in the app should import a relief-type module (e.g. cannabis_cppa)
directly — always go through app.rules.eligibility /
app.rules.registry.
"""
from app.rules import cannabis_cppa  # noqa: F401  (registers handler)
from app.rules import criminal_record_expungement  # noqa: F401  (registers handler)
from app.rules.eligibility import assess_expungement_eligibility, identify_referral_need
from app.rules.registry import get_handler, is_supported, list_supported_relief_types

__all__ = [
    "assess_expungement_eligibility",
    "identify_referral_need",
    "get_handler",
    "is_supported",
    "list_supported_relief_types",
]
