"""ClearPath Justice Agent application package."""

__version__ = "0.2.0"
