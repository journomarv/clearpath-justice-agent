"""Agent tools: controlled operations the LLM can trigger, but never bypass."""
