"""
Knowledge base retrieval interface.

Structure (extended for v0.2, still placeholder content pending ClearPath
material — see README.md in this directory for the population workflow):

    expungement_process_guide   — step-by-step process, per relief type
    document_checklist          — required documents, per relief type
    application_forms           — official form references
    police_clearance_info       — how to obtain a SAPS clearance certificate
    referral_organizations      — where to send someone needing human help

Each item is tagged with a `relief_types` list so the agent can filter
knowledge relevant to the case at hand, and a `source_ids` list pointing
into app/knowledge/sources.py for provenance.

PRINCIPLE: No invented information. Only verified materials. Always cite a
source. Never presented as more current than its verified_date.
"""
from typing import Dict, List, Optional, TypedDict

from app.schemas.rules import ReliefType
from app.knowledge.sources import KnowledgeSource, get_sources


class KnowledgeItem(TypedDict):
    id: str
    title: str
    relief_types: List[str]
    source_ids: List[str]
    content: str
    verified_date: Optional[str]


# TODO(clearpath): Replace placeholder `content` strings with verified
# material once supplied. Every item below is intentionally generic and
# instructs the agent to defer to a human rather than assert specifics.
KNOWLEDGE_STRUCTURE: Dict[str, KnowledgeItem] = {
    "expungement_process_guide": {
        "id": "expungement_process_guide",
        "title": "How the expungement process generally works",
        "relief_types": [
            ReliefType.CANNABIS_EXPUNGEMENT.value,
            ReliefType.CRIMINAL_RECORD_EXPUNGEMENT.value,
        ],
        "source_ids": ["doj_expungements_overview", "gov_za_expungement_summary"],
        "content": (
            "TODO(clearpath): populate with a verified, plain-language "
            "walkthrough of the process, sourced from the cited DOJ/gov.za "
            "pages and reviewed by ClearPath legal before being shown to "
            "users as authoritative."
        ),
        "verified_date": None,
    },
    "document_checklist": {
        "id": "document_checklist",
        "title": "Documents commonly needed for an expungement application",
        "relief_types": [
            ReliefType.CANNABIS_EXPUNGEMENT.value,
            ReliefType.CRIMINAL_RECORD_EXPUNGEMENT.value,
        ],
        "source_ids": ["doj_expungements_overview", "saps_criminal_record_centre"],
        "content": (
            "TODO(clearpath): populate the verified document checklist "
            "(e.g. police clearance certificate, completed application "
            "form) once confirmed."
        ),
        "verified_date": None,
    },
    "application_forms": {
        "id": "application_forms",
        "title": "Official application forms",
        "relief_types": [ReliefType.CRIMINAL_RECORD_EXPUNGEMENT.value],
        "source_ids": ["doj_expungements_overview"],
        "content": (
            "TODO(clearpath): confirm current form identifiers (e.g. Form "
            "A / J744, Form 13 / J763) and add direct links once verified "
            "as current."
        ),
        "verified_date": None,
    },
    "police_clearance_info": {
        "id": "police_clearance_info",
        "title": "How to obtain a SAPS police clearance certificate",
        "relief_types": [
            ReliefType.CANNABIS_EXPUNGEMENT.value,
            ReliefType.CRIMINAL_RECORD_EXPUNGEMENT.value,
        ],
        "source_ids": ["saps_criminal_record_centre"],
        "content": (
            "TODO(clearpath): populate with the current SAPS process for "
            "requesting a police clearance certificate."
        ),
        "verified_date": None,
    },
    "referral_organizations": {
        "id": "referral_organizations",
        "title": "Where to go for human / legal help",
        "relief_types": [
            ReliefType.CANNABIS_EXPUNGEMENT.value,
            ReliefType.CRIMINAL_RECORD_EXPUNGEMENT.value,
            ReliefType.UNKNOWN.value,
        ],
        "source_ids": ["clearpath_referral_organizations"],
        "content": (
            "TODO(clearpath): populate with the current list of legal aid "
            "clinics, NGOs, and partner organisations, with contact "
            "details and intake criteria."
        ),
        "verified_date": None,
    },
}


def get_knowledge_item(item_id: str) -> Optional[KnowledgeItem]:
    return KNOWLEDGE_STRUCTURE.get(item_id)


def list_knowledge_for_relief_type(relief_type: ReliefType) -> List[KnowledgeItem]:
    """Return knowledge items relevant to a given relief type."""
    return [
        item
        for item in KNOWLEDGE_STRUCTURE.values()
        if relief_type.value in item["relief_types"]
    ]


def get_sources_for_item(item_id: str) -> List[KnowledgeSource]:
    item = get_knowledge_item(item_id)
    if not item:
        return []
    return get_sources(item["source_ids"])
